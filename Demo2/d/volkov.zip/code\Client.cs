using System;

namespace DefaultScope
{
	public static class ContextFactory
	{
		public static Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineContext CreateContext(string cachePath, System.Uri serviceUri)
		{
			return new DefaultScope.OfflineContext(cachePath, serviceUri);
		}

		public static String ScopeName
		{
			get
			{
				return "DefaultScope";
			}
		}

		public static String ConfigName
		{
			get
			{
				return "BitMobile";
			}
		}

		public static String Version
		{
			get
			{
				return "1.0.0.7";
			}
		}
		
	}
}

namespace DefaultScope 
{
	 
	namespace Enum 
	{
		 
		
		[System.Serializable]
		public partial class DataStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static DataStatus CreateInstance(OfflineContext dao)
            {
                DataStatus entity = new DataStatus();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<DataStatus>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class DataType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static DataType CreateInstance(OfflineContext dao)
            {
                DataType entity = new DataType();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<DataType>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class OutletConfirmationStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static OutletConfirmationStatus CreateInstance(OfflineContext dao)
            {
                OutletConfirmationStatus entity = new OutletConfirmationStatus();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<OutletConfirmationStatus>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class TypesOfUsers : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static TypesOfUsers CreateInstance(OfflineContext dao)
            {
                TypesOfUsers entity = new TypesOfUsers();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<TypesOfUsers>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class UploadType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static UploadType CreateInstance(OfflineContext dao)
            {
                UploadType entity = new UploadType();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<UploadType>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class VisitStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static VisitStatus CreateInstance(OfflineContext dao)
            {
                VisitStatus entity = new VisitStatus();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<VisitStatus>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class StatusTask : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static StatusTask CreateInstance(OfflineContext dao)
            {
                StatusTask entity = new StatusTask();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<StatusTask>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class OrderSatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static OrderSatus CreateInstance(OfflineContext dao)
            {
                OrderSatus entity = new OrderSatus();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<OrderSatus>(entity);
                return entity;
            }

					}

		        
		
		public class Collections
		{
			private OfflineContext context;

			public Collections(OfflineContext context)
			{
				this.context = context;
			}

			 

			public System.Collections.Generic.IEnumerable<Enum.DataStatus> DataStatus 
			{
				get 
				{
					return context.GetCollection<Enum.DataStatus>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.DataType> DataType 
			{
				get 
				{
					return context.GetCollection<Enum.DataType>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.OutletConfirmationStatus> OutletConfirmationStatus 
			{
				get 
				{
					return context.GetCollection<Enum.OutletConfirmationStatus>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.TypesOfUsers> TypesOfUsers 
			{
				get 
				{
					return context.GetCollection<Enum.TypesOfUsers>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.UploadType> UploadType 
			{
				get 
				{
					return context.GetCollection<Enum.UploadType>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.VisitStatus> VisitStatus 
			{
				get 
				{
					return context.GetCollection<Enum.VisitStatus>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.StatusTask> StatusTask 
			{
				get 
				{
					return context.GetCollection<Enum.StatusTask>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Enum.OrderSatus> OrderSatus 
			{
				get 
				{
					return context.GetCollection<Enum.OrderSatus>();
				}
			}


			
					}

	}

	 
	namespace Catalog 
	{
		 
		
		[System.Serializable]
		public partial class Positions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static Positions CreateInstance(OfflineContext dao)
            {
                Positions entity = new Positions();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Positions>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class User : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Manager;		

						public Guid Manager 
			{
				get 
				{
					return _Manager;
				}
				set 
				{
					base.OnPropertyChanging("Manager");
					_Manager = value;
					base.OnPropertyChanged("Manager");
				}
			}

						public Catalog.User ManagerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_Manager))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Manager.ToString()));
				return null;
			}
			
			
			
			private String _EMail;		

						public String EMail 
			{
				get 
				{
					return _EMail;
				}
				set 
				{
					base.OnPropertyChanging("EMail");
					_EMail = value;
					base.OnPropertyChanged("EMail");
				}
			}

			
			
			
			private System.Nullable<Guid> _UserID;		

						public System.Nullable<Guid> UserID 
			{
				get 
				{
					return _UserID;
				}
				set 
				{
					base.OnPropertyChanging("UserID");
					_UserID = value;
					base.OnPropertyChanged("UserID");
				}
			}

			
			
			
			private String _UserName;		

						public String UserName 
			{
				get 
				{
					return _UserName;
				}
				set 
				{
					base.OnPropertyChanging("UserName");
					_UserName = value;
					base.OnPropertyChanged("UserName");
				}
			}

			
			
			
			private String _Role;		

						public String Role 
			{
				get 
				{
					return _Role;
				}
				set 
				{
					base.OnPropertyChanging("Role");
					_Role = value;
					base.OnPropertyChanged("Role");
				}
			}

			
			
			
			private String _Password;		

						public String Password 
			{
				get 
				{
					return _Password;
				}
				set 
				{
					base.OnPropertyChanging("Password");
					_Password = value;
					base.OnPropertyChanged("Password");
				}
			}

			
			
			
			private Guid _Position;		

						public Guid Position 
			{
				get 
				{
					return _Position;
				}
				set 
				{
					base.OnPropertyChanging("Position");
					_Position = value;
					base.OnPropertyChanged("Position");
				}
			}

						public Catalog.Positions PositionAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Positions)
                    if (item.Id.Equals(_Position))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Position.ToString()));
				return null;
			}
			
			
			
			public static User CreateInstance(OfflineContext dao)
            {
                User entity = new User();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<User>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Region : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Parent;		

						public Guid Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

						public Catalog.Region ParentAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Region)
                    if (item.Id.Equals(_Parent))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Parent.ToString()));
				return null;
			}
			
			
			
			private Guid _Manager;		

						public Guid Manager 
			{
				get 
				{
					return _Manager;
				}
				set 
				{
					base.OnPropertyChanging("Manager");
					_Manager = value;
					base.OnPropertyChanged("Manager");
				}
			}

						public Catalog.User ManagerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_Manager))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Manager.ToString()));
				return null;
			}
			
			
			
			public static Region CreateInstance(OfflineContext dao)
            {
                Region entity = new Region();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Region>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Distributor : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static Distributor CreateInstance(OfflineContext dao)
            {
                Distributor entity = new Distributor();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Distributor>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class OutletParameter : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _DataType;		

						public Guid DataType 
			{
				get 
				{
					return _DataType;
				}
				set 
				{
					base.OnPropertyChanging("DataType");
					_DataType = value;
					base.OnPropertyChanged("DataType");
				}
			}

						public Enum.DataType DataTypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.DataType)
                    if (item.Id.Equals(_DataType))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _DataType.ToString()));
				return null;
			}
			
			
			
			public static OutletParameter CreateInstance(OfflineContext dao)
            {
                OutletParameter entity = new OutletParameter();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<OutletParameter>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class OutletType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static OutletType CreateInstance(OfflineContext dao)
            {
                OutletType entity = new OutletType();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<OutletType>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class OutletClass : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static OutletClass CreateInstance(OfflineContext dao)
            {
                OutletClass entity = new OutletClass();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<OutletClass>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Outlet : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Type;		

						public Guid Type 
			{
				get 
				{
					return _Type;
				}
				set 
				{
					base.OnPropertyChanging("Type");
					_Type = value;
					base.OnPropertyChanged("Type");
				}
			}

						public Catalog.OutletType TypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletType)
                    if (item.Id.Equals(_Type))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Type.ToString()));
				return null;
			}
			
			
			
			private Guid _Class;		

						public Guid Class 
			{
				get 
				{
					return _Class;
				}
				set 
				{
					base.OnPropertyChanging("Class");
					_Class = value;
					base.OnPropertyChanged("Class");
				}
			}

						public Catalog.OutletClass ClassAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletClass)
                    if (item.Id.Equals(_Class))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Class.ToString()));
				return null;
			}
			
			
			
			private Guid _Distributor;		

						public Guid Distributor 
			{
				get 
				{
					return _Distributor;
				}
				set 
				{
					base.OnPropertyChanging("Distributor");
					_Distributor = value;
					base.OnPropertyChanged("Distributor");
				}
			}

						public Catalog.Distributor DistributorAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Distributor)
                    if (item.Id.Equals(_Distributor))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Distributor.ToString()));
				return null;
			}
			
			
			
			private String _Address;		

						public String Address 
			{
				get 
				{
					return _Address;
				}
				set 
				{
					base.OnPropertyChanging("Address");
					_Address = value;
					base.OnPropertyChanged("Address");
				}
			}

			
			
			
			private Guid _ConfirmationStatus;		

						public Guid ConfirmationStatus 
			{
				get 
				{
					return _ConfirmationStatus;
				}
				set 
				{
					base.OnPropertyChanging("ConfirmationStatus");
					_ConfirmationStatus = value;
					base.OnPropertyChanged("ConfirmationStatus");
				}
			}

						public Enum.OutletConfirmationStatus ConfirmationStatusAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.OutletConfirmationStatus)
                    if (item.Id.Equals(_ConfirmationStatus))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _ConfirmationStatus.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<decimal> _Lattitude;		

						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					base.OnPropertyChanging("Lattitude");
					_Lattitude = value;
					base.OnPropertyChanged("Lattitude");
				}
			}

			
			
			
			private System.Nullable<decimal> _Longitude;		

						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					base.OnPropertyChanging("Longitude");
					_Longitude = value;
					base.OnPropertyChanged("Longitude");
				}
			}

			
			
			
			public static Outlet CreateInstance(OfflineContext dao)
            {
                Outlet entity = new Outlet();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Outlet>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Catalog.Outlet_Parameters> Parameters(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.Outlet_Parameters> result = new System.Collections.Generic.List<Catalog.Outlet_Parameters>();
				System.Collections.Generic.IEnumerable<Catalog.Outlet_Parameters> items = context.GetCollection<Catalog.Outlet_Parameters>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Outlet_Parameters : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Outlet RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Parameter;		

						public Guid Parameter 
			{
				get 
				{
					return _Parameter;
				}
				set 
				{
					base.OnPropertyChanging("Parameter");
					_Parameter = value;
					base.OnPropertyChanged("Parameter");
				}
			}

						public Catalog.OutletParameter ParameterAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletParameter)
                    if (item.Id.Equals(_Parameter))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Parameter.ToString()));
				return null;
			}
			
			
			
			private String _Value;		

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					base.OnPropertyChanging("Value");
					_Value = value;
					base.OnPropertyChanged("Value");
				}
			}

			
			
			
			public static Outlet_Parameters CreateInstance(OfflineContext dao)
            {
                Outlet_Parameters entity = new Outlet_Parameters();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Outlet_Parameters>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Territory : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Owner;		

						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					base.OnPropertyChanging("Owner");
					_Owner = value;
					base.OnPropertyChanged("Owner");
				}
			}

						public Catalog.Region OwnerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Region)
                    if (item.Id.Equals(_Owner))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Owner.ToString()));
				return null;
			}
			
			
			
			private Guid _SR;		

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					base.OnPropertyChanging("SR");
					_SR = value;
					base.OnPropertyChanged("SR");
				}
			}

						public Catalog.User SRAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_SR))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SR.ToString()));
				return null;
			}
			
			
			
			public static Territory CreateInstance(OfflineContext dao)
            {
                Territory entity = new Territory();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Territory>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Catalog.Territory_Outlets> Outlets(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.Territory_Outlets> result = new System.Collections.Generic.List<Catalog.Territory_Outlets>();
				System.Collections.Generic.IEnumerable<Catalog.Territory_Outlets> items = context.GetCollection<Catalog.Territory_Outlets>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Catalog.Territory_SKUGroups> SKUGroups(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.Territory_SKUGroups> result = new System.Collections.Generic.List<Catalog.Territory_SKUGroups>();
				System.Collections.Generic.IEnumerable<Catalog.Territory_SKUGroups> items = context.GetCollection<Catalog.Territory_SKUGroups>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Territory_Outlets : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Territory RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Territory)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Outlet;		

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					base.OnPropertyChanging("Outlet");
					_Outlet = value;
					base.OnPropertyChanged("Outlet");
				}
			}

						public Catalog.Outlet OutletAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Outlet))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Outlet.ToString()));
				return null;
			}
			
			
			
			public static Territory_Outlets CreateInstance(OfflineContext dao)
            {
                Territory_Outlets entity = new Territory_Outlets();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Territory_Outlets>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Territory_SKUGroups : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Territory RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Territory)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKUGroup;		

						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					base.OnPropertyChanging("SKUGroup");
					_SKUGroup = value;
					base.OnPropertyChanged("SKUGroup");
				}
			}

						public Catalog.SKUGroup SKUGroupAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUGroup)
                    if (item.Id.Equals(_SKUGroup))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKUGroup.ToString()));
				return null;
			}
			
			
			
			public static Territory_SKUGroups CreateInstance(OfflineContext dao)
            {
                Territory_SKUGroups entity = new Territory_SKUGroups();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Territory_SKUGroups>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class QuestionGroup : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static QuestionGroup CreateInstance(OfflineContext dao)
            {
                QuestionGroup entity = new QuestionGroup();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<QuestionGroup>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Question : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Owner;		

						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					base.OnPropertyChanging("Owner");
					_Owner = value;
					base.OnPropertyChanged("Owner");
				}
			}

						public Catalog.QuestionGroup OwnerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.QuestionGroup)
                    if (item.Id.Equals(_Owner))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Owner.ToString()));
				return null;
			}
			
			
			
			private Guid _AnswerType;		

						public Guid AnswerType 
			{
				get 
				{
					return _AnswerType;
				}
				set 
				{
					base.OnPropertyChanging("AnswerType");
					_AnswerType = value;
					base.OnPropertyChanged("AnswerType");
				}
			}

						public Enum.DataType AnswerTypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.DataType)
                    if (item.Id.Equals(_AnswerType))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _AnswerType.ToString()));
				return null;
			}
			
			
			
			public static Question CreateInstance(OfflineContext dao)
            {
                Question entity = new Question();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Question>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Catalog.Question_ValueList> ValueList(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.Question_ValueList> result = new System.Collections.Generic.List<Catalog.Question_ValueList>();
				System.Collections.Generic.IEnumerable<Catalog.Question_ValueList> items = context.GetCollection<Catalog.Question_ValueList>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Question_ValueList : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Question RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Question)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private String _Value;		

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					base.OnPropertyChanging("Value");
					_Value = value;
					base.OnPropertyChanged("Value");
				}
			}

			
			
			
			public static Question_ValueList CreateInstance(OfflineContext dao)
            {
                Question_ValueList entity = new Question_ValueList();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Question_ValueList>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class SKUGroup : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Parent;		

						public Guid Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

						public Catalog.SKUGroup ParentAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUGroup)
                    if (item.Id.Equals(_Parent))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Parent.ToString()));
				return null;
			}
			
			
			
			public static SKUGroup CreateInstance(OfflineContext dao)
            {
                SKUGroup entity = new SKUGroup();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<SKUGroup>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Brands : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			public static Brands CreateInstance(OfflineContext dao)
            {
                Brands entity = new Brands();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Brands>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class UnitsOfMeasure : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private String _FullDescription;		

						public String FullDescription 
			{
				get 
				{
					return _FullDescription;
				}
				set 
				{
					base.OnPropertyChanging("FullDescription");
					_FullDescription = value;
					base.OnPropertyChanged("FullDescription");
				}
			}

			
			
			
			public static UnitsOfMeasure CreateInstance(OfflineContext dao)
            {
                UnitsOfMeasure entity = new UnitsOfMeasure();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<UnitsOfMeasure>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class SKU : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _Owner;		

						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					base.OnPropertyChanging("Owner");
					_Owner = value;
					base.OnPropertyChanged("Owner");
				}
			}

						public Catalog.SKUGroup OwnerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUGroup)
                    if (item.Id.Equals(_Owner))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Owner.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<decimal> _Price;		

						public System.Nullable<decimal> Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					base.OnPropertyChanging("Price");
					_Price = value;
					base.OnPropertyChanged("Price");
				}
			}

			
			
			
			private Guid _Brand;		

						public Guid Brand 
			{
				get 
				{
					return _Brand;
				}
				set 
				{
					base.OnPropertyChanging("Brand");
					_Brand = value;
					base.OnPropertyChanged("Brand");
				}
			}

						public Catalog.Brands BrandAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Brands)
                    if (item.Id.Equals(_Brand))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Brand.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<decimal> _Stock;		

						public System.Nullable<decimal> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					base.OnPropertyChanging("Stock");
					_Stock = value;
					base.OnPropertyChanged("Stock");
				}
			}

			
			
			
			private Guid _BaseUnit;		

						public Guid BaseUnit 
			{
				get 
				{
					return _BaseUnit;
				}
				set 
				{
					base.OnPropertyChanging("BaseUnit");
					_BaseUnit = value;
					base.OnPropertyChanged("BaseUnit");
				}
			}

						public Catalog.UnitsOfMeasure BaseUnitAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.UnitsOfMeasure)
                    if (item.Id.Equals(_BaseUnit))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _BaseUnit.ToString()));
				return null;
			}
			
			
			
			public static SKU CreateInstance(OfflineContext dao)
            {
                SKU entity = new SKU();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<SKU>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Catalog.SKU_Packing> Packing(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.SKU_Packing> result = new System.Collections.Generic.List<Catalog.SKU_Packing>();
				System.Collections.Generic.IEnumerable<Catalog.SKU_Packing> items = context.GetCollection<Catalog.SKU_Packing>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class SKU_Packing : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public SKU RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKU)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Pack;		

						public Guid Pack 
			{
				get 
				{
					return _Pack;
				}
				set 
				{
					base.OnPropertyChanging("Pack");
					_Pack = value;
					base.OnPropertyChanged("Pack");
				}
			}

						public Catalog.UnitsOfMeasure PackAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.UnitsOfMeasure)
                    if (item.Id.Equals(_Pack))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Pack.ToString()));
				return null;
			}
			
			
			
			private decimal _Multiplier;		

						public decimal Multiplier 
			{
				get 
				{
					return _Multiplier;
				}
				set 
				{
					base.OnPropertyChanging("Multiplier");
					_Multiplier = value;
					base.OnPropertyChanged("Multiplier");
				}
			}

			
			
			
			public static SKU_Packing CreateInstance(OfflineContext dao)
            {
                SKU_Packing entity = new SKU_Packing();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<SKU_Packing>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class SKUQuestions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Code;		

						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					base.OnPropertyChanging("Code");
					_Code = value;
					base.OnPropertyChanged("Code");
				}
			}

			
			
			
			private String _Description;		

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					base.OnPropertyChanging("Description");
					_Description = value;
					base.OnPropertyChanged("Description");
				}
			}

			
			
			
			private Guid _AnswerType;		

						public Guid AnswerType 
			{
				get 
				{
					return _AnswerType;
				}
				set 
				{
					base.OnPropertyChanging("AnswerType");
					_AnswerType = value;
					base.OnPropertyChanged("AnswerType");
				}
			}

						public Enum.DataType AnswerTypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.DataType)
                    if (item.Id.Equals(_AnswerType))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _AnswerType.ToString()));
				return null;
			}
			
			
			
			public static SKUQuestions CreateInstance(OfflineContext dao)
            {
                SKUQuestions entity = new SKUQuestions();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<SKUQuestions>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Catalog.SKUQuestions_ValueList> ValueList(OfflineContext context) 
			{
				System.Collections.Generic.List<Catalog.SKUQuestions_ValueList> result = new System.Collections.Generic.List<Catalog.SKUQuestions_ValueList>();
				System.Collections.Generic.IEnumerable<Catalog.SKUQuestions_ValueList> items = context.GetCollection<Catalog.SKUQuestions_ValueList>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class SKUQuestions_ValueList : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public SKUQuestions RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUQuestions)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private String _Value;		

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					base.OnPropertyChanging("Value");
					_Value = value;
					base.OnPropertyChanged("Value");
				}
			}

			
			
			
			public static SKUQuestions_ValueList CreateInstance(OfflineContext dao)
            {
                SKUQuestions_ValueList entity = new SKUQuestions_ValueList();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<SKUQuestions_ValueList>(entity);
                return entity;
            }
		}

		        
		
		public class Collections
		{
			private OfflineContext context;

			public Collections(OfflineContext context)
			{
				this.context = context;
			}

			 

			public System.Collections.Generic.IEnumerable<Catalog.Positions> Positions 
			{
				get 
				{
					return context.GetCollection<Catalog.Positions>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.User> User 
			{
				get 
				{
					return context.GetCollection<Catalog.User>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Region> Region 
			{
				get 
				{
					return context.GetCollection<Catalog.Region>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Distributor> Distributor 
			{
				get 
				{
					return context.GetCollection<Catalog.Distributor>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.OutletParameter> OutletParameter 
			{
				get 
				{
					return context.GetCollection<Catalog.OutletParameter>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.OutletType> OutletType 
			{
				get 
				{
					return context.GetCollection<Catalog.OutletType>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.OutletClass> OutletClass 
			{
				get 
				{
					return context.GetCollection<Catalog.OutletClass>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Outlet> Outlet 
			{
				get 
				{
					return context.GetCollection<Catalog.Outlet>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Catalog.Outlet_Parameters> Outlet_Parameters 
			{
				get 
				{
					return context.GetCollection<Catalog.Outlet_Parameters>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Territory> Territory 
			{
				get 
				{
					return context.GetCollection<Catalog.Territory>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Catalog.Territory_Outlets> Territory_Outlets 
			{
				get 
				{
					return context.GetCollection<Catalog.Territory_Outlets>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Catalog.Territory_SKUGroups> Territory_SKUGroups 
			{
				get 
				{
					return context.GetCollection<Catalog.Territory_SKUGroups>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Catalog.QuestionGroup> QuestionGroup 
			{
				get 
				{
					return context.GetCollection<Catalog.QuestionGroup>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Question> Question 
			{
				get 
				{
					return context.GetCollection<Catalog.Question>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Catalog.Question_ValueList> Question_ValueList 
			{
				get 
				{
					return context.GetCollection<Catalog.Question_ValueList>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Catalog.SKUGroup> SKUGroup 
			{
				get 
				{
					return context.GetCollection<Catalog.SKUGroup>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.Brands> Brands 
			{
				get 
				{
					return context.GetCollection<Catalog.Brands>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.UnitsOfMeasure> UnitsOfMeasure 
			{
				get 
				{
					return context.GetCollection<Catalog.UnitsOfMeasure>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<Catalog.SKU> SKU 
			{
				get 
				{
					return context.GetCollection<Catalog.SKU>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Catalog.SKU_Packing> SKU_Packing 
			{
				get 
				{
					return context.GetCollection<Catalog.SKU_Packing>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Catalog.SKUQuestions> SKUQuestions 
			{
				get 
				{
					return context.GetCollection<Catalog.SKUQuestions>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Catalog.SKUQuestions_ValueList> SKUQuestions_ValueList 
			{
				get 
				{
					return context.GetCollection<Catalog.SKUQuestions_ValueList>();
				}
			}
			
			
					}

	}

	 
	namespace Document 
	{
		 
		
		[System.Serializable]
		public partial class PriceList : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			public static PriceList CreateInstance(OfflineContext dao)
            {
                PriceList entity = new PriceList();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<PriceList>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.PriceList_Prices> Prices(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.PriceList_Prices> result = new System.Collections.Generic.List<Document.PriceList_Prices>();
				System.Collections.Generic.IEnumerable<Document.PriceList_Prices> items = context.GetCollection<Document.PriceList_Prices>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class PriceList_Prices : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public PriceList RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.PriceList)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKU;		

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					base.OnPropertyChanging("SKU");
					_SKU = value;
					base.OnPropertyChanged("SKU");
				}
			}

						public Catalog.SKU SKUAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKU)
                    if (item.Id.Equals(_SKU))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKU.ToString()));
				return null;
			}
			
			
			
			private decimal _Price;		

						public decimal Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					base.OnPropertyChanging("Price");
					_Price = value;
					base.OnPropertyChanged("Price");
				}
			}

			
			
			
			private System.Nullable<decimal> _Stock;		

						public System.Nullable<decimal> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					base.OnPropertyChanging("Stock");
					_Stock = value;
					base.OnPropertyChanged("Stock");
				}
			}

			
			
			
			public static PriceList_Prices CreateInstance(OfflineContext dao)
            {
                PriceList_Prices entity = new PriceList_Prices();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<PriceList_Prices>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Questionnaire : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private Guid _OutletType;		

						public Guid OutletType 
			{
				get 
				{
					return _OutletType;
				}
				set 
				{
					base.OnPropertyChanging("OutletType");
					_OutletType = value;
					base.OnPropertyChanged("OutletType");
				}
			}

						public Catalog.OutletType OutletTypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletType)
                    if (item.Id.Equals(_OutletType))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _OutletType.ToString()));
				return null;
			}
			
			
			
			private Guid _OutletClass;		

						public Guid OutletClass 
			{
				get 
				{
					return _OutletClass;
				}
				set 
				{
					base.OnPropertyChanging("OutletClass");
					_OutletClass = value;
					base.OnPropertyChanged("OutletClass");
				}
			}

						public Catalog.OutletClass OutletClassAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletClass)
                    if (item.Id.Equals(_OutletClass))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _OutletClass.ToString()));
				return null;
			}
			
			
			
			public static Questionnaire CreateInstance(OfflineContext dao)
            {
                Questionnaire entity = new Questionnaire();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_Questions> Questions(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Questionnaire_Questions> result = new System.Collections.Generic.List<Document.Questionnaire_Questions>();
				System.Collections.Generic.IEnumerable<Document.Questionnaire_Questions> items = context.GetCollection<Document.Questionnaire_Questions>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUs> SKUs(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Questionnaire_SKUs> result = new System.Collections.Generic.List<Document.Questionnaire_SKUs>();
				System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUs> items = context.GetCollection<Document.Questionnaire_SKUs>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUGroups> SKUGroups(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Questionnaire_SKUGroups> result = new System.Collections.Generic.List<Document.Questionnaire_SKUGroups>();
				System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUGroups> items = context.GetCollection<Document.Questionnaire_SKUGroups>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUQuestions> SKUQuestions(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Questionnaire_SKUQuestions> result = new System.Collections.Generic.List<Document.Questionnaire_SKUQuestions>();
				System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUQuestions> items = context.GetCollection<Document.Questionnaire_SKUQuestions>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_Territories> Territories(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Questionnaire_Territories> result = new System.Collections.Generic.List<Document.Questionnaire_Territories>();
				System.Collections.Generic.IEnumerable<Document.Questionnaire_Territories> items = context.GetCollection<Document.Questionnaire_Territories>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Questionnaire_Questions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Questionnaire RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Questionnaire)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Question;		

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					base.OnPropertyChanging("Question");
					_Question = value;
					base.OnPropertyChanged("Question");
				}
			}

						public Catalog.Question QuestionAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Question)
                    if (item.Id.Equals(_Question))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Question.ToString()));
				return null;
			}
			
			
			
			public static Questionnaire_Questions CreateInstance(OfflineContext dao)
            {
                Questionnaire_Questions entity = new Questionnaire_Questions();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire_Questions>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Questionnaire_SKUs : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Questionnaire RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Questionnaire)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKU;		

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					base.OnPropertyChanging("SKU");
					_SKU = value;
					base.OnPropertyChanged("SKU");
				}
			}

						public Catalog.SKU SKUAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKU)
                    if (item.Id.Equals(_SKU))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKU.ToString()));
				return null;
			}
			
			
			
			public static Questionnaire_SKUs CreateInstance(OfflineContext dao)
            {
                Questionnaire_SKUs entity = new Questionnaire_SKUs();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire_SKUs>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Questionnaire_SKUGroups : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Questionnaire RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Questionnaire)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKUGroup;		

						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					base.OnPropertyChanging("SKUGroup");
					_SKUGroup = value;
					base.OnPropertyChanged("SKUGroup");
				}
			}

						public Catalog.SKUGroup SKUGroupAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUGroup)
                    if (item.Id.Equals(_SKUGroup))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKUGroup.ToString()));
				return null;
			}
			
			
			
			public static Questionnaire_SKUGroups CreateInstance(OfflineContext dao)
            {
                Questionnaire_SKUGroups entity = new Questionnaire_SKUGroups();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire_SKUGroups>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Questionnaire_SKUQuestions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Questionnaire RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Questionnaire)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKUQuestion;		

						public Guid SKUQuestion 
			{
				get 
				{
					return _SKUQuestion;
				}
				set 
				{
					base.OnPropertyChanging("SKUQuestion");
					_SKUQuestion = value;
					base.OnPropertyChanged("SKUQuestion");
				}
			}

						public Catalog.SKUQuestions SKUQuestionAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUQuestions)
                    if (item.Id.Equals(_SKUQuestion))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKUQuestion.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<bool> _UseInQuestionaire;		

						public System.Nullable<bool> UseInQuestionaire 
			{
				get 
				{
					return _UseInQuestionaire;
				}
				set 
				{
					base.OnPropertyChanging("UseInQuestionaire");
					_UseInQuestionaire = value;
					base.OnPropertyChanged("UseInQuestionaire");
				}
			}

			
			
			
			public static Questionnaire_SKUQuestions CreateInstance(OfflineContext dao)
            {
                Questionnaire_SKUQuestions entity = new Questionnaire_SKUQuestions();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire_SKUQuestions>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Questionnaire_Territories : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Questionnaire RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Questionnaire)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Territory;		

						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					base.OnPropertyChanging("Territory");
					_Territory = value;
					base.OnPropertyChanged("Territory");
				}
			}

						public Catalog.Territory TerritoryAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Territory)
                    if (item.Id.Equals(_Territory))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Territory.ToString()));
				return null;
			}
			
			
			
			public static Questionnaire_Territories CreateInstance(OfflineContext dao)
            {
                Questionnaire_Territories entity = new Questionnaire_Territories();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Questionnaire_Territories>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Target : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private Guid _Territory;		

						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					base.OnPropertyChanging("Territory");
					_Territory = value;
					base.OnPropertyChanged("Territory");
				}
			}

						public Catalog.Territory TerritoryAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Territory)
                    if (item.Id.Equals(_Territory))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Territory.ToString()));
				return null;
			}
			
			
			
			private Guid _OutletType;		

						public Guid OutletType 
			{
				get 
				{
					return _OutletType;
				}
				set 
				{
					base.OnPropertyChanging("OutletType");
					_OutletType = value;
					base.OnPropertyChanged("OutletType");
				}
			}

						public Catalog.OutletType OutletTypeAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletType)
                    if (item.Id.Equals(_OutletType))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _OutletType.ToString()));
				return null;
			}
			
			
			
			private Guid _OutletClass;		

						public Guid OutletClass 
			{
				get 
				{
					return _OutletClass;
				}
				set 
				{
					base.OnPropertyChanging("OutletClass");
					_OutletClass = value;
					base.OnPropertyChanged("OutletClass");
				}
			}

						public Catalog.OutletClass OutletClassAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.OutletClass)
                    if (item.Id.Equals(_OutletClass))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _OutletClass.ToString()));
				return null;
			}
			
			
			
			public static Target CreateInstance(OfflineContext dao)
            {
                Target entity = new Target();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Target>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.Target_Targets> Targets(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Target_Targets> result = new System.Collections.Generic.List<Document.Target_Targets>();
				System.Collections.Generic.IEnumerable<Document.Target_Targets> items = context.GetCollection<Document.Target_Targets>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Target_Targets : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Target RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Target)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Question;		

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					base.OnPropertyChanging("Question");
					_Question = value;
					base.OnPropertyChanged("Question");
				}
			}

						public Catalog.Question QuestionAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Question)
                    if (item.Id.Equals(_Question))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Question.ToString()));
				return null;
			}
			
			
			
			private decimal _Value;		

						public decimal Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					base.OnPropertyChanging("Value");
					_Value = value;
					base.OnPropertyChanged("Value");
				}
			}

			
			
			
			public static Target_Targets CreateInstance(OfflineContext dao)
            {
                Target_Targets entity = new Target_Targets();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Target_Targets>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class VisitPlan : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private DateTime _Year;		

						public DateTime Year 
			{
				get 
				{
					return _Year;
				}
				set 
				{
					base.OnPropertyChanging("Year");
					_Year = value;
					base.OnPropertyChanged("Year");
				}
			}

			
			
			
			private int _WeekNumber;		

						public int WeekNumber 
			{
				get 
				{
					return _WeekNumber;
				}
				set 
				{
					base.OnPropertyChanging("WeekNumber");
					_WeekNumber = value;
					base.OnPropertyChanged("WeekNumber");
				}
			}

			
			
			
			private Guid _SR;		

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					base.OnPropertyChanging("SR");
					_SR = value;
					base.OnPropertyChanged("SR");
				}
			}

						public Catalog.User SRAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_SR))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SR.ToString()));
				return null;
			}
			
			
			
			private Guid _Owner;		

						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					base.OnPropertyChanging("Owner");
					_Owner = value;
					base.OnPropertyChanged("Owner");
				}
			}

						public Catalog.User OwnerAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_Owner))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Owner.ToString()));
				return null;
			}
			
			
			
			private DateTime _DateFrom;		

						public DateTime DateFrom 
			{
				get 
				{
					return _DateFrom;
				}
				set 
				{
					base.OnPropertyChanging("DateFrom");
					_DateFrom = value;
					base.OnPropertyChanged("DateFrom");
				}
			}

			
			
			
			private DateTime _DateTo;		

						public DateTime DateTo 
			{
				get 
				{
					return _DateTo;
				}
				set 
				{
					base.OnPropertyChanging("DateTo");
					_DateTo = value;
					base.OnPropertyChanged("DateTo");
				}
			}

			
			
			
			public static VisitPlan CreateInstance(OfflineContext dao)
            {
                VisitPlan entity = new VisitPlan();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<VisitPlan>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.VisitPlan_Outlets> Outlets(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.VisitPlan_Outlets> result = new System.Collections.Generic.List<Document.VisitPlan_Outlets>();
				System.Collections.Generic.IEnumerable<Document.VisitPlan_Outlets> items = context.GetCollection<Document.VisitPlan_Outlets>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class VisitPlan_Outlets : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public VisitPlan RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.VisitPlan)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Outlet;		

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					base.OnPropertyChanging("Outlet");
					_Outlet = value;
					base.OnPropertyChanged("Outlet");
				}
			}

						public Catalog.Outlet OutletAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Outlet))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Outlet.ToString()));
				return null;
			}
			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			public static VisitPlan_Outlets CreateInstance(OfflineContext dao)
            {
                VisitPlan_Outlets entity = new VisitPlan_Outlets();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<VisitPlan_Outlets>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Visit : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private Guid _Outlet;		

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					base.OnPropertyChanging("Outlet");
					_Outlet = value;
					base.OnPropertyChanged("Outlet");
				}
			}

						public Catalog.Outlet OutletAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Outlet))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Outlet.ToString()));
				return null;
			}
			
			
			
			private Guid _SR;		

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					base.OnPropertyChanging("SR");
					_SR = value;
					base.OnPropertyChanged("SR");
				}
			}

						public Catalog.User SRAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_SR))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SR.ToString()));
				return null;
			}
			
			
			
			private Guid _Status;		

						public Guid Status 
			{
				get 
				{
					return _Status;
				}
				set 
				{
					base.OnPropertyChanging("Status");
					_Status = value;
					base.OnPropertyChanged("Status");
				}
			}

						public Enum.VisitStatus StatusAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.VisitStatus)
                    if (item.Id.Equals(_Status))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Status.ToString()));
				return null;
			}
			
			
			
			private DateTime _StartTime;		

						public DateTime StartTime 
			{
				get 
				{
					return _StartTime;
				}
				set 
				{
					base.OnPropertyChanging("StartTime");
					_StartTime = value;
					base.OnPropertyChanged("StartTime");
				}
			}

			
			
			
			private System.Nullable<DateTime> _EndTime;		

						public System.Nullable<DateTime> EndTime 
			{
				get 
				{
					return _EndTime;
				}
				set 
				{
					base.OnPropertyChanging("EndTime");
					_EndTime = value;
					base.OnPropertyChanged("EndTime");
				}
			}

			
			
			
			private decimal _Encashment;		

						public decimal Encashment 
			{
				get 
				{
					return _Encashment;
				}
				set 
				{
					base.OnPropertyChanging("Encashment");
					_Encashment = value;
					base.OnPropertyChanged("Encashment");
				}
			}

			
			
			
			private Guid _Plan;		

						public Guid Plan 
			{
				get 
				{
					return _Plan;
				}
				set 
				{
					base.OnPropertyChanging("Plan");
					_Plan = value;
					base.OnPropertyChanged("Plan");
				}
			}

						public Document.VisitPlan PlanAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.VisitPlan)
                    if (item.Id.Equals(_Plan))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Plan.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<decimal> _Lattitude;		

						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					base.OnPropertyChanging("Lattitude");
					_Lattitude = value;
					base.OnPropertyChanged("Lattitude");
				}
			}

			
			
			
			private System.Nullable<decimal> _Longitude;		

						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					base.OnPropertyChanging("Longitude");
					_Longitude = value;
					base.OnPropertyChanged("Longitude");
				}
			}

			
			
			
			public static Visit CreateInstance(OfflineContext dao)
            {
                Visit entity = new Visit();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Visit>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.Visit_Questions> Questions(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Visit_Questions> result = new System.Collections.Generic.List<Document.Visit_Questions>();
				System.Collections.Generic.IEnumerable<Document.Visit_Questions> items = context.GetCollection<Document.Visit_Questions>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Visit_SKUs> SKUs(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Visit_SKUs> result = new System.Collections.Generic.List<Document.Visit_SKUs>();
				System.Collections.Generic.IEnumerable<Document.Visit_SKUs> items = context.GetCollection<Document.Visit_SKUs>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Visit_SKUGroups> SKUGroups(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Visit_SKUGroups> result = new System.Collections.Generic.List<Document.Visit_SKUGroups>();
				System.Collections.Generic.IEnumerable<Document.Visit_SKUGroups> items = context.GetCollection<Document.Visit_SKUGroups>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

						
			public System.Collections.Generic.IEnumerable<Document.Visit_Task> Task(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Visit_Task> result = new System.Collections.Generic.List<Document.Visit_Task>();
				System.Collections.Generic.IEnumerable<Document.Visit_Task> items = context.GetCollection<Document.Visit_Task>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Visit_Questions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Visit RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Visit)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _Question;		

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					base.OnPropertyChanging("Question");
					_Question = value;
					base.OnPropertyChanged("Question");
				}
			}

						public Catalog.Question QuestionAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Question)
                    if (item.Id.Equals(_Question))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Question.ToString()));
				return null;
			}
			
			
			
			private String _Answer;		

						public String Answer 
			{
				get 
				{
					return _Answer;
				}
				set 
				{
					base.OnPropertyChanging("Answer");
					_Answer = value;
					base.OnPropertyChanged("Answer");
				}
			}

			
			
			
			public static Visit_Questions CreateInstance(OfflineContext dao)
            {
                Visit_Questions entity = new Visit_Questions();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Visit_Questions>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Visit_SKUs : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Visit RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Visit)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKU;		

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					base.OnPropertyChanging("SKU");
					_SKU = value;
					base.OnPropertyChanged("SKU");
				}
			}

						public Catalog.SKU SKUAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKU)
                    if (item.Id.Equals(_SKU))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKU.ToString()));
				return null;
			}
			
			
			
			private bool _Available;		

						public bool Available 
			{
				get 
				{
					return _Available;
				}
				set 
				{
					base.OnPropertyChanging("Available");
					_Available = value;
					base.OnPropertyChanged("Available");
				}
			}

			
			
			
			private System.Nullable<int> _Facing;		

						public System.Nullable<int> Facing 
			{
				get 
				{
					return _Facing;
				}
				set 
				{
					base.OnPropertyChanging("Facing");
					_Facing = value;
					base.OnPropertyChanged("Facing");
				}
			}

			
			
			
			private System.Nullable<int> _Stock;		

						public System.Nullable<int> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					base.OnPropertyChanging("Stock");
					_Stock = value;
					base.OnPropertyChanged("Stock");
				}
			}

			
			
			
			private System.Nullable<int> _Price;		

						public System.Nullable<int> Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					base.OnPropertyChanging("Price");
					_Price = value;
					base.OnPropertyChanged("Price");
				}
			}

			
			
			
			private System.Nullable<int> _MarkUp;		

						public System.Nullable<int> MarkUp 
			{
				get 
				{
					return _MarkUp;
				}
				set 
				{
					base.OnPropertyChanging("MarkUp");
					_MarkUp = value;
					base.OnPropertyChanged("MarkUp");
				}
			}

			
			
			
			private bool _OutOfStock;		

						public bool OutOfStock 
			{
				get 
				{
					return _OutOfStock;
				}
				set 
				{
					base.OnPropertyChanging("OutOfStock");
					_OutOfStock = value;
					base.OnPropertyChanged("OutOfStock");
				}
			}

			
			
			
			public static Visit_SKUs CreateInstance(OfflineContext dao)
            {
                Visit_SKUs entity = new Visit_SKUs();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Visit_SKUs>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Visit_SKUGroups : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Visit RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Visit)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKUGroup;		

						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					base.OnPropertyChanging("SKUGroup");
					_SKUGroup = value;
					base.OnPropertyChanged("SKUGroup");
				}
			}

						public Catalog.SKUGroup SKUGroupAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKUGroup)
                    if (item.Id.Equals(_SKUGroup))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKUGroup.ToString()));
				return null;
			}
			
			
			
			private bool _Available;		

						public bool Available 
			{
				get 
				{
					return _Available;
				}
				set 
				{
					base.OnPropertyChanging("Available");
					_Available = value;
					base.OnPropertyChanged("Available");
				}
			}

			
			
			
			public static Visit_SKUGroups CreateInstance(OfflineContext dao)
            {
                Visit_SKUGroups entity = new Visit_SKUGroups();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Visit_SKUGroups>(entity);
                return entity;
            }
		}

		 

		[System.Serializable]
		public partial class Visit_Task : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Visit RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Visit)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private String _TextTask;		

						public String TextTask 
			{
				get 
				{
					return _TextTask;
				}
				set 
				{
					base.OnPropertyChanging("TextTask");
					_TextTask = value;
					base.OnPropertyChanged("TextTask");
				}
			}

			
			
			
			private String _Result;		

						public String Result 
			{
				get 
				{
					return _Result;
				}
				set 
				{
					base.OnPropertyChanging("Result");
					_Result = value;
					base.OnPropertyChanged("Result");
				}
			}

			
			
			
			private Guid _TaskRef;		

						public Guid TaskRef 
			{
				get 
				{
					return _TaskRef;
				}
				set 
				{
					base.OnPropertyChanging("TaskRef");
					_TaskRef = value;
					base.OnPropertyChanged("TaskRef");
				}
			}

						public Document.Task TaskRefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Task)
                    if (item.Id.Equals(_TaskRef))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _TaskRef.ToString()));
				return null;
			}
			
			
			
			public static Visit_Task CreateInstance(OfflineContext dao)
            {
                Visit_Task entity = new Visit_Task();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Visit_Task>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Order : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private Guid _Outlet;		

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					base.OnPropertyChanging("Outlet");
					_Outlet = value;
					base.OnPropertyChanged("Outlet");
				}
			}

						public Catalog.Outlet OutletAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Outlet))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Outlet.ToString()));
				return null;
			}
			
			
			
			private Guid _SR;		

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					base.OnPropertyChanging("SR");
					_SR = value;
					base.OnPropertyChanged("SR");
				}
			}

						public Catalog.User SRAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.User)
                    if (item.Id.Equals(_SR))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SR.ToString()));
				return null;
			}
			
			
			
			private DateTime _DeliveryDate;		

						public DateTime DeliveryDate 
			{
				get 
				{
					return _DeliveryDate;
				}
				set 
				{
					base.OnPropertyChanging("DeliveryDate");
					_DeliveryDate = value;
					base.OnPropertyChanged("DeliveryDate");
				}
			}

			
			
			
			private String _Commentary;		

						public String Commentary 
			{
				get 
				{
					return _Commentary;
				}
				set 
				{
					base.OnPropertyChanging("Commentary");
					_Commentary = value;
					base.OnPropertyChanged("Commentary");
				}
			}

			
			
			
			private Guid _Visit;		

						public Guid Visit 
			{
				get 
				{
					return _Visit;
				}
				set 
				{
					base.OnPropertyChanging("Visit");
					_Visit = value;
					base.OnPropertyChanged("Visit");
				}
			}

						public Document.Visit VisitAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Visit)
                    if (item.Id.Equals(_Visit))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Visit.ToString()));
				return null;
			}
			
			
			
			private System.Nullable<decimal> _Lattitude;		

						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					base.OnPropertyChanging("Lattitude");
					_Lattitude = value;
					base.OnPropertyChanged("Lattitude");
				}
			}

			
			
			
			private System.Nullable<decimal> _Longitude;		

						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					base.OnPropertyChanging("Longitude");
					_Longitude = value;
					base.OnPropertyChanged("Longitude");
				}
			}

			
			
			
			private Guid _Status;		

						public Guid Status 
			{
				get 
				{
					return _Status;
				}
				set 
				{
					base.OnPropertyChanging("Status");
					_Status = value;
					base.OnPropertyChanged("Status");
				}
			}

						public Enum.OrderSatus StatusAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.OrderSatus)
                    if (item.Id.Equals(_Status))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Status.ToString()));
				return null;
			}
			
			
			
			public static Order CreateInstance(OfflineContext dao)
            {
                Order entity = new Order();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Order>(entity);
                return entity;
            }

						
			public System.Collections.Generic.IEnumerable<Document.Order_SKUs> SKUs(OfflineContext context) 
			{
				System.Collections.Generic.List<Document.Order_SKUs> result = new System.Collections.Generic.List<Document.Order_SKUs>();
				System.Collections.Generic.IEnumerable<Document.Order_SKUs> items = context.GetCollection<Document.Order_SKUs>();
				foreach(var item in items)
				{
					if(item.Ref.Equals(this.Id))
						result.Add(item);
				}
				return result;
			}

					}

		 

		[System.Serializable]
		public partial class Order_SKUs : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			public Order RefAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.Order)
                    if (item.Id.Equals(_Ref))
                        return item;
				return null;
			}

			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private Guid _Ref;		

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					base.OnPropertyChanging("Ref");
					_Ref = value;
					base.OnPropertyChanged("Ref");
				}
			}

			
			
			
			private int _LineNumber;		

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					base.OnPropertyChanging("LineNumber");
					_LineNumber = value;
					base.OnPropertyChanged("LineNumber");
				}
			}

			
			
			
			private Guid _SKU;		

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					base.OnPropertyChanging("SKU");
					_SKU = value;
					base.OnPropertyChanged("SKU");
				}
			}

						public Catalog.SKU SKUAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.SKU)
                    if (item.Id.Equals(_SKU))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _SKU.ToString()));
				return null;
			}
			
			
			
			private decimal _Qty;		

						public decimal Qty 
			{
				get 
				{
					return _Qty;
				}
				set 
				{
					base.OnPropertyChanging("Qty");
					_Qty = value;
					base.OnPropertyChanged("Qty");
				}
			}

			
			
			
			private decimal _Price;		

						public decimal Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					base.OnPropertyChanging("Price");
					_Price = value;
					base.OnPropertyChanged("Price");
				}
			}

			
			
			
			private int _Discount;		

						public int Discount 
			{
				get 
				{
					return _Discount;
				}
				set 
				{
					base.OnPropertyChanging("Discount");
					_Discount = value;
					base.OnPropertyChanged("Discount");
				}
			}

			
			
			
			private decimal _Total;		

						public decimal Total 
			{
				get 
				{
					return _Total;
				}
				set 
				{
					base.OnPropertyChanging("Total");
					_Total = value;
					base.OnPropertyChanged("Total");
				}
			}

			
			
			
			private decimal _Amount;		

						public decimal Amount 
			{
				get 
				{
					return _Amount;
				}
				set 
				{
					base.OnPropertyChanging("Amount");
					_Amount = value;
					base.OnPropertyChanged("Amount");
				}
			}

			
			
			
			private Guid _Units;		

						public Guid Units 
			{
				get 
				{
					return _Units;
				}
				set 
				{
					base.OnPropertyChanging("Units");
					_Units = value;
					base.OnPropertyChanged("Units");
				}
			}

						public Catalog.UnitsOfMeasure UnitsAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.UnitsOfMeasure)
                    if (item.Id.Equals(_Units))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Units.ToString()));
				return null;
			}
			
			
			
			public static Order_SKUs CreateInstance(OfflineContext dao)
            {
                Order_SKUs entity = new Order_SKUs();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Order_SKUs>(entity);
                return entity;
            }
		}

		        
		 
		
		[System.Serializable]
		public partial class Task : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Number;		

						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					base.OnPropertyChanging("Number");
					_Number = value;
					base.OnPropertyChanged("Number");
				}
			}

			
			
			
			private DateTime _Date;		

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					base.OnPropertyChanging("Date");
					_Date = value;
					base.OnPropertyChanged("Date");
				}
			}

			
			
			
			private System.Nullable<bool> _Posted;		

						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					base.OnPropertyChanging("Posted");
					_Posted = value;
					base.OnPropertyChanged("Posted");
				}
			}

			
			
			
			private Guid _Territory;		

						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					base.OnPropertyChanging("Territory");
					_Territory = value;
					base.OnPropertyChanged("Territory");
				}
			}

						public Catalog.Territory TerritoryAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Territory)
                    if (item.Id.Equals(_Territory))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Territory.ToString()));
				return null;
			}
			
			
			
			private Guid _Outlet;		

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					base.OnPropertyChanging("Outlet");
					_Outlet = value;
					base.OnPropertyChanged("Outlet");
				}
			}

						public Catalog.Outlet OutletAsObject(OfflineContext context)
			{
			    foreach (var item in context.Catalog.Outlet)
                    if (item.Id.Equals(_Outlet))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _Outlet.ToString()));
				return null;
			}
			
			
			
			private Guid _StatusTask;		

						public Guid StatusTask 
			{
				get 
				{
					return _StatusTask;
				}
				set 
				{
					base.OnPropertyChanging("StatusTask");
					_StatusTask = value;
					base.OnPropertyChanged("StatusTask");
				}
			}

						public Enum.StatusTask StatusTaskAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.StatusTask)
                    if (item.Id.Equals(_StatusTask))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _StatusTask.ToString()));
				return null;
			}
			
			
			
			private String _TextTask;		

						public String TextTask 
			{
				get 
				{
					return _TextTask;
				}
				set 
				{
					base.OnPropertyChanging("TextTask");
					_TextTask = value;
					base.OnPropertyChanged("TextTask");
				}
			}

			
			
			
			private Guid _VisitPlan;		

						public Guid VisitPlan 
			{
				get 
				{
					return _VisitPlan;
				}
				set 
				{
					base.OnPropertyChanging("VisitPlan");
					_VisitPlan = value;
					base.OnPropertyChanged("VisitPlan");
				}
			}

						public Document.VisitPlan VisitPlanAsObject(OfflineContext context)
			{
			    foreach (var item in context.Document.VisitPlan)
                    if (item.Id.Equals(_VisitPlan))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _VisitPlan.ToString()));
				return null;
			}
			
			
			
			private DateTime _PlanDate;		

						public DateTime PlanDate 
			{
				get 
				{
					return _PlanDate;
				}
				set 
				{
					base.OnPropertyChanging("PlanDate");
					_PlanDate = value;
					base.OnPropertyChanged("PlanDate");
				}
			}

			
			
			
			private Guid _TypeOfResultAndGoals;		

						public Guid TypeOfResultAndGoals 
			{
				get 
				{
					return _TypeOfResultAndGoals;
				}
				set 
				{
					base.OnPropertyChanging("TypeOfResultAndGoals");
					_TypeOfResultAndGoals = value;
					base.OnPropertyChanged("TypeOfResultAndGoals");
				}
			}

						public Enum.DataType TypeOfResultAndGoalsAsObject(OfflineContext context)
			{
			    foreach (var item in context.Enum.DataType)
                    if (item.Id.Equals(_TypeOfResultAndGoals))
                        return item;
                //throw new Exception(String.Format("Object {0} not found", _TypeOfResultAndGoals.ToString()));
				return null;
			}
			
			
			
			private String _Result;		

						public String Result 
			{
				get 
				{
					return _Result;
				}
				set 
				{
					base.OnPropertyChanging("Result");
					_Result = value;
					base.OnPropertyChanged("Result");
				}
			}

			
			
			
			private System.Nullable<DateTime> _FactDate;		

						public System.Nullable<DateTime> FactDate 
			{
				get 
				{
					return _FactDate;
				}
				set 
				{
					base.OnPropertyChanging("FactDate");
					_FactDate = value;
					base.OnPropertyChanged("FactDate");
				}
			}

			
			
			
			private String _Target;		

						public String Target 
			{
				get 
				{
					return _Target;
				}
				set 
				{
					base.OnPropertyChanging("Target");
					_Target = value;
					base.OnPropertyChanged("Target");
				}
			}

			
			
			
			public static Task CreateInstance(OfflineContext dao)
            {
                Task entity = new Task();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Task>(entity);
                return entity;
            }

					}

		        
		
		public class Collections
		{
			private OfflineContext context;

			public Collections(OfflineContext context)
			{
				this.context = context;
			}

			 

			public System.Collections.Generic.IEnumerable<Document.PriceList> PriceList 
			{
				get 
				{
					return context.GetCollection<Document.PriceList>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.PriceList_Prices> PriceList_Prices 
			{
				get 
				{
					return context.GetCollection<Document.PriceList_Prices>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.Questionnaire> Questionnaire 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_Questions> Questionnaire_Questions 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire_Questions>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUs> Questionnaire_SKUs 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire_SKUs>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUGroups> Questionnaire_SKUGroups 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire_SKUGroups>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_SKUQuestions> Questionnaire_SKUQuestions 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire_SKUQuestions>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Questionnaire_Territories> Questionnaire_Territories 
			{
				get 
				{
					return context.GetCollection<Document.Questionnaire_Territories>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.Target> Target 
			{
				get 
				{
					return context.GetCollection<Document.Target>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.Target_Targets> Target_Targets 
			{
				get 
				{
					return context.GetCollection<Document.Target_Targets>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.VisitPlan> VisitPlan 
			{
				get 
				{
					return context.GetCollection<Document.VisitPlan>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.VisitPlan_Outlets> VisitPlan_Outlets 
			{
				get 
				{
					return context.GetCollection<Document.VisitPlan_Outlets>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.Visit> Visit 
			{
				get 
				{
					return context.GetCollection<Document.Visit>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.Visit_Questions> Visit_Questions 
			{
				get 
				{
					return context.GetCollection<Document.Visit_Questions>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Visit_SKUs> Visit_SKUs 
			{
				get 
				{
					return context.GetCollection<Document.Visit_SKUs>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Visit_SKUGroups> Visit_SKUGroups 
			{
				get 
				{
					return context.GetCollection<Document.Visit_SKUGroups>();
				}
			}
			
			 
			
			public System.Collections.Generic.IEnumerable<Document.Visit_Task> Visit_Task 
			{
				get 
				{
					return context.GetCollection<Document.Visit_Task>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.Order> Order 
			{
				get 
				{
					return context.GetCollection<Document.Order>();
				}
			}


			 
			
			public System.Collections.Generic.IEnumerable<Document.Order_SKUs> Order_SKUs 
			{
				get 
				{
					return context.GetCollection<Document.Order_SKUs>();
				}
			}
			
			
			 

			public System.Collections.Generic.IEnumerable<Document.Task> Task 
			{
				get 
				{
					return context.GetCollection<Document.Task>();
				}
			}


			
					}

	}

	 
	namespace resource 
	{
		 
		
		[System.Serializable]
		public partial class BusinessProcess : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static BusinessProcess CreateInstance(OfflineContext dao)
            {
                BusinessProcess entity = new BusinessProcess();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<BusinessProcess>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Image : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static Image CreateInstance(OfflineContext dao)
            {
                Image entity = new Image();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Image>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Screen : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static Screen CreateInstance(OfflineContext dao)
            {
                Screen entity = new Screen();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Screen>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Script : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static Script CreateInstance(OfflineContext dao)
            {
                Script entity = new Script();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Script>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Style : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static Style CreateInstance(OfflineContext dao)
            {
                Style entity = new Style();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Style>(entity);
                return entity;
            }

					}

		        
		 
		
		[System.Serializable]
		public partial class Translation : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Data;		

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					base.OnPropertyChanging("Data");
					_Data = value;
					base.OnPropertyChanged("Data");
				}
			}

			
						public System.IO.Stream DataAsStream(OfflineContext context)
			{
				return new System.IO.MemoryStream(System.Convert.FromBase64String(_Data));
			}
			
			
			private String _Parent;		

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					base.OnPropertyChanging("Parent");
					_Parent = value;
					base.OnPropertyChanged("Parent");
				}
			}

			
			
			
			public static Translation CreateInstance(OfflineContext dao)
            {
                Translation entity = new Translation();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Translation>(entity);
                return entity;
            }

					}

		        
		
		public class Collections
		{
			private OfflineContext context;

			public Collections(OfflineContext context)
			{
				this.context = context;
			}

			 

			public System.Collections.Generic.IEnumerable<resource.BusinessProcess> BusinessProcess 
			{
				get 
				{
					return context.GetCollection<resource.BusinessProcess>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<resource.Image> Image 
			{
				get 
				{
					return context.GetCollection<resource.Image>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<resource.Screen> Screen 
			{
				get 
				{
					return context.GetCollection<resource.Screen>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<resource.Script> Script 
			{
				get 
				{
					return context.GetCollection<resource.Script>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<resource.Style> Style 
			{
				get 
				{
					return context.GetCollection<resource.Style>();
				}
			}


			
			 

			public System.Collections.Generic.IEnumerable<resource.Translation> Translation 
			{
				get 
				{
					return context.GetCollection<resource.Translation>();
				}
			}


			
					}

	}

	 
	namespace admin 
	{
		 
		
		[System.Serializable]
		public partial class Entity : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			
			private Guid _Id;		

						[System.ComponentModel.DataAnnotations.KeyAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					base.OnPropertyChanging("Id");
					_Id = value;
					base.OnPropertyChanged("Id");
				}
			}

			
			
			
			private String _Name;		

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					base.OnPropertyChanging("Name");
					_Name = value;
					base.OnPropertyChanged("Name");
				}
			}

			
			
			
			private String _Schema;		

						public String Schema 
			{
				get 
				{
					return _Schema;
				}
				set 
				{
					base.OnPropertyChanging("Schema");
					_Schema = value;
					base.OnPropertyChanged("Schema");
				}
			}

			
			
			
			private String _ShortName;		

						public String ShortName 
			{
				get 
				{
					return _ShortName;
				}
				set 
				{
					base.OnPropertyChanging("ShortName");
					_ShortName = value;
					base.OnPropertyChanged("ShortName");
				}
			}

			
			
			
			public static Entity CreateInstance(OfflineContext dao)
            {
                Entity entity = new Entity();
				//entity.Init();
                entity.Id = System.Guid.NewGuid();
                dao.AddItem<Entity>(entity);
                return entity;
            }

					}

		        
		
		public class Collections
		{
			private OfflineContext context;

			public Collections(OfflineContext context)
			{
				this.context = context;
			}

			 

			public System.Collections.Generic.IEnumerable<admin.Entity> Entity 
			{
				get 
				{
					return context.GetCollection<admin.Entity>();
				}
			}


			
					}

	}

	
	public class OfflineContext : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineContext 
	{    
        public const string SyncScopeName = "DefaultScope";
        
        public OfflineContext(string cachePath, System.Uri serviceUri) : 
                base(OfflineContext.GetSchema(), SyncScopeName, cachePath, serviceUri) {
        }
        
        public OfflineContext(string cachePath, System.Uri serviceUri, System.Security.Cryptography.SymmetricAlgorithm symmAlgorithm) : 
                base(OfflineContext.GetSchema(), SyncScopeName, cachePath, serviceUri, symmAlgorithm) {
        }

		 
		
		private Enum.Collections _Enum;
		public Enum.Collections Enum
        {
            get
            {
                if (_Enum == null)
                    _Enum = new Enum.Collections(this);
                return _Enum;
            }
        }

		 
		
		private Catalog.Collections _Catalog;
		public Catalog.Collections Catalog
        {
            get
            {
                if (_Catalog == null)
                    _Catalog = new Catalog.Collections(this);
                return _Catalog;
            }
        }

		 
		
		private Document.Collections _Document;
		public Document.Collections Document
        {
            get
            {
                if (_Document == null)
                    _Document = new Document.Collections(this);
                return _Document;
            }
        }

		 
		
		private resource.Collections _resource;
		public resource.Collections resource
        {
            get
            {
                if (_resource == null)
                    _resource = new resource.Collections(this);
                return _resource;
            }
        }

		 
		
		private admin.Collections _admin;
		public admin.Collections admin
        {
            get
            {
                if (_admin == null)
                    _admin = new admin.Collections(this);
                return _admin;
            }
        }

		


        private static Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageSchema GetSchema() 
		{
            Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageSchema schema = new Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageSchema();
			            schema.AddCollection<Enum.DataStatus>();

			
			            schema.AddCollection<Enum.DataType>();

			
			            schema.AddCollection<Enum.OutletConfirmationStatus>();

			
			            schema.AddCollection<Enum.TypesOfUsers>();

			
			            schema.AddCollection<Enum.UploadType>();

			
			            schema.AddCollection<Enum.VisitStatus>();

			
			            schema.AddCollection<Enum.StatusTask>();

			
			            schema.AddCollection<Enum.OrderSatus>();

			
			            schema.AddCollection<Catalog.Positions>();

			
			            schema.AddCollection<Catalog.User>();

			
			            schema.AddCollection<Catalog.Region>();

			
			            schema.AddCollection<Catalog.Distributor>();

			
			            schema.AddCollection<Catalog.OutletParameter>();

			
			            schema.AddCollection<Catalog.OutletType>();

			
			            schema.AddCollection<Catalog.OutletClass>();

			
			            schema.AddCollection<Catalog.Outlet>();

			 
            schema.AddCollection<Catalog.Outlet_Parameters>();
			
			            schema.AddCollection<Catalog.Territory>();

			 
            schema.AddCollection<Catalog.Territory_Outlets>();
			 
            schema.AddCollection<Catalog.Territory_SKUGroups>();
			
			            schema.AddCollection<Catalog.QuestionGroup>();

			
			            schema.AddCollection<Catalog.Question>();

			 
            schema.AddCollection<Catalog.Question_ValueList>();
			
			            schema.AddCollection<Catalog.SKUGroup>();

			
			            schema.AddCollection<Catalog.Brands>();

			
			            schema.AddCollection<Catalog.UnitsOfMeasure>();

			
			            schema.AddCollection<Catalog.SKU>();

			 
            schema.AddCollection<Catalog.SKU_Packing>();
			
			            schema.AddCollection<Catalog.SKUQuestions>();

			 
            schema.AddCollection<Catalog.SKUQuestions_ValueList>();
			
			            schema.AddCollection<Document.PriceList>();

			 
            schema.AddCollection<Document.PriceList_Prices>();
			
			            schema.AddCollection<Document.Questionnaire>();

			 
            schema.AddCollection<Document.Questionnaire_Questions>();
			 
            schema.AddCollection<Document.Questionnaire_SKUs>();
			 
            schema.AddCollection<Document.Questionnaire_SKUGroups>();
			 
            schema.AddCollection<Document.Questionnaire_SKUQuestions>();
			 
            schema.AddCollection<Document.Questionnaire_Territories>();
			
			            schema.AddCollection<Document.Target>();

			 
            schema.AddCollection<Document.Target_Targets>();
			
			            schema.AddCollection<Document.VisitPlan>();

			 
            schema.AddCollection<Document.VisitPlan_Outlets>();
			
			            schema.AddCollection<Document.Visit>();

			 
            schema.AddCollection<Document.Visit_Questions>();
			 
            schema.AddCollection<Document.Visit_SKUs>();
			 
            schema.AddCollection<Document.Visit_SKUGroups>();
			 
            schema.AddCollection<Document.Visit_Task>();
			
			            schema.AddCollection<Document.Order>();

			 
            schema.AddCollection<Document.Order_SKUs>();
			
			            schema.AddCollection<Document.Task>();

			
			            schema.AddCollection<resource.BusinessProcess>();

			
			            schema.AddCollection<resource.Image>();

			
			            schema.AddCollection<resource.Screen>();

			
			            schema.AddCollection<resource.Script>();

			
			            schema.AddCollection<resource.Style>();

			
			            schema.AddCollection<resource.Translation>();

			
			            schema.AddCollection<admin.Entity>();

			
			            return schema;
        }
    }

}
