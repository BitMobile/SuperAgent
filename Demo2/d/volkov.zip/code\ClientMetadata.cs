using System;

namespace DefaultScope 
{
	public class Metadata
	{
		private String type;
		private String name;

		public Metadata(String Type, String Name)
		{
			this.type = Type;
			this.name = Name;
		}

		public String Type
		{
			get
			{
				return type;
			}
		}

		public String Name
		{
			get
			{
				return name;
			}
		}

	}


	 
	namespace Enum 
	{
		 

		public partial class DataStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static DataStatusMetadata metadata;

			public static DataStatusMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static DataStatus()
			{
				metadata = new DataStatusMetadata();
			}
		}


		public class DataStatusMetadata
		{
			
			
			
			
			
			
			
			public DataStatusMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class DataType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static DataTypeMetadata metadata;

			public static DataTypeMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static DataType()
			{
				metadata = new DataTypeMetadata();
			}
		}


		public class DataTypeMetadata
		{
			
			
			
			
			
			
			
			public DataTypeMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class OutletConfirmationStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OutletConfirmationStatusMetadata metadata;

			public static OutletConfirmationStatusMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static OutletConfirmationStatus()
			{
				metadata = new OutletConfirmationStatusMetadata();
			}
		}


		public class OutletConfirmationStatusMetadata
		{
			
			
			
			
			
			
			
			public OutletConfirmationStatusMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class TypesOfUsers : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static TypesOfUsersMetadata metadata;

			public static TypesOfUsersMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static TypesOfUsers()
			{
				metadata = new TypesOfUsersMetadata();
			}
		}


		public class TypesOfUsersMetadata
		{
			
			
			
			
			
			
			
			public TypesOfUsersMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class UploadType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static UploadTypeMetadata metadata;

			public static UploadTypeMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static UploadType()
			{
				metadata = new UploadTypeMetadata();
			}
		}


		public class UploadTypeMetadata
		{
			
			
			
			
			
			
			
			public UploadTypeMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class VisitStatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static VisitStatusMetadata metadata;

			public static VisitStatusMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static VisitStatus()
			{
				metadata = new VisitStatusMetadata();
			}
		}


		public class VisitStatusMetadata
		{
			
			
			
			
			
			
			
			public VisitStatusMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class StatusTask : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static StatusTaskMetadata metadata;

			public static StatusTaskMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static StatusTask()
			{
				metadata = new StatusTaskMetadata();
			}
		}


		public class StatusTaskMetadata
		{
			
			
			
			
			
			
			
			public StatusTaskMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class OrderSatus : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OrderSatusMetadata metadata;

			public static OrderSatusMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static OrderSatus()
			{
				metadata = new OrderSatusMetadata();
			}
		}


		public class OrderSatusMetadata
		{
			
			
			
			
			
			
			
			public OrderSatusMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
			}

	 
	namespace Catalog 
	{
		 

		public partial class Positions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static PositionsMetadata metadata;

			public static PositionsMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Positions()
			{
				metadata = new PositionsMetadata();
			}
		}


		public class PositionsMetadata
		{
			
			
			
			
			
			
			
			public PositionsMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class User : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static UserMetadata metadata;

			public static UserMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static User()
			{
				metadata = new UserMetadata();
			}
		}


		public class UserMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Manager;
			public Metadata Manager
			{
				get
				{
					return _Manager;
				}
			}
			 
			
			
			
			
			
			
			
			
			
			
			
			
			
			private Metadata _Position;
			public Metadata Position
			{
				get
				{
					return _Position;
				}
			}
			 
			
			
			public UserMetadata()
			{

			
			
			
			
			
			
			
			
				_Manager = new Metadata("Catalog","User");
			 
			
			
			
			
			
			
			
			
			
			
			
			
			
				_Position = new Metadata("Catalog","Positions");
			 
			
			
			}
		}
        
		 

		public partial class Region : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static RegionMetadata metadata;

			public static RegionMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Region()
			{
				metadata = new RegionMetadata();
			}
		}


		public class RegionMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Parent;
			public Metadata Parent
			{
				get
				{
					return _Parent;
				}
			}
			 
			
			
			
			private Metadata _Manager;
			public Metadata Manager
			{
				get
				{
					return _Manager;
				}
			}
			 
			
			
			public RegionMetadata()
			{

			
			
			
			
			
			
			
			
				_Parent = new Metadata("Catalog","Region");
			 
			
			
			
				_Manager = new Metadata("Catalog","User");
			 
			
			
			}
		}
        
		 

		public partial class Distributor : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static DistributorMetadata metadata;

			public static DistributorMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Distributor()
			{
				metadata = new DistributorMetadata();
			}
		}


		public class DistributorMetadata
		{
			
			
			
			
			
			
			
			public DistributorMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class OutletParameter : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OutletParameterMetadata metadata;

			public static OutletParameterMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static OutletParameter()
			{
				metadata = new OutletParameterMetadata();
			}
		}


		public class OutletParameterMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _DataType;
			public Metadata DataType
			{
				get
				{
					return _DataType;
				}
			}
			 
			
			
			public OutletParameterMetadata()
			{

			
			
			
			
			
			
			
			
				_DataType = new Metadata("Enum","DataType");
			 
			
			
			}
		}
        
		 

		public partial class OutletType : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OutletTypeMetadata metadata;

			public static OutletTypeMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static OutletType()
			{
				metadata = new OutletTypeMetadata();
			}
		}


		public class OutletTypeMetadata
		{
			
			
			
			
			
			
			
			public OutletTypeMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class OutletClass : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OutletClassMetadata metadata;

			public static OutletClassMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static OutletClass()
			{
				metadata = new OutletClassMetadata();
			}
		}


		public class OutletClassMetadata
		{
			
			
			
			
			
			
			
			public OutletClassMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Outlet : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OutletMetadata metadata;

			public static OutletMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Outlet()
			{
				metadata = new OutletMetadata();
			}
		}


		public class OutletMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Type;
			public Metadata Type
			{
				get
				{
					return _Type;
				}
			}
			 
			
			
			
			private Metadata _Class;
			public Metadata Class
			{
				get
				{
					return _Class;
				}
			}
			 
			
			
			
			private Metadata _Distributor;
			public Metadata Distributor
			{
				get
				{
					return _Distributor;
				}
			}
			 
			
			
			
			
			
			private Metadata _ConfirmationStatus;
			public Metadata ConfirmationStatus
			{
				get
				{
					return _ConfirmationStatus;
				}
			}
			 
			
			
			
			
			
			
			public OutletMetadata()
			{

			
			
			
			
			
			
			
			
				_Type = new Metadata("Catalog","OutletType");
			 
			
			
			
				_Class = new Metadata("Catalog","OutletClass");
			 
			
			
			
				_Distributor = new Metadata("Catalog","Distributor");
			 
			
			
			
			
			
				_ConfirmationStatus = new Metadata("Enum","OutletConfirmationStatus");
			 
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Territory : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static TerritoryMetadata metadata;

			public static TerritoryMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Territory()
			{
				metadata = new TerritoryMetadata();
			}
		}


		public class TerritoryMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Owner;
			public Metadata Owner
			{
				get
				{
					return _Owner;
				}
			}
			 
			
			
			
			private Metadata _SR;
			public Metadata SR
			{
				get
				{
					return _SR;
				}
			}
			 
			
			
			public TerritoryMetadata()
			{

			
			
			
			
			
			
			
			
				_Owner = new Metadata("Catalog","Region");
			 
			
			
			
				_SR = new Metadata("Catalog","User");
			 
			
			
			}
		}
        
		 

		public partial class QuestionGroup : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static QuestionGroupMetadata metadata;

			public static QuestionGroupMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static QuestionGroup()
			{
				metadata = new QuestionGroupMetadata();
			}
		}


		public class QuestionGroupMetadata
		{
			
			
			
			
			
			
			
			public QuestionGroupMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Question : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static QuestionMetadata metadata;

			public static QuestionMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Question()
			{
				metadata = new QuestionMetadata();
			}
		}


		public class QuestionMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Owner;
			public Metadata Owner
			{
				get
				{
					return _Owner;
				}
			}
			 
			
			
			
			private Metadata _AnswerType;
			public Metadata AnswerType
			{
				get
				{
					return _AnswerType;
				}
			}
			 
			
			
			public QuestionMetadata()
			{

			
			
			
			
			
			
			
			
				_Owner = new Metadata("Catalog","QuestionGroup");
			 
			
			
			
				_AnswerType = new Metadata("Enum","DataType");
			 
			
			
			}
		}
        
		 

		public partial class SKUGroup : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static SKUGroupMetadata metadata;

			public static SKUGroupMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static SKUGroup()
			{
				metadata = new SKUGroupMetadata();
			}
		}


		public class SKUGroupMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Parent;
			public Metadata Parent
			{
				get
				{
					return _Parent;
				}
			}
			 
			
			
			public SKUGroupMetadata()
			{

			
			
			
			
			
			
			
			
				_Parent = new Metadata("Catalog","SKUGroup");
			 
			
			
			}
		}
        
		 

		public partial class Brands : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static BrandsMetadata metadata;

			public static BrandsMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Brands()
			{
				metadata = new BrandsMetadata();
			}
		}


		public class BrandsMetadata
		{
			
			
			
			
			
			
			
			public BrandsMetadata()
			{

			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class UnitsOfMeasure : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static UnitsOfMeasureMetadata metadata;

			public static UnitsOfMeasureMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static UnitsOfMeasure()
			{
				metadata = new UnitsOfMeasureMetadata();
			}
		}


		public class UnitsOfMeasureMetadata
		{
			
			
			
			
			
			
			
			
			
			public UnitsOfMeasureMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class SKU : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static SKUMetadata metadata;

			public static SKUMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static SKU()
			{
				metadata = new SKUMetadata();
			}
		}


		public class SKUMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _Owner;
			public Metadata Owner
			{
				get
				{
					return _Owner;
				}
			}
			 
			
			
			
			
			
			private Metadata _Brand;
			public Metadata Brand
			{
				get
				{
					return _Brand;
				}
			}
			 
			
			
			
			
			
			private Metadata _BaseUnit;
			public Metadata BaseUnit
			{
				get
				{
					return _BaseUnit;
				}
			}
			 
			
			
			public SKUMetadata()
			{

			
			
			
			
			
			
			
			
				_Owner = new Metadata("Catalog","SKUGroup");
			 
			
			
			
			
			
				_Brand = new Metadata("Catalog","Brands");
			 
			
			
			
			
			
				_BaseUnit = new Metadata("Catalog","UnitsOfMeasure");
			 
			
			
			}
		}
        
		 

		public partial class SKUQuestions : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static SKUQuestionsMetadata metadata;

			public static SKUQuestionsMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static SKUQuestions()
			{
				metadata = new SKUQuestionsMetadata();
			}
		}


		public class SKUQuestionsMetadata
		{
			
			
			
			
			
			
			
			
			private Metadata _AnswerType;
			public Metadata AnswerType
			{
				get
				{
					return _AnswerType;
				}
			}
			 
			
			
			public SKUQuestionsMetadata()
			{

			
			
			
			
			
			
			
			
				_AnswerType = new Metadata("Enum","DataType");
			 
			
			
			}
		}
        
			}

	 
	namespace Document 
	{
		 

		public partial class PriceList : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static PriceListMetadata metadata;

			public static PriceListMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static PriceList()
			{
				metadata = new PriceListMetadata();
			}
		}


		public class PriceListMetadata
		{
			
			
			
			
			
			
			
			
			
			public PriceListMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Questionnaire : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static QuestionnaireMetadata metadata;

			public static QuestionnaireMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Questionnaire()
			{
				metadata = new QuestionnaireMetadata();
			}
		}


		public class QuestionnaireMetadata
		{
			
			
			
			
			
			
			
			
			
			
			private Metadata _OutletType;
			public Metadata OutletType
			{
				get
				{
					return _OutletType;
				}
			}
			 
			
			
			
			private Metadata _OutletClass;
			public Metadata OutletClass
			{
				get
				{
					return _OutletClass;
				}
			}
			 
			
			
			public QuestionnaireMetadata()
			{

			
			
			
			
			
			
			
			
			
			
				_OutletType = new Metadata("Catalog","OutletType");
			 
			
			
			
				_OutletClass = new Metadata("Catalog","OutletClass");
			 
			
			
			}
		}
        
		 

		public partial class Target : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static TargetMetadata metadata;

			public static TargetMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Target()
			{
				metadata = new TargetMetadata();
			}
		}


		public class TargetMetadata
		{
			
			
			
			
			
			
			
			
			
			
			private Metadata _Territory;
			public Metadata Territory
			{
				get
				{
					return _Territory;
				}
			}
			 
			
			
			
			private Metadata _OutletType;
			public Metadata OutletType
			{
				get
				{
					return _OutletType;
				}
			}
			 
			
			
			
			private Metadata _OutletClass;
			public Metadata OutletClass
			{
				get
				{
					return _OutletClass;
				}
			}
			 
			
			
			public TargetMetadata()
			{

			
			
			
			
			
			
			
			
			
			
				_Territory = new Metadata("Catalog","Territory");
			 
			
			
			
				_OutletType = new Metadata("Catalog","OutletType");
			 
			
			
			
				_OutletClass = new Metadata("Catalog","OutletClass");
			 
			
			
			}
		}
        
		 

		public partial class VisitPlan : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static VisitPlanMetadata metadata;

			public static VisitPlanMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static VisitPlan()
			{
				metadata = new VisitPlanMetadata();
			}
		}


		public class VisitPlanMetadata
		{
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			private Metadata _SR;
			public Metadata SR
			{
				get
				{
					return _SR;
				}
			}
			 
			
			
			
			private Metadata _Owner;
			public Metadata Owner
			{
				get
				{
					return _Owner;
				}
			}
			 
			
			
			
			
			
			
			public VisitPlanMetadata()
			{

			
			
			
			
			
			
			
			
			
			
			
			
			
			
				_SR = new Metadata("Catalog","User");
			 
			
			
			
				_Owner = new Metadata("Catalog","User");
			 
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Visit : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static VisitMetadata metadata;

			public static VisitMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Visit()
			{
				metadata = new VisitMetadata();
			}
		}


		public class VisitMetadata
		{
			
			
			
			
			
			
			
			
			
			
			private Metadata _Outlet;
			public Metadata Outlet
			{
				get
				{
					return _Outlet;
				}
			}
			 
			
			
			
			private Metadata _SR;
			public Metadata SR
			{
				get
				{
					return _SR;
				}
			}
			 
			
			
			
			private Metadata _Status;
			public Metadata Status
			{
				get
				{
					return _Status;
				}
			}
			 
			
			
			
			
			
			
			
			
			
			private Metadata _Plan;
			public Metadata Plan
			{
				get
				{
					return _Plan;
				}
			}
			 
			
			
			
			
			
			
			public VisitMetadata()
			{

			
			
			
			
			
			
			
			
			
			
				_Outlet = new Metadata("Catalog","Outlet");
			 
			
			
			
				_SR = new Metadata("Catalog","User");
			 
			
			
			
				_Status = new Metadata("Enum","VisitStatus");
			 
			
			
			
			
			
			
			
			
			
				_Plan = new Metadata("Document","VisitPlan");
			 
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Order : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static OrderMetadata metadata;

			public static OrderMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Order()
			{
				metadata = new OrderMetadata();
			}
		}


		public class OrderMetadata
		{
			
			
			
			
			
			
			
			
			
			
			private Metadata _Outlet;
			public Metadata Outlet
			{
				get
				{
					return _Outlet;
				}
			}
			 
			
			
			
			private Metadata _SR;
			public Metadata SR
			{
				get
				{
					return _SR;
				}
			}
			 
			
			
			
			
			
			
			
			private Metadata _Visit;
			public Metadata Visit
			{
				get
				{
					return _Visit;
				}
			}
			 
			
			
			
			
			
			
			
			private Metadata _Status;
			public Metadata Status
			{
				get
				{
					return _Status;
				}
			}
			 
			
			
			public OrderMetadata()
			{

			
			
			
			
			
			
			
			
			
			
				_Outlet = new Metadata("Catalog","Outlet");
			 
			
			
			
				_SR = new Metadata("Catalog","User");
			 
			
			
			
			
			
			
			
				_Visit = new Metadata("Document","Visit");
			 
			
			
			
			
			
			
			
				_Status = new Metadata("Enum","OrderSatus");
			 
			
			
			}
		}
        
		 

		public partial class Task : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static TaskMetadata metadata;

			public static TaskMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Task()
			{
				metadata = new TaskMetadata();
			}
		}


		public class TaskMetadata
		{
			
			
			
			
			
			
			
			
			
			
			private Metadata _Territory;
			public Metadata Territory
			{
				get
				{
					return _Territory;
				}
			}
			 
			
			
			
			private Metadata _Outlet;
			public Metadata Outlet
			{
				get
				{
					return _Outlet;
				}
			}
			 
			
			
			
			private Metadata _StatusTask;
			public Metadata StatusTask
			{
				get
				{
					return _StatusTask;
				}
			}
			 
			
			
			
			
			
			private Metadata _VisitPlan;
			public Metadata VisitPlan
			{
				get
				{
					return _VisitPlan;
				}
			}
			 
			
			
			
			
			
			private Metadata _TypeOfResultAndGoals;
			public Metadata TypeOfResultAndGoals
			{
				get
				{
					return _TypeOfResultAndGoals;
				}
			}
			 
			
			
			
			
			
			
			
			
			public TaskMetadata()
			{

			
			
			
			
			
			
			
			
			
			
				_Territory = new Metadata("Catalog","Territory");
			 
			
			
			
				_Outlet = new Metadata("Catalog","Outlet");
			 
			
			
			
				_StatusTask = new Metadata("Enum","StatusTask");
			 
			
			
			
			
			
				_VisitPlan = new Metadata("Document","VisitPlan");
			 
			
			
			
			
			
				_TypeOfResultAndGoals = new Metadata("Enum","DataType");
			 
			
			
			
			
			
			
			
			
			}
		}
        
			}

	 
	namespace resource 
	{
		 

		public partial class BusinessProcess : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static BusinessProcessMetadata metadata;

			public static BusinessProcessMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static BusinessProcess()
			{
				metadata = new BusinessProcessMetadata();
			}
		}


		public class BusinessProcessMetadata
		{
			
			
			
			
			
			
			
			
			
			public BusinessProcessMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Image : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static ImageMetadata metadata;

			public static ImageMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Image()
			{
				metadata = new ImageMetadata();
			}
		}


		public class ImageMetadata
		{
			
			
			
			
			
			
			
			
			
			public ImageMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Screen : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static ScreenMetadata metadata;

			public static ScreenMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Screen()
			{
				metadata = new ScreenMetadata();
			}
		}


		public class ScreenMetadata
		{
			
			
			
			
			
			
			
			
			
			public ScreenMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Script : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static ScriptMetadata metadata;

			public static ScriptMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Script()
			{
				metadata = new ScriptMetadata();
			}
		}


		public class ScriptMetadata
		{
			
			
			
			
			
			
			
			
			
			public ScriptMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Style : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static StyleMetadata metadata;

			public static StyleMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Style()
			{
				metadata = new StyleMetadata();
			}
		}


		public class StyleMetadata
		{
			
			
			
			
			
			
			
			
			
			public StyleMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
		 

		public partial class Translation : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static TranslationMetadata metadata;

			public static TranslationMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Translation()
			{
				metadata = new TranslationMetadata();
			}
		}


		public class TranslationMetadata
		{
			
			
			
			
			
			
			
			
			
			public TranslationMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
			}

	 
	namespace admin 
	{
		 

		public partial class Entity : Microsoft.Synchronization.ClientServices.IsolatedStorage.IsolatedStorageOfflineEntity 
		{
			private static EntityMetadata metadata;

			public static EntityMetadata Metadata
			{
				get
				{
					return metadata;
				}
			}

			static Entity()
			{
				metadata = new EntityMetadata();
			}
		}


		public class EntityMetadata
		{
			
			
			
			
			
			
			
			
			
			public EntityMetadata()
			{

			
			
			
			
			
			
			
			
			
			}
		}
        
			}

	
}
