
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Synchronization.ClientServices.IsolatedStorage
{
    public class IsolatedStorageOfflineEntity 
    {
         protected void OnPropertyChanging(string propertyName)
         { }
         protected void OnPropertyChanged(string propertyName)
         { }
    }
    public class IsolatedStorageOfflineContext
    {
        public IsolatedStorageOfflineContext(IsolatedStorageSchema s)
        {

        }
        public IsolatedStorageOfflineContext()
        {

        }
        public void AddItem<T>(T entity) where T : IsolatedStorageOfflineEntity
        {

        }
        public IEnumerable<T> GetCollection<T>() where T : IsolatedStorageOfflineEntity
        {
            return null;
        }
        public IsolatedStorageOfflineContext(IsolatedStorageSchema schema, string scopeName, string cachePath,Uri uri) :
            this(schema, scopeName, cachePath, uri, null)
        {
        }
     public IsolatedStorageOfflineContext(IsolatedStorageSchema schema, string scopeName, string cachePath,Uri uri, System.Security.Cryptography.SymmetricAlgorithm encryptionAlgorithm)
        {}
    }
    public class IsolatedStorageSchema
    {
        public void AddCollection<T>() where T : IsolatedStorageOfflineEntity
        {

        }
    }
}
namespace System.ComponentModel.DataAnnotations
{
   public sealed class KeyAttribute : Attribute
   {
   }
}
