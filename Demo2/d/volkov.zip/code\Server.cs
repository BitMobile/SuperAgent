using System;
using Common;

namespace DefaultScope
{
	public class OfflineEntityBase : object, Microsoft.Synchronization.Services.IOfflineEntity {
        
		private Microsoft.Synchronization.Services.OfflineEntityMetadata _serviceMetadata;
        
		public OfflineEntityBase() {
			ServiceMetadata = new Microsoft.Synchronization.Services.OfflineEntityMetadata();
		}
        
		public virtual Microsoft.Synchronization.Services.OfflineEntityMetadata ServiceMetadata {
			get {
				return _serviceMetadata;
			}
			set {
				if ((value == null)) {
					throw new System.ArgumentNullException("value");
				}
				_serviceMetadata = value;
			}
		}
	}

	 

	namespace Enum
	{
		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_DataStatus", TableLocalName="Enum.DataStatus", KeyFields="Id")]
		public partial class DataStatus : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_DataType", TableLocalName="Enum.DataType", KeyFields="Id")]
		public partial class DataType : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_OutletConfirmationStatus", TableLocalName="Enum.OutletConfirmationStatus", KeyFields="Id")]
		public partial class OutletConfirmationStatus : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_TypesOfUsers", TableLocalName="Enum.TypesOfUsers", KeyFields="Id")]
		public partial class TypesOfUsers : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_UploadType", TableLocalName="Enum.UploadType", KeyFields="Id")]
		public partial class UploadType : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_VisitStatus", TableLocalName="Enum.VisitStatus", KeyFields="Id")]
		public partial class VisitStatus : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_StatusTask", TableLocalName="Enum.StatusTask", KeyFields="Id")]
		public partial class StatusTask : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Enum_OrderSatus", TableLocalName="Enum.OrderSatus", KeyFields="Id")]
		public partial class OrderSatus : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

			}

	 

	namespace Catalog
	{
		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Positions", TableLocalName="Catalog.Positions", KeyFields="Id")]
		public partial class Positions : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_User", TableLocalName="Catalog.User", KeyFields="Id")]
		public partial class User : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Manager;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Manager 
			{
				get 
				{
					return _Manager;
				}
				set 
				{
					_Manager = value;
				}
			}

			
			private String _EMail;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String EMail 
			{
				get 
				{
					return _EMail;
				}
				set 
				{
					_EMail = value;
				}
			}

			
			private System.Nullable<Guid> _UserID;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<Guid> UserID 
			{
				get 
				{
					return _UserID;
				}
				set 
				{
					_UserID = value;
				}
			}

			
			private String _UserName;

						public String UserName 
			{
				get 
				{
					return _UserName;
				}
				set 
				{
					_UserName = value;
				}
			}

			
			private String _Role;

						public String Role 
			{
				get 
				{
					return _Role;
				}
				set 
				{
					_Role = value;
				}
			}

			
			private String _Password;

						public String Password 
			{
				get 
				{
					return _Password;
				}
				set 
				{
					_Password = value;
				}
			}

			
			private Guid _Position;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Position 
			{
				get 
				{
					return _Position;
				}
				set 
				{
					_Position = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Region", TableLocalName="Catalog.Region", KeyFields="Id")]
		public partial class Region : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Parent;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

			
			private Guid _Manager;

						public Guid Manager 
			{
				get 
				{
					return _Manager;
				}
				set 
				{
					_Manager = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Distributor", TableLocalName="Catalog.Distributor", KeyFields="Id")]
		public partial class Distributor : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_OutletParameter", TableLocalName="Catalog.OutletParameter", KeyFields="Id")]
		public partial class OutletParameter : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _DataType;

						public Guid DataType 
			{
				get 
				{
					return _DataType;
				}
				set 
				{
					_DataType = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_OutletType", TableLocalName="Catalog.OutletType", KeyFields="Id")]
		public partial class OutletType : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_OutletClass", TableLocalName="Catalog.OutletClass", KeyFields="Id")]
		public partial class OutletClass : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Outlet", TableLocalName="Catalog.Outlet", KeyFields="Id")]
		public partial class Outlet : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Type;

						public Guid Type 
			{
				get 
				{
					return _Type;
				}
				set 
				{
					_Type = value;
				}
			}

			
			private Guid _Class;

						public Guid Class 
			{
				get 
				{
					return _Class;
				}
				set 
				{
					_Class = value;
				}
			}

			
			private Guid _Distributor;

						public Guid Distributor 
			{
				get 
				{
					return _Distributor;
				}
				set 
				{
					_Distributor = value;
				}
			}

			
			private String _Address;

						public String Address 
			{
				get 
				{
					return _Address;
				}
				set 
				{
					_Address = value;
				}
			}

			
			private Guid _ConfirmationStatus;

						public Guid ConfirmationStatus 
			{
				get 
				{
					return _ConfirmationStatus;
				}
				set 
				{
					_ConfirmationStatus = value;
				}
			}

			
			private System.Nullable<decimal> _Lattitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					_Lattitude = value;
				}
			}

			
			private System.Nullable<decimal> _Longitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					_Longitude = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Outlet_Parameters", TableLocalName="Catalog.Outlet_Parameters", KeyFields="Id")]
		public partial class Outlet_Parameters : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Parameter;

						public Guid Parameter 
			{
				get 
				{
					return _Parameter;
				}
				set 
				{
					_Parameter = value;
				}
			}

			
			private String _Value;

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					_Value = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Territory", TableLocalName="Catalog.Territory", KeyFields="Id")]
		public partial class Territory : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Owner;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					_Owner = value;
				}
			}

			
			private Guid _SR;

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					_SR = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Territory_Outlets", TableLocalName="Catalog.Territory_Outlets", KeyFields="Id")]
		public partial class Territory_Outlets : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Outlet;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					_Outlet = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Territory_SKUGroups", TableLocalName="Catalog.Territory_SKUGroups", KeyFields="Id")]
		public partial class Territory_SKUGroups : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKUGroup;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					_SKUGroup = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_QuestionGroup", TableLocalName="Catalog.QuestionGroup", KeyFields="Id")]
		public partial class QuestionGroup : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Question", TableLocalName="Catalog.Question", KeyFields="Id")]
		public partial class Question : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Owner;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					_Owner = value;
				}
			}

			
			private Guid _AnswerType;

						public Guid AnswerType 
			{
				get 
				{
					return _AnswerType;
				}
				set 
				{
					_AnswerType = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Question_ValueList", TableLocalName="Catalog.Question_ValueList", KeyFields="Id")]
		public partial class Question_ValueList : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private String _Value;

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					_Value = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_SKUGroup", TableLocalName="Catalog.SKUGroup", KeyFields="Id")]
		public partial class SKUGroup : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Parent;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_Brands", TableLocalName="Catalog.Brands", KeyFields="Id")]
		public partial class Brands : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_UnitsOfMeasure", TableLocalName="Catalog.UnitsOfMeasure", KeyFields="Id")]
		public partial class UnitsOfMeasure : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private String _FullDescription;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String FullDescription 
			{
				get 
				{
					return _FullDescription;
				}
				set 
				{
					_FullDescription = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_SKU", TableLocalName="Catalog.SKU", KeyFields="Id")]
		public partial class SKU : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _Owner;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					_Owner = value;
				}
			}

			
			private System.Nullable<decimal> _Price;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					_Price = value;
				}
			}

			
			private Guid _Brand;

						public Guid Brand 
			{
				get 
				{
					return _Brand;
				}
				set 
				{
					_Brand = value;
				}
			}

			
			private System.Nullable<decimal> _Stock;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					_Stock = value;
				}
			}

			
			private Guid _BaseUnit;

						public Guid BaseUnit 
			{
				get 
				{
					return _BaseUnit;
				}
				set 
				{
					_BaseUnit = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_SKU_Packing", TableLocalName="Catalog.SKU_Packing", KeyFields="Id")]
		public partial class SKU_Packing : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Pack;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Pack 
			{
				get 
				{
					return _Pack;
				}
				set 
				{
					_Pack = value;
				}
			}

			
			private decimal _Multiplier;

						public decimal Multiplier 
			{
				get 
				{
					return _Multiplier;
				}
				set 
				{
					_Multiplier = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_SKUQuestions", TableLocalName="Catalog.SKUQuestions", KeyFields="Id")]
		public partial class SKUQuestions : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Code;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Code 
			{
				get 
				{
					return _Code;
				}
				set 
				{
					_Code = value;
				}
			}

			
			private String _Description;

						public String Description 
			{
				get 
				{
					return _Description;
				}
				set 
				{
					_Description = value;
				}
			}

			
			private Guid _AnswerType;

						public Guid AnswerType 
			{
				get 
				{
					return _AnswerType;
				}
				set 
				{
					_AnswerType = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Catalog_SKUQuestions_ValueList", TableLocalName="Catalog.SKUQuestions_ValueList", KeyFields="Id")]
		public partial class SKUQuestions_ValueList : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private String _Value;

						public String Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					_Value = value;
				}
			}

					}

		

			}

	 

	namespace Document
	{
		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_PriceList", TableLocalName="Document.PriceList", KeyFields="Id")]
		public partial class PriceList : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_PriceList_Prices", TableLocalName="Document.PriceList_Prices", KeyFields="Id")]
		public partial class PriceList_Prices : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKU;

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					_SKU = value;
				}
			}

			
			private decimal _Price;

						public decimal Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					_Price = value;
				}
			}

			
			private System.Nullable<decimal> _Stock;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					_Stock = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire", TableLocalName="Document.Questionnaire", KeyFields="Id")]
		public partial class Questionnaire : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private Guid _OutletType;

						public Guid OutletType 
			{
				get 
				{
					return _OutletType;
				}
				set 
				{
					_OutletType = value;
				}
			}

			
			private Guid _OutletClass;

						public Guid OutletClass 
			{
				get 
				{
					return _OutletClass;
				}
				set 
				{
					_OutletClass = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire_Questions", TableLocalName="Document.Questionnaire_Questions", KeyFields="Id")]
		public partial class Questionnaire_Questions : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Question;

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					_Question = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire_SKUs", TableLocalName="Document.Questionnaire_SKUs", KeyFields="Id")]
		public partial class Questionnaire_SKUs : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKU;

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					_SKU = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire_SKUGroups", TableLocalName="Document.Questionnaire_SKUGroups", KeyFields="Id")]
		public partial class Questionnaire_SKUGroups : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKUGroup;

						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					_SKUGroup = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire_SKUQuestions", TableLocalName="Document.Questionnaire_SKUQuestions", KeyFields="Id")]
		public partial class Questionnaire_SKUQuestions : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKUQuestion;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid SKUQuestion 
			{
				get 
				{
					return _SKUQuestion;
				}
				set 
				{
					_SKUQuestion = value;
				}
			}

			
			private System.Nullable<bool> _UseInQuestionaire;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> UseInQuestionaire 
			{
				get 
				{
					return _UseInQuestionaire;
				}
				set 
				{
					_UseInQuestionaire = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Questionnaire_Territories", TableLocalName="Document.Questionnaire_Territories", KeyFields="Id")]
		public partial class Questionnaire_Territories : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Territory;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					_Territory = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Target", TableLocalName="Document.Target", KeyFields="Id")]
		public partial class Target : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private Guid _Territory;

						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					_Territory = value;
				}
			}

			
			private Guid _OutletType;

						public Guid OutletType 
			{
				get 
				{
					return _OutletType;
				}
				set 
				{
					_OutletType = value;
				}
			}

			
			private Guid _OutletClass;

						public Guid OutletClass 
			{
				get 
				{
					return _OutletClass;
				}
				set 
				{
					_OutletClass = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Target_Targets", TableLocalName="Document.Target_Targets", KeyFields="Id")]
		public partial class Target_Targets : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Question;

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					_Question = value;
				}
			}

			
			private decimal _Value;

						public decimal Value 
			{
				get 
				{
					return _Value;
				}
				set 
				{
					_Value = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_VisitPlan", TableLocalName="Document.VisitPlan", KeyFields="Id")]
		public partial class VisitPlan : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private DateTime _Year;

						public DateTime Year 
			{
				get 
				{
					return _Year;
				}
				set 
				{
					_Year = value;
				}
			}

			
			private int _WeekNumber;

						public int WeekNumber 
			{
				get 
				{
					return _WeekNumber;
				}
				set 
				{
					_WeekNumber = value;
				}
			}

			
			private Guid _SR;

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					_SR = value;
				}
			}

			
			private Guid _Owner;

						public Guid Owner 
			{
				get 
				{
					return _Owner;
				}
				set 
				{
					_Owner = value;
				}
			}

			
			private DateTime _DateFrom;

						public DateTime DateFrom 
			{
				get 
				{
					return _DateFrom;
				}
				set 
				{
					_DateFrom = value;
				}
			}

			
			private DateTime _DateTo;

						public DateTime DateTo 
			{
				get 
				{
					return _DateTo;
				}
				set 
				{
					_DateTo = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_VisitPlan_Outlets", TableLocalName="Document.VisitPlan_Outlets", KeyFields="Id")]
		public partial class VisitPlan_Outlets : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Outlet;

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					_Outlet = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Visit", TableLocalName="Document.Visit", KeyFields="Id")]
		public partial class Visit : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private Guid _Outlet;

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					_Outlet = value;
				}
			}

			
			private Guid _SR;

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					_SR = value;
				}
			}

			
			private Guid _Status;

						public Guid Status 
			{
				get 
				{
					return _Status;
				}
				set 
				{
					_Status = value;
				}
			}

			
			private DateTime _StartTime;

						public DateTime StartTime 
			{
				get 
				{
					return _StartTime;
				}
				set 
				{
					_StartTime = value;
				}
			}

			
			private System.Nullable<DateTime> _EndTime;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<DateTime> EndTime 
			{
				get 
				{
					return _EndTime;
				}
				set 
				{
					_EndTime = value;
				}
			}

			
			private decimal _Encashment;

						public decimal Encashment 
			{
				get 
				{
					return _Encashment;
				}
				set 
				{
					_Encashment = value;
				}
			}

			
			private Guid _Plan;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Plan 
			{
				get 
				{
					return _Plan;
				}
				set 
				{
					_Plan = value;
				}
			}

			
			private System.Nullable<decimal> _Lattitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					_Lattitude = value;
				}
			}

			
			private System.Nullable<decimal> _Longitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					_Longitude = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Visit_Questions", TableLocalName="Document.Visit_Questions", KeyFields="Id")]
		public partial class Visit_Questions : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _Question;

						public Guid Question 
			{
				get 
				{
					return _Question;
				}
				set 
				{
					_Question = value;
				}
			}

			
			private String _Answer;

						public String Answer 
			{
				get 
				{
					return _Answer;
				}
				set 
				{
					_Answer = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Visit_SKUs", TableLocalName="Document.Visit_SKUs", KeyFields="Id")]
		public partial class Visit_SKUs : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKU;

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					_SKU = value;
				}
			}

			
			private bool _Available;

						public bool Available 
			{
				get 
				{
					return _Available;
				}
				set 
				{
					_Available = value;
				}
			}

			
			private System.Nullable<int> _Facing;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<int> Facing 
			{
				get 
				{
					return _Facing;
				}
				set 
				{
					_Facing = value;
				}
			}

			
			private System.Nullable<int> _Stock;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<int> Stock 
			{
				get 
				{
					return _Stock;
				}
				set 
				{
					_Stock = value;
				}
			}

			
			private System.Nullable<int> _Price;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<int> Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					_Price = value;
				}
			}

			
			private System.Nullable<int> _MarkUp;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<int> MarkUp 
			{
				get 
				{
					return _MarkUp;
				}
				set 
				{
					_MarkUp = value;
				}
			}

			
			private bool _OutOfStock;

						public bool OutOfStock 
			{
				get 
				{
					return _OutOfStock;
				}
				set 
				{
					_OutOfStock = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Visit_SKUGroups", TableLocalName="Document.Visit_SKUGroups", KeyFields="Id")]
		public partial class Visit_SKUGroups : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKUGroup;

						public Guid SKUGroup 
			{
				get 
				{
					return _SKUGroup;
				}
				set 
				{
					_SKUGroup = value;
				}
			}

			
			private bool _Available;

						public bool Available 
			{
				get 
				{
					return _Available;
				}
				set 
				{
					_Available = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Visit_Task", TableLocalName="Document.Visit_Task", KeyFields="Id")]
		public partial class Visit_Task : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private String _TextTask;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String TextTask 
			{
				get 
				{
					return _TextTask;
				}
				set 
				{
					_TextTask = value;
				}
			}

			
			private String _Result;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Result 
			{
				get 
				{
					return _Result;
				}
				set 
				{
					_Result = value;
				}
			}

			
			private Guid _TaskRef;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid TaskRef 
			{
				get 
				{
					return _TaskRef;
				}
				set 
				{
					_TaskRef = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Order", TableLocalName="Document.Order", KeyFields="Id")]
		public partial class Order : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private Guid _Outlet;

						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					_Outlet = value;
				}
			}

			
			private Guid _SR;

						public Guid SR 
			{
				get 
				{
					return _SR;
				}
				set 
				{
					_SR = value;
				}
			}

			
			private DateTime _DeliveryDate;

						public DateTime DeliveryDate 
			{
				get 
				{
					return _DeliveryDate;
				}
				set 
				{
					_DeliveryDate = value;
				}
			}

			
			private String _Commentary;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Commentary 
			{
				get 
				{
					return _Commentary;
				}
				set 
				{
					_Commentary = value;
				}
			}

			
			private Guid _Visit;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Visit 
			{
				get 
				{
					return _Visit;
				}
				set 
				{
					_Visit = value;
				}
			}

			
			private System.Nullable<decimal> _Lattitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Lattitude 
			{
				get 
				{
					return _Lattitude;
				}
				set 
				{
					_Lattitude = value;
				}
			}

			
			private System.Nullable<decimal> _Longitude;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<decimal> Longitude 
			{
				get 
				{
					return _Longitude;
				}
				set 
				{
					_Longitude = value;
				}
			}

			
			private Guid _Status;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Status 
			{
				get 
				{
					return _Status;
				}
				set 
				{
					_Status = value;
				}
			}

					}

			

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Order_SKUs", TableLocalName="Document.Order_SKUs", KeyFields="Id")]
		public partial class Order_SKUs : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private Guid _Ref;

						public Guid Ref 
			{
				get 
				{
					return _Ref;
				}
				set 
				{
					_Ref = value;
				}
			}

			
			private int _LineNumber;

						public int LineNumber 
			{
				get 
				{
					return _LineNumber;
				}
				set 
				{
					_LineNumber = value;
				}
			}

			
			private Guid _SKU;

						public Guid SKU 
			{
				get 
				{
					return _SKU;
				}
				set 
				{
					_SKU = value;
				}
			}

			
			private decimal _Qty;

						public decimal Qty 
			{
				get 
				{
					return _Qty;
				}
				set 
				{
					_Qty = value;
				}
			}

			
			private decimal _Price;

						public decimal Price 
			{
				get 
				{
					return _Price;
				}
				set 
				{
					_Price = value;
				}
			}

			
			private int _Discount;

						public int Discount 
			{
				get 
				{
					return _Discount;
				}
				set 
				{
					_Discount = value;
				}
			}

			
			private decimal _Total;

						public decimal Total 
			{
				get 
				{
					return _Total;
				}
				set 
				{
					_Total = value;
				}
			}

			
			private decimal _Amount;

						public decimal Amount 
			{
				get 
				{
					return _Amount;
				}
				set 
				{
					_Amount = value;
				}
			}

			
			private Guid _Units;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Units 
			{
				get 
				{
					return _Units;
				}
				set 
				{
					_Units = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="Document_Task", TableLocalName="Document.Task", KeyFields="Id")]
		public partial class Task : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Number;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Number 
			{
				get 
				{
					return _Number;
				}
				set 
				{
					_Number = value;
				}
			}

			
			private DateTime _Date;

						public DateTime Date 
			{
				get 
				{
					return _Date;
				}
				set 
				{
					_Date = value;
				}
			}

			
			private System.Nullable<bool> _Posted;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<bool> Posted 
			{
				get 
				{
					return _Posted;
				}
				set 
				{
					_Posted = value;
				}
			}

			
			private Guid _Territory;

						public Guid Territory 
			{
				get 
				{
					return _Territory;
				}
				set 
				{
					_Territory = value;
				}
			}

			
			private Guid _Outlet;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Outlet 
			{
				get 
				{
					return _Outlet;
				}
				set 
				{
					_Outlet = value;
				}
			}

			
			private Guid _StatusTask;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid StatusTask 
			{
				get 
				{
					return _StatusTask;
				}
				set 
				{
					_StatusTask = value;
				}
			}

			
			private String _TextTask;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String TextTask 
			{
				get 
				{
					return _TextTask;
				}
				set 
				{
					_TextTask = value;
				}
			}

			
			private Guid _VisitPlan;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid VisitPlan 
			{
				get 
				{
					return _VisitPlan;
				}
				set 
				{
					_VisitPlan = value;
				}
			}

			
			private DateTime _PlanDate;

						public DateTime PlanDate 
			{
				get 
				{
					return _PlanDate;
				}
				set 
				{
					_PlanDate = value;
				}
			}

			
			private Guid _TypeOfResultAndGoals;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid TypeOfResultAndGoals 
			{
				get 
				{
					return _TypeOfResultAndGoals;
				}
				set 
				{
					_TypeOfResultAndGoals = value;
				}
			}

			
			private String _Result;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Result 
			{
				get 
				{
					return _Result;
				}
				set 
				{
					_Result = value;
				}
			}

			
			private System.Nullable<DateTime> _FactDate;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public System.Nullable<DateTime> FactDate 
			{
				get 
				{
					return _FactDate;
				}
				set 
				{
					_FactDate = value;
				}
			}

			
			private String _Target;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public String Target 
			{
				get 
				{
					return _Target;
				}
				set 
				{
					_Target = value;
				}
			}

					}

		

			}

	 

	namespace resource
	{
		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_BusinessProcess", TableLocalName="resource.BusinessProcess", KeyFields="Id")]
		public partial class BusinessProcess : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_Image", TableLocalName="resource.Image", KeyFields="Id")]
		public partial class Image : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_Screen", TableLocalName="resource.Screen", KeyFields="Id")]
		public partial class Screen : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_Script", TableLocalName="resource.Script", KeyFields="Id")]
		public partial class Script : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_Style", TableLocalName="resource.Style", KeyFields="Id")]
		public partial class Style : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="resource_Translation", TableLocalName="resource.Translation", KeyFields="Id")]
		public partial class Translation : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Data;

						public String Data 
			{
				get 
				{
					return _Data;
				}
				set 
				{
					_Data = value;
				}
			}

			
			private String _Parent;

						public String Parent 
			{
				get 
				{
					return _Parent;
				}
				set 
				{
					_Parent = value;
				}
			}

					}

		

			}

	 

	namespace admin
	{
		 

		[Microsoft.Synchronization.Services.SyncEntityTypeAttribute(TableGlobalName="admin_Entity", TableLocalName="admin.Entity", KeyFields="Id")]
		public partial class Entity : OfflineEntityBase 
		{
			
			private Guid _Id;

						[Microsoft.Synchronization.Services.SyncEntityPropertyIsNullableAttribute()]
						public Guid Id 
			{
				get 
				{
					return _Id;
				}
				set 
				{
					_Id = value;
				}
			}

			
			private String _Name;

						public String Name 
			{
				get 
				{
					return _Name;
				}
				set 
				{
					_Name = value;
				}
			}

			
			private String _Schema;

						public String Schema 
			{
				get 
				{
					return _Schema;
				}
				set 
				{
					_Schema = value;
				}
			}

			
			private String _ShortName;

						public String ShortName 
			{
				get 
				{
					return _ShortName;
				}
				set 
				{
					_ShortName = value;
				}
			}

					}

		

			}

	

	[Microsoft.Synchronization.Services.SyncScopeAttribute()]
    public class OfflineEntities 
	{
		  
		  
        private System.Collections.Generic.ICollection<Enum.DataStatus> _DataStatus;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.DataType> _DataType;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.OutletConfirmationStatus> _OutletConfirmationStatus;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.TypesOfUsers> _TypesOfUsers;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.UploadType> _UploadType;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.VisitStatus> _VisitStatus;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.StatusTask> _StatusTask;

		
		  
		  
        private System.Collections.Generic.ICollection<Enum.OrderSatus> _OrderSatus;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Positions> _Positions;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.User> _User;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Region> _Region;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Distributor> _Distributor;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.OutletParameter> _OutletParameter;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.OutletType> _OutletType;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.OutletClass> _OutletClass;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Outlet> _Outlet;

		
        private System.Collections.Generic.ICollection<Catalog.Outlet_Parameters> _Outlet_Parameters;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Territory> _Territory;

		
        private System.Collections.Generic.ICollection<Catalog.Territory_Outlets> _Territory_Outlets;

		
        private System.Collections.Generic.ICollection<Catalog.Territory_SKUGroups> _Territory_SKUGroups;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.QuestionGroup> _QuestionGroup;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Question> _Question;

		
        private System.Collections.Generic.ICollection<Catalog.Question_ValueList> _Question_ValueList;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.SKUGroup> _SKUGroup;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.Brands> _Brands;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.UnitsOfMeasure> _UnitsOfMeasure;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.SKU> _SKU;

		
        private System.Collections.Generic.ICollection<Catalog.SKU_Packing> _SKU_Packing;

		
		  
		  
        private System.Collections.Generic.ICollection<Catalog.SKUQuestions> _SKUQuestions;

		
        private System.Collections.Generic.ICollection<Catalog.SKUQuestions_ValueList> _SKUQuestions_ValueList;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.PriceList> _PriceList;

		
        private System.Collections.Generic.ICollection<Document.PriceList_Prices> _PriceList_Prices;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.Questionnaire> _Questionnaire;

		
        private System.Collections.Generic.ICollection<Document.Questionnaire_Questions> _Questionnaire_Questions;

		
        private System.Collections.Generic.ICollection<Document.Questionnaire_SKUs> _Questionnaire_SKUs;

		
        private System.Collections.Generic.ICollection<Document.Questionnaire_SKUGroups> _Questionnaire_SKUGroups;

		
        private System.Collections.Generic.ICollection<Document.Questionnaire_SKUQuestions> _Questionnaire_SKUQuestions;

		
        private System.Collections.Generic.ICollection<Document.Questionnaire_Territories> _Questionnaire_Territories;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.Target> _Target;

		
        private System.Collections.Generic.ICollection<Document.Target_Targets> _Target_Targets;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.VisitPlan> _VisitPlan;

		
        private System.Collections.Generic.ICollection<Document.VisitPlan_Outlets> _VisitPlan_Outlets;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.Visit> _Visit;

		
        private System.Collections.Generic.ICollection<Document.Visit_Questions> _Visit_Questions;

		
        private System.Collections.Generic.ICollection<Document.Visit_SKUs> _Visit_SKUs;

		
        private System.Collections.Generic.ICollection<Document.Visit_SKUGroups> _Visit_SKUGroups;

		
        private System.Collections.Generic.ICollection<Document.Visit_Task> _Visit_Task;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.Order> _Order;

		
        private System.Collections.Generic.ICollection<Document.Order_SKUs> _Order_SKUs;

		
		  
		  
        private System.Collections.Generic.ICollection<Document.Task> _Task;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.BusinessProcess> _BusinessProcess;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.Image> _Image;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.Screen> _Screen;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.Script> _Script;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.Style> _Style;

		
		  
		  
        private System.Collections.Generic.ICollection<resource.Translation> _Translation;

		
		  
		  
        private System.Collections.Generic.ICollection<admin.Entity> _Entity;

		
		    }

	
	public static class Helper
    {
        public static void AddFilters(Microsoft.Synchronization.Services.ISyncServiceConfiguration config)
        {
			  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
											  	  
																				  	  
				 		
				config.AddFilterParameterConfiguration("UserId", "Catalog_Territory", "@UserId", typeof(Guid));
													 		
					config.AddFilterParameterConfiguration("UserId", "Catalog_Territory_Outlets", "@UserId", typeof(Guid));
														 		
					config.AddFilterParameterConfiguration("UserId", "Catalog_Territory_SKUGroups", "@UserId", typeof(Guid));
												  	  
											  	  
																				  	  
											  	  
											  	  
											  	  
																				  	  
																				  	  
																				  	  
																																																								  	  
																				  	  
				 		
				config.AddFilterParameterConfiguration("UserId", "Document_VisitPlan", "@UserId", typeof(Guid));
													 		
					config.AddFilterParameterConfiguration("UserId", "Document_VisitPlan_Outlets", "@UserId", typeof(Guid));
												  	  
				 		
				config.AddFilterParameterConfiguration("UserId", "Document_Visit", "@UserId", typeof(Guid));
													 		
					config.AddFilterParameterConfiguration("UserId", "Document_Visit_Questions", "@UserId", typeof(Guid));
														 		
					config.AddFilterParameterConfiguration("UserId", "Document_Visit_SKUs", "@UserId", typeof(Guid));
														 		
					config.AddFilterParameterConfiguration("UserId", "Document_Visit_SKUGroups", "@UserId", typeof(Guid));
														 		
					config.AddFilterParameterConfiguration("UserId", "Document_Visit_Task", "@UserId", typeof(Guid));
												  	  
				 		
				config.AddFilterParameterConfiguration("UserId", "Document_Order", "@UserId", typeof(Guid));
													 		
					config.AddFilterParameterConfiguration("UserId", "Document_Order_SKUs", "@UserId", typeof(Guid));
												  	  
											  	  
											  	  
				 		
				config.AddFilterParameterConfiguration("Resolution", "resource_Image", "@Resolution", typeof(String));
											  	  
											  	  
											  	  
				 		
				config.AddFilterParameterConfiguration("Resolution", "resource_Style", "@Resolution", typeof(String));
											  	  
											  	  
											        }
    }

	public class DeviceSyncService : Microsoft.Synchronization.Services.SyncService<OfflineEntities>
    {
		private String scope;

		public String Scope
		{
			get
			{
				return scope;
			}
		}

		public DeviceSyncService()
		{
		}

		public DeviceSyncService(String scope)
		{
			this.scope = scope;
		}

        public static void InitializeService(Microsoft.Synchronization.Services.ISyncServiceConfiguration config, string dataBaseName)
        {
			config.ServerConnectionString = Common.Solution.CreateFromContext(dataBaseName).ConnectionString;
            config.SetEnableScope("DefaultScope");
			config.EnableDiagnosticPage = true;
            config.UseVerboseErrors = true;
			config.SetConflictResolutionPolicy(Microsoft.Synchronization.Services.ConflictResolutionPolicy.ServerWins);
            Helper.AddFilters(config);
        }

		public static Guid Logon(string dataBaseName, System.Net.NetworkCredential credential, String configName, String configVersion)
        {
			return Common.Logon.GetUserId(dataBaseName, credential, configName, configVersion);
        }

    }
}