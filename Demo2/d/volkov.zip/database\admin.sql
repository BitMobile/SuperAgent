
CREATE TABLE [admin].LastSyncTime(
	LastTime DATETIME NOT NULL PRIMARY KEY CLUSTERED
)
GO
INSERT INTO [admin].LastSyncTime SELECT '20100101'
GO

CREATE TABLE [admin].SyncSession(
	[Id] UNIQUEIDENTIFIER PRIMARY KEY CLUSTERED,
	StartTime DATETIME NOT NULL,
	EndTime DATETIME NULL
)
GO

CREATE PROCEDURE [admin].BeginSyncSession @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @D DATETIME
	SET @D = GETDATE()
	INSERT INTO [admin].SyncSession([Id], [StartTime], [EndTime]) VALUES(@SessionId,@D,NULL)
GO

CREATE PROCEDURE [admin].CommitSyncSession @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @D DATETIME
	SELECT @D = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @D IS NULL
	  RAISERROR('Session is not found', 16, 1)
	ELSE
	BEGIN
		UPDATE [admin].LastSyncTime SET LastTime = @D
		UPDATE [admin].SyncSession SET EndTime = GETDATE() WHERE [Id] = @SessionId
	END
GO

CREATE PROCEDURE [admin].Logon @UserName VARCHAR(100), @UserPassword VARCHAR(100), @ConfigName VARCHAR(100), @ConfigVersion VARCHAR(100) AS
	SET NOCOUNT ON
	DECLARE @SConfigName VARCHAR(100), @SConfigVersion VARCHAR(100)
	SET @SConfigName = 'BitMobile'
	SET @SConfigVersion = '1.0.0.7'

	IF @SConfigName <> @ConfigName OR @SConfigVersion <> @SConfigVersion
		RAISERROR('Invalid client version. The server configuration is "%s ver.%s"', 16, 1, @SConfigName, @SConfigVersion)
	ELSE
		SELECT TOP 1 Id FROM [Catalog].[User] WHERE UserName=@UserName AND Password=@UserPassword AND Role='SR'
GO

ALTER TABLE [Catalog].[User] ADD CONSTRAINT UQ_Catalog_User_UserName UNIQUE([UserName])
GO

---------------------------------------------------------CRUD OPERATIONS ----------------------------------------------------------
GO


CREATE PROCEDURE [Enum].[DataStatus_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[DataStatus](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[DataStatus_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[DataStatus] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[DataStatus_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[DataStatus] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[DataType_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[DataType](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[DataType_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[DataType] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[DataType_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[DataType] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[OutletConfirmationStatus_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[OutletConfirmationStatus](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[OutletConfirmationStatus_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[OutletConfirmationStatus] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[OutletConfirmationStatus_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[OutletConfirmationStatus] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[TypesOfUsers_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[TypesOfUsers](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[TypesOfUsers_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[TypesOfUsers] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[TypesOfUsers_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[TypesOfUsers] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[UploadType_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[UploadType](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[UploadType_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[UploadType] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[UploadType_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[UploadType] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[VisitStatus_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[VisitStatus](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[VisitStatus_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[VisitStatus] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[VisitStatus_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[VisitStatus] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[StatusTask_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[StatusTask](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[StatusTask_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[StatusTask] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[StatusTask_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[StatusTask] WHERE Id = @Id
GO




CREATE PROCEDURE [Enum].[OrderSatus_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Enum].[OrderSatus](
				[Id],				[Name],				[Description]			) 
	VALUES
	(
				@Id,				@Name,				@Description			)
GO

CREATE PROCEDURE [Enum].[OrderSatus_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(100),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Enum].[OrderSatus] SET
				[Id] = @Id,				[Name] = @Name,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Enum].[OrderSatus_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Enum].[OrderSatus] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Positions_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Positions](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[Positions_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Positions] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Positions_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Positions] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[User_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Manager UNIQUEIDENTIFIER,		@EMail VARCHAR(50),		@UserID UNIQUEIDENTIFIER,		@UserName VARCHAR(100),		@Role VARCHAR(25),		@Password VARCHAR(100),		@Position UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[User](
				[Id],				[Code],				[Description],				[Manager],				[EMail],				[UserID],				[UserName],				[Role],				[Password],				[Position]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Manager,				@EMail,				@UserID,				@UserName,				@Role,				@Password,				@Position			)
GO

CREATE PROCEDURE [Catalog].[User_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Manager UNIQUEIDENTIFIER,		@EMail VARCHAR(50),		@UserID UNIQUEIDENTIFIER,		@UserName VARCHAR(100),		@Role VARCHAR(25),		@Password VARCHAR(100),		@Position UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[User] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Manager] = @Manager,				[EMail] = @EMail,				[UserID] = @UserID,				[UserName] = @UserName,				[Role] = @Role,				[Password] = @Password,				[Position] = @Position			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[User_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[User] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Region_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Parent UNIQUEIDENTIFIER,		@Manager UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Region](
				[Id],				[Code],				[Description],				[Parent],				[Manager]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Parent,				@Manager			)
GO

CREATE PROCEDURE [Catalog].[Region_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Parent UNIQUEIDENTIFIER,		@Manager UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Region] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Parent] = @Parent,				[Manager] = @Manager			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Region_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Region] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Distributor_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Distributor](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[Distributor_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Distributor] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Distributor_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Distributor] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[OutletParameter_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@DataType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[OutletParameter](
				[Id],				[Code],				[Description],				[DataType]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@DataType			)
GO

CREATE PROCEDURE [Catalog].[OutletParameter_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@DataType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[OutletParameter] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[DataType] = @DataType			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[OutletParameter_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[OutletParameter] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[OutletType_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[OutletType](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[OutletType_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[OutletType] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[OutletType_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[OutletType] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[OutletClass_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[OutletClass](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[OutletClass_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[OutletClass] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[OutletClass_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[OutletClass] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Outlet_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Type UNIQUEIDENTIFIER,		@Class UNIQUEIDENTIFIER,		@Distributor UNIQUEIDENTIFIER,		@Address VARCHAR(100),		@ConfirmationStatus UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Outlet](
				[Id],				[Code],				[Description],				[Type],				[Class],				[Distributor],				[Address],				[ConfirmationStatus],				[Lattitude],				[Longitude]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Type,				@Class,				@Distributor,				@Address,				@ConfirmationStatus,				@Lattitude,				@Longitude			)
GO

CREATE PROCEDURE [Catalog].[Outlet_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Type UNIQUEIDENTIFIER,		@Class UNIQUEIDENTIFIER,		@Distributor UNIQUEIDENTIFIER,		@Address VARCHAR(100),		@ConfirmationStatus UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Outlet] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Type] = @Type,				[Class] = @Class,				[Distributor] = @Distributor,				[Address] = @Address,				[ConfirmationStatus] = @ConfirmationStatus,				[Lattitude] = @Lattitude,				[Longitude] = @Longitude			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Outlet_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Outlet] WHERE Id = @Id
GO



CREATE PROCEDURE [Catalog].[Outlet_Parameters_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Parameter UNIQUEIDENTIFIER,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Outlet_Parameters](
				[Id],				[Ref],				[LineNumber],				[Parameter],				[Value]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Parameter,				@Value			)
GO

CREATE PROCEDURE [Catalog].[Outlet_Parameters_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Parameter UNIQUEIDENTIFIER,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Outlet_Parameters] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Parameter] = @Parameter,				[Value] = @Value			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Outlet_Parameters_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Outlet_Parameters] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Outlet_Parameters_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Outlet_Parameters] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Catalog].[Territory_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Territory](
				[Id],				[Code],				[Description],				[Owner],				[SR]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Owner,				@SR			)
GO

CREATE PROCEDURE [Catalog].[Territory_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Territory] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Owner] = @Owner,				[SR] = @SR			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Territory_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Territory] WHERE Id = @Id
GO



CREATE PROCEDURE [Catalog].[Territory_Outlets_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Outlet UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Territory_Outlets](
				[Id],				[Ref],				[LineNumber],				[Outlet]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Outlet			)
GO

CREATE PROCEDURE [Catalog].[Territory_Outlets_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Outlet UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Territory_Outlets] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Outlet] = @Outlet			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Territory_Outlets_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Territory_Outlets] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Territory_Outlets_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Territory_Outlets] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Catalog].[Territory_SKUGroups_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Territory_SKUGroups](
				[Id],				[Ref],				[LineNumber],				[SKUGroup]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKUGroup			)
GO

CREATE PROCEDURE [Catalog].[Territory_SKUGroups_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Territory_SKUGroups] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKUGroup] = @SKUGroup			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Territory_SKUGroups_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Territory_SKUGroups] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Territory_SKUGroups_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Territory_SKUGroups] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Catalog].[QuestionGroup_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[QuestionGroup](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[QuestionGroup_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[QuestionGroup] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[QuestionGroup_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[QuestionGroup] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Question_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@AnswerType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Question](
				[Id],				[Code],				[Description],				[Owner],				[AnswerType]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Owner,				@AnswerType			)
GO

CREATE PROCEDURE [Catalog].[Question_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@AnswerType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Question] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Owner] = @Owner,				[AnswerType] = @AnswerType			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Question_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Question] WHERE Id = @Id
GO



CREATE PROCEDURE [Catalog].[Question_ValueList_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Question_ValueList](
				[Id],				[Ref],				[LineNumber],				[Value]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Value			)
GO

CREATE PROCEDURE [Catalog].[Question_ValueList_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Question_ValueList] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Value] = @Value			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Question_ValueList_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Question_ValueList] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Question_ValueList_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Question_ValueList] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Catalog].[SKUGroup_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Parent UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[SKUGroup](
				[Id],				[Code],				[Description],				[Parent]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Parent			)
GO

CREATE PROCEDURE [Catalog].[SKUGroup_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Parent UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[SKUGroup] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKUGroup_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKUGroup] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[Brands_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[Brands](
				[Id],				[Code],				[Description]			) 
	VALUES
	(
				@Id,				@Code,				@Description			)
GO

CREATE PROCEDURE [Catalog].[Brands_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[Brands] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[Brands_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[Brands] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[UnitsOfMeasure_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(25),		@FullDescription VARCHAR(50)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[UnitsOfMeasure](
				[Id],				[Code],				[Description],				[FullDescription]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@FullDescription			)
GO

CREATE PROCEDURE [Catalog].[UnitsOfMeasure_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(25),		@FullDescription VARCHAR(50)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[UnitsOfMeasure] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[FullDescription] = @FullDescription			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[UnitsOfMeasure_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[UnitsOfMeasure] WHERE Id = @Id
GO




CREATE PROCEDURE [Catalog].[SKU_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@Price DECIMAL(15,2),		@Brand UNIQUEIDENTIFIER,		@Stock DECIMAL(10,2),		@BaseUnit UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[SKU](
				[Id],				[Code],				[Description],				[Owner],				[Price],				[Brand],				[Stock],				[BaseUnit]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@Owner,				@Price,				@Brand,				@Stock,				@BaseUnit			)
GO

CREATE PROCEDURE [Catalog].[SKU_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@Owner UNIQUEIDENTIFIER,		@Price DECIMAL(15,2),		@Brand UNIQUEIDENTIFIER,		@Stock DECIMAL(10,2),		@BaseUnit UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[SKU] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[Owner] = @Owner,				[Price] = @Price,				[Brand] = @Brand,				[Stock] = @Stock,				[BaseUnit] = @BaseUnit			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKU_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKU] WHERE Id = @Id
GO



CREATE PROCEDURE [Catalog].[SKU_Packing_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Pack UNIQUEIDENTIFIER,		@Multiplier DECIMAL(10,2)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[SKU_Packing](
				[Id],				[Ref],				[LineNumber],				[Pack],				[Multiplier]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Pack,				@Multiplier			)
GO

CREATE PROCEDURE [Catalog].[SKU_Packing_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Pack UNIQUEIDENTIFIER,		@Multiplier DECIMAL(10,2)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[SKU_Packing] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Pack] = @Pack,				[Multiplier] = @Multiplier			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKU_Packing_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKU_Packing] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKU_Packing_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKU_Packing] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Catalog].[SKUQuestions_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@AnswerType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[SKUQuestions](
				[Id],				[Code],				[Description],				[AnswerType]			) 
	VALUES
	(
				@Id,				@Code,				@Description,				@AnswerType			)
GO

CREATE PROCEDURE [Catalog].[SKUQuestions_adm_update]
		@Id UNIQUEIDENTIFIER,		@Code VARCHAR(9),		@Description VARCHAR(100),		@AnswerType UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[SKUQuestions] SET
				[Id] = @Id,				[Code] = @Code,				[Description] = @Description,				[AnswerType] = @AnswerType			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKUQuestions_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKUQuestions] WHERE Id = @Id
GO



CREATE PROCEDURE [Catalog].[SKUQuestions_ValueList_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Catalog].[SKUQuestions_ValueList](
				[Id],				[Ref],				[LineNumber],				[Value]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Value			)
GO

CREATE PROCEDURE [Catalog].[SKUQuestions_ValueList_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Value VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Catalog].[SKUQuestions_ValueList] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Value] = @Value			WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKUQuestions_ValueList_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKUQuestions_ValueList] WHERE Id = @Id
GO

CREATE PROCEDURE [Catalog].[SKUQuestions_ValueList_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Catalog].[SKUQuestions_ValueList] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[PriceList_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[PriceList](
				[Id],				[Number],				[Date],				[Posted]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted			)
GO

CREATE PROCEDURE [Document].[PriceList_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT	AS
	SET NOCOUNT ON
	UPDATE [Document].[PriceList] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[PriceList_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[PriceList] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[PriceList_Prices_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Price DECIMAL(10,2),		@Stock DECIMAL(10,2)	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[PriceList_Prices](
				[Id],				[Ref],				[LineNumber],				[SKU],				[Price],				[Stock]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKU,				@Price,				@Stock			)
GO

CREATE PROCEDURE [Document].[PriceList_Prices_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Price DECIMAL(10,2),		@Stock DECIMAL(10,2)	AS
	SET NOCOUNT ON
	UPDATE [Document].[PriceList_Prices] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKU] = @SKU,				[Price] = @Price,				[Stock] = @Stock			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[PriceList_Prices_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[PriceList_Prices] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[PriceList_Prices_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[PriceList_Prices] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[Questionnaire_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@OutletType UNIQUEIDENTIFIER,		@OutletClass UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire](
				[Id],				[Number],				[Date],				[Posted],				[OutletType],				[OutletClass]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@OutletType,				@OutletClass			)
GO

CREATE PROCEDURE [Document].[Questionnaire_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@OutletType UNIQUEIDENTIFIER,		@OutletClass UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[OutletType] = @OutletType,				[OutletClass] = @OutletClass			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[Questionnaire_Questions_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire_Questions](
				[Id],				[Ref],				[LineNumber],				[Question]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Question			)
GO

CREATE PROCEDURE [Document].[Questionnaire_Questions_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire_Questions] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Question] = @Question			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_Questions_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_Questions] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_Questions_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_Questions] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Questionnaire_SKUs_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire_SKUs](
				[Id],				[Ref],				[LineNumber],				[SKU]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKU			)
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUs_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire_SKUs] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKU] = @SKU			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUs_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUs] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUs_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUs] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Questionnaire_SKUGroups_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire_SKUGroups](
				[Id],				[Ref],				[LineNumber],				[SKUGroup]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKUGroup			)
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUGroups_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire_SKUGroups] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKUGroup] = @SKUGroup			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUGroups_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUGroups] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUGroups_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUGroups] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Questionnaire_SKUQuestions_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUQuestion UNIQUEIDENTIFIER,		@UseInQuestionaire BIT	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire_SKUQuestions](
				[Id],				[Ref],				[LineNumber],				[SKUQuestion],				[UseInQuestionaire]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKUQuestion,				@UseInQuestionaire			)
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUQuestions_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUQuestion UNIQUEIDENTIFIER,		@UseInQuestionaire BIT	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire_SKUQuestions] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKUQuestion] = @SKUQuestion,				[UseInQuestionaire] = @UseInQuestionaire			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUQuestions_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUQuestions] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_SKUQuestions_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_SKUQuestions] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Questionnaire_Territories_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Territory UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Questionnaire_Territories](
				[Id],				[Ref],				[LineNumber],				[Territory]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Territory			)
GO

CREATE PROCEDURE [Document].[Questionnaire_Territories_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Territory UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Questionnaire_Territories] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Territory] = @Territory			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_Territories_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_Territories] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Questionnaire_Territories_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Questionnaire_Territories] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[Target_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Territory UNIQUEIDENTIFIER,		@OutletType UNIQUEIDENTIFIER,		@OutletClass UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Target](
				[Id],				[Number],				[Date],				[Posted],				[Territory],				[OutletType],				[OutletClass]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@Territory,				@OutletType,				@OutletClass			)
GO

CREATE PROCEDURE [Document].[Target_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Territory UNIQUEIDENTIFIER,		@OutletType UNIQUEIDENTIFIER,		@OutletClass UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Target] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[Territory] = @Territory,				[OutletType] = @OutletType,				[OutletClass] = @OutletClass			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Target_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Target] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[Target_Targets_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER,		@Value DECIMAL(10,2)	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Target_Targets](
				[Id],				[Ref],				[LineNumber],				[Question],				[Value]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Question,				@Value			)
GO

CREATE PROCEDURE [Document].[Target_Targets_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER,		@Value DECIMAL(10,2)	AS
	SET NOCOUNT ON
	UPDATE [Document].[Target_Targets] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Question] = @Question,				[Value] = @Value			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Target_Targets_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Target_Targets] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Target_Targets_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Target_Targets] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[VisitPlan_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Year DATETIME,		@WeekNumber INT,		@SR UNIQUEIDENTIFIER,		@Owner UNIQUEIDENTIFIER,		@DateFrom DATETIME,		@DateTo DATETIME	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[VisitPlan](
				[Id],				[Number],				[Date],				[Posted],				[Year],				[WeekNumber],				[SR],				[Owner],				[DateFrom],				[DateTo]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@Year,				@WeekNumber,				@SR,				@Owner,				@DateFrom,				@DateTo			)
GO

CREATE PROCEDURE [Document].[VisitPlan_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Year DATETIME,		@WeekNumber INT,		@SR UNIQUEIDENTIFIER,		@Owner UNIQUEIDENTIFIER,		@DateFrom DATETIME,		@DateTo DATETIME	AS
	SET NOCOUNT ON
	UPDATE [Document].[VisitPlan] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[Year] = @Year,				[WeekNumber] = @WeekNumber,				[SR] = @SR,				[Owner] = @Owner,				[DateFrom] = @DateFrom,				[DateTo] = @DateTo			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[VisitPlan_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[VisitPlan] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[VisitPlan_Outlets_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Outlet UNIQUEIDENTIFIER,		@Date DATETIME	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[VisitPlan_Outlets](
				[Id],				[Ref],				[LineNumber],				[Outlet],				[Date]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Outlet,				@Date			)
GO

CREATE PROCEDURE [Document].[VisitPlan_Outlets_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Outlet UNIQUEIDENTIFIER,		@Date DATETIME	AS
	SET NOCOUNT ON
	UPDATE [Document].[VisitPlan_Outlets] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Outlet] = @Outlet,				[Date] = @Date			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[VisitPlan_Outlets_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[VisitPlan_Outlets] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[VisitPlan_Outlets_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[VisitPlan_Outlets] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[Visit_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Outlet UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER,		@Status UNIQUEIDENTIFIER,		@StartTime DATETIME,		@EndTime DATETIME,		@Encashment DECIMAL(15,2),		@Plan UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8)	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Visit](
				[Id],				[Number],				[Date],				[Posted],				[Outlet],				[SR],				[Status],				[StartTime],				[EndTime],				[Encashment],				[Plan],				[Lattitude],				[Longitude]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@Outlet,				@SR,				@Status,				@StartTime,				@EndTime,				@Encashment,				@Plan,				@Lattitude,				@Longitude			)
GO

CREATE PROCEDURE [Document].[Visit_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Outlet UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER,		@Status UNIQUEIDENTIFIER,		@StartTime DATETIME,		@EndTime DATETIME,		@Encashment DECIMAL(15,2),		@Plan UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8)	AS
	SET NOCOUNT ON
	UPDATE [Document].[Visit] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[Outlet] = @Outlet,				[SR] = @SR,				[Status] = @Status,				[StartTime] = @StartTime,				[EndTime] = @EndTime,				[Encashment] = @Encashment,				[Plan] = @Plan,				[Lattitude] = @Lattitude,				[Longitude] = @Longitude			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[Visit_Questions_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER,		@Answer VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Visit_Questions](
				[Id],				[Ref],				[LineNumber],				[Question],				[Answer]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@Question,				@Answer			)
GO

CREATE PROCEDURE [Document].[Visit_Questions_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@Question UNIQUEIDENTIFIER,		@Answer VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Document].[Visit_Questions] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[Question] = @Question,				[Answer] = @Answer			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_Questions_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_Questions] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_Questions_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_Questions] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Visit_SKUs_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Available BIT,		@Facing INT,		@Stock INT,		@Price INT,		@MarkUp INT,		@OutOfStock BIT	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Visit_SKUs](
				[Id],				[Ref],				[LineNumber],				[SKU],				[Available],				[Facing],				[Stock],				[Price],				[MarkUp],				[OutOfStock]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKU,				@Available,				@Facing,				@Stock,				@Price,				@MarkUp,				@OutOfStock			)
GO

CREATE PROCEDURE [Document].[Visit_SKUs_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Available BIT,		@Facing INT,		@Stock INT,		@Price INT,		@MarkUp INT,		@OutOfStock BIT	AS
	SET NOCOUNT ON
	UPDATE [Document].[Visit_SKUs] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKU] = @SKU,				[Available] = @Available,				[Facing] = @Facing,				[Stock] = @Stock,				[Price] = @Price,				[MarkUp] = @MarkUp,				[OutOfStock] = @OutOfStock			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_SKUs_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_SKUs] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_SKUs_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_SKUs] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Visit_SKUGroups_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER,		@Available BIT	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Visit_SKUGroups](
				[Id],				[Ref],				[LineNumber],				[SKUGroup],				[Available]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKUGroup,				@Available			)
GO

CREATE PROCEDURE [Document].[Visit_SKUGroups_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKUGroup UNIQUEIDENTIFIER,		@Available BIT	AS
	SET NOCOUNT ON
	UPDATE [Document].[Visit_SKUGroups] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKUGroup] = @SKUGroup,				[Available] = @Available			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_SKUGroups_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_SKUGroups] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_SKUGroups_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_SKUGroups] WHERE Ref = @Ref
GO


CREATE PROCEDURE [Document].[Visit_Task_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@TextTask VARCHAR(100),		@Result VARCHAR(100),		@TaskRef UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Visit_Task](
				[Id],				[Ref],				[LineNumber],				[TextTask],				[Result],				[TaskRef]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@TextTask,				@Result,				@TaskRef			)
GO

CREATE PROCEDURE [Document].[Visit_Task_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@TextTask VARCHAR(100),		@Result VARCHAR(100),		@TaskRef UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Visit_Task] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[TextTask] = @TextTask,				[Result] = @Result,				[TaskRef] = @TaskRef			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_Task_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_Task] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Visit_Task_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Visit_Task] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[Order_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Outlet UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER,		@DeliveryDate DATETIME,		@Commentary VARCHAR(100),		@Visit UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8),		@Status UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Order](
				[Id],				[Number],				[Date],				[Posted],				[Outlet],				[SR],				[DeliveryDate],				[Commentary],				[Visit],				[Lattitude],				[Longitude],				[Status]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@Outlet,				@SR,				@DeliveryDate,				@Commentary,				@Visit,				@Lattitude,				@Longitude,				@Status			)
GO

CREATE PROCEDURE [Document].[Order_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Outlet UNIQUEIDENTIFIER,		@SR UNIQUEIDENTIFIER,		@DeliveryDate DATETIME,		@Commentary VARCHAR(100),		@Visit UNIQUEIDENTIFIER,		@Lattitude DECIMAL(10,8),		@Longitude DECIMAL(10,8),		@Status UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Order] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[Outlet] = @Outlet,				[SR] = @SR,				[DeliveryDate] = @DeliveryDate,				[Commentary] = @Commentary,				[Visit] = @Visit,				[Lattitude] = @Lattitude,				[Longitude] = @Longitude,				[Status] = @Status			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Order_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Order] WHERE Id = @Id
GO



CREATE PROCEDURE [Document].[Order_SKUs_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Qty DECIMAL(15,1),		@Price DECIMAL(15,2),		@Discount INT,		@Total DECIMAL(10,2),		@Amount DECIMAL(15,2),		@Units UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Order_SKUs](
				[Id],				[Ref],				[LineNumber],				[SKU],				[Qty],				[Price],				[Discount],				[Total],				[Amount],				[Units]			) 
	VALUES
	(
				@Id,				@Ref,				@LineNumber,				@SKU,				@Qty,				@Price,				@Discount,				@Total,				@Amount,				@Units			)
GO

CREATE PROCEDURE [Document].[Order_SKUs_adm_update]
		@Id UNIQUEIDENTIFIER,		@Ref UNIQUEIDENTIFIER,		@LineNumber INT,		@SKU UNIQUEIDENTIFIER,		@Qty DECIMAL(15,1),		@Price DECIMAL(15,2),		@Discount INT,		@Total DECIMAL(10,2),		@Amount DECIMAL(15,2),		@Units UNIQUEIDENTIFIER	AS
	SET NOCOUNT ON
	UPDATE [Document].[Order_SKUs] SET
				[Id] = @Id,				[Ref] = @Ref,				[LineNumber] = @LineNumber,				[SKU] = @SKU,				[Qty] = @Qty,				[Price] = @Price,				[Discount] = @Discount,				[Total] = @Total,				[Amount] = @Amount,				[Units] = @Units			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Order_SKUs_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Order_SKUs] WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Order_SKUs_adm_clear] @Ref UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Order_SKUs] WHERE Ref = @Ref
GO



CREATE PROCEDURE [Document].[Task_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Territory UNIQUEIDENTIFIER,		@Outlet UNIQUEIDENTIFIER,		@StatusTask UNIQUEIDENTIFIER,		@TextTask VARCHAR(100),		@VisitPlan UNIQUEIDENTIFIER,		@PlanDate DATETIME,		@TypeOfResultAndGoals UNIQUEIDENTIFIER,		@Result VARCHAR(100),		@FactDate DATETIME,		@Target VARCHAR(100)	AS
	SET NOCOUNT ON
	INSERT INTO [Document].[Task](
				[Id],				[Number],				[Date],				[Posted],				[Territory],				[Outlet],				[StatusTask],				[TextTask],				[VisitPlan],				[PlanDate],				[TypeOfResultAndGoals],				[Result],				[FactDate],				[Target]			) 
	VALUES
	(
				@Id,				@Number,				@Date,				@Posted,				@Territory,				@Outlet,				@StatusTask,				@TextTask,				@VisitPlan,				@PlanDate,				@TypeOfResultAndGoals,				@Result,				@FactDate,				@Target			)
GO

CREATE PROCEDURE [Document].[Task_adm_update]
		@Id UNIQUEIDENTIFIER,		@Number VARCHAR(9),		@Date DATETIME,		@Posted BIT,		@Territory UNIQUEIDENTIFIER,		@Outlet UNIQUEIDENTIFIER,		@StatusTask UNIQUEIDENTIFIER,		@TextTask VARCHAR(100),		@VisitPlan UNIQUEIDENTIFIER,		@PlanDate DATETIME,		@TypeOfResultAndGoals UNIQUEIDENTIFIER,		@Result VARCHAR(100),		@FactDate DATETIME,		@Target VARCHAR(100)	AS
	SET NOCOUNT ON
	UPDATE [Document].[Task] SET
				[Id] = @Id,				[Number] = @Number,				[Date] = @Date,				[Posted] = @Posted,				[Territory] = @Territory,				[Outlet] = @Outlet,				[StatusTask] = @StatusTask,				[TextTask] = @TextTask,				[VisitPlan] = @VisitPlan,				[PlanDate] = @PlanDate,				[TypeOfResultAndGoals] = @TypeOfResultAndGoals,				[Result] = @Result,				[FactDate] = @FactDate,				[Target] = @Target			WHERE Id = @Id
GO

CREATE PROCEDURE [Document].[Task_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [Document].[Task] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[BusinessProcess_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[BusinessProcess](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[BusinessProcess_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[BusinessProcess] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[BusinessProcess_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[BusinessProcess] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[Image_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[Image](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[Image_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[Image] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[Image_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[Image] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[Screen_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[Screen](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[Screen_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[Screen] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[Screen_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[Screen] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[Script_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[Script](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[Script_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[Script] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[Script_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[Script] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[Style_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[Style](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[Style_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[Style] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[Style_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[Style] WHERE Id = @Id
GO




CREATE PROCEDURE [resource].[Translation_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	INSERT INTO [resource].[Translation](
				[Id],				[Name],				[Data],				[Parent]			) 
	VALUES
	(
				@Id,				@Name,				@Data,				@Parent			)
GO

CREATE PROCEDURE [resource].[Translation_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Data NTEXT,		@Parent VARCHAR(250)	AS
	SET NOCOUNT ON
	UPDATE [resource].[Translation] SET
				[Id] = @Id,				[Name] = @Name,				[Data] = @Data,				[Parent] = @Parent			WHERE Id = @Id
GO

CREATE PROCEDURE [resource].[Translation_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [resource].[Translation] WHERE Id = @Id
GO




CREATE PROCEDURE [admin].[Entity_adm_insert]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Schema VARCHAR(50),		@ShortName VARCHAR(50)	AS
	SET NOCOUNT ON
	INSERT INTO [admin].[Entity](
				[Id],				[Name],				[Schema],				[ShortName]			) 
	VALUES
	(
				@Id,				@Name,				@Schema,				@ShortName			)
GO

CREATE PROCEDURE [admin].[Entity_adm_update]
		@Id UNIQUEIDENTIFIER,		@Name VARCHAR(250),		@Schema VARCHAR(50),		@ShortName VARCHAR(50)	AS
	SET NOCOUNT ON
	UPDATE [admin].[Entity] SET
				[Id] = @Id,				[Name] = @Name,				[Schema] = @Schema,				[ShortName] = @ShortName			WHERE Id = @Id
GO

CREATE PROCEDURE [admin].[Entity_adm_delete] @Id UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DELETE FROM [admin].[Entity] WHERE Id = @Id
GO




---------------------------------------------------------SYNC GETCHANGES ----------------------------------------------------------
GO


CREATE PROCEDURE [Enum].[DataStatus_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[DataStatus] E
	JOIN [Enum].[DataStatus_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.DataStatus' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[DataStatus] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[DataType_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[DataType] E
	JOIN [Enum].[DataType_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.DataType' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[DataType] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[OutletConfirmationStatus_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[OutletConfirmationStatus] E
	JOIN [Enum].[OutletConfirmationStatus_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.OutletConfirmationStatus' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[OutletConfirmationStatus] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[TypesOfUsers_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[TypesOfUsers] E
	JOIN [Enum].[TypesOfUsers_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.TypesOfUsers' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[TypesOfUsers] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[UploadType_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[UploadType] E
	JOIN [Enum].[UploadType_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.UploadType' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[UploadType] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[VisitStatus_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[VisitStatus] E
	JOIN [Enum].[VisitStatus_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.VisitStatus' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[VisitStatus] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[StatusTask_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[StatusTask] E
	JOIN [Enum].[StatusTask_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.StatusTask' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[StatusTask] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Enum].[OrderSatus_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Enum].[OrderSatus] E
	JOIN [Enum].[OrderSatus_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Enum.OrderSatus' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Description] AS [Row!2!Description]							FROM [Enum].[OrderSatus] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Positions_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Positions] E
	JOIN [Catalog].[Positions_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Positions' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[Positions] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[User_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[User] E
	JOIN [Catalog].[User_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.User' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Manager],NULL AS [Row!2!EMail],NULL AS [Row!2!UserID],NULL AS [Row!2!UserName],NULL AS [Row!2!Role],NULL AS [Row!2!Password],NULL AS [Row!2!Position]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Manager] AS [Row!2!Manager],H.[EMail] AS [Row!2!EMail],H.[UserID] AS [Row!2!UserID],H.[UserName] AS [Row!2!UserName],H.[Role] AS [Row!2!Role],H.[Password] AS [Row!2!Password],H.[Position] AS [Row!2!Position]							FROM [Catalog].[User] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Region_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Region] E
	JOIN [Catalog].[Region_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Region' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Parent],NULL AS [Row!2!Manager]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Parent] AS [Row!2!Parent],H.[Manager] AS [Row!2!Manager]							FROM [Catalog].[Region] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Distributor_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Distributor] E
	JOIN [Catalog].[Distributor_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Distributor' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[Distributor] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[OutletParameter_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[OutletParameter] E
	JOIN [Catalog].[OutletParameter_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.OutletParameter' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!DataType]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[DataType] AS [Row!2!DataType]							FROM [Catalog].[OutletParameter] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[OutletType_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[OutletType] E
	JOIN [Catalog].[OutletType_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.OutletType' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[OutletType] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[OutletClass_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[OutletClass] E
	JOIN [Catalog].[OutletClass_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.OutletClass' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[OutletClass] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Outlet_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Outlet] E
	JOIN [Catalog].[Outlet_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Catalog].[Outlet_Parameters] E
	JOIN [Catalog].[Outlet_Parameters_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Outlet' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Type],NULL AS [Row!2!Class],NULL AS [Row!2!Distributor],NULL AS [Row!2!Address],NULL AS [Row!2!ConfirmationStatus],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]						,NULL AS [Parameters!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Parameter]
					,NULL AS [Row!12!Value]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Type] AS [Row!2!Type],H.[Class] AS [Row!2!Class],H.[Distributor] AS [Row!2!Distributor],H.[Address] AS [Row!2!Address],H.[ConfirmationStatus] AS [Row!2!ConfirmationStatus],H.[Lattitude] AS [Row!2!Lattitude],H.[Longitude] AS [Row!2!Longitude]						,NULL AS [Parameters!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Parameter]
					,NULL AS [Row!12!Value]
				FROM [Catalog].[Outlet] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Type],NULL AS [Row!2!Class],NULL AS [Row!2!Distributor],NULL AS [Row!2!Address],NULL AS [Row!2!ConfirmationStatus],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Parameters!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Parameter]
					,NULL AS [Row!12!Value]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Type],NULL AS [Row!2!Class],NULL AS [Row!2!Distributor],NULL AS [Row!2!Address],NULL AS [Row!2!ConfirmationStatus],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Parameters!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Parameter AS [Row!12!Parameter]								 ,T.Value AS [Row!12!Value]							FROM @Ids Ids
	JOIN [Catalog].[Outlet_Parameters] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Territory_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Territory] E
	JOIN [Catalog].[Territory_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Catalog].[Territory_Outlets] E
	JOIN [Catalog].[Territory_Outlets_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Catalog].[Territory_SKUGroups] E
	JOIN [Catalog].[Territory_SKUGroups_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Territory' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!SR]						,NULL AS [Outlets!11]
						,NULL AS [SKUGroups!21]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUGroup]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Owner] AS [Row!2!Owner],H.[SR] AS [Row!2!SR]						,NULL AS [Outlets!11]
						,NULL AS [SKUGroups!21]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUGroup]
				FROM [Catalog].[Territory] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!SR]			,NULL AS [Outlets!11]
				,NULL AS [SKUGroups!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKUGroup]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!SR]			,NULL AS [Outlets!11]
				,NULL AS [SKUGroups!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Outlet AS [Row!12!Outlet]															 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKUGroup]				FROM @Ids Ids
	JOIN [Catalog].[Territory_Outlets] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	21 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!SR]			,NULL AS [Outlets!21]
				,NULL AS [SKUGroups!21]
										,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!Outlet]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUGroup]
				FROM @Ids Ids

	UNION ALL

	SELECT
	22 AS Tag, 21 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!SR]			,NULL AS [Outlets!21]
				,NULL AS [SKUGroups!21]
													 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!Outlet]									 ,T.Id AS [Row!22!Id]								 ,T.Ref AS [Row!22!Ref]								 ,T.LineNumber AS [Row!22!LineNumber]								 ,T.SKUGroup AS [Row!22!SKUGroup]							FROM @Ids Ids
	JOIN [Catalog].[Territory_SKUGroups] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[QuestionGroup_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[QuestionGroup] E
	JOIN [Catalog].[QuestionGroup_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.QuestionGroup' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[QuestionGroup] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Question_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Question] E
	JOIN [Catalog].[Question_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Catalog].[Question_ValueList] E
	JOIN [Catalog].[Question_ValueList_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Question' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!AnswerType]						,NULL AS [ValueList!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Owner] AS [Row!2!Owner],H.[AnswerType] AS [Row!2!AnswerType]						,NULL AS [ValueList!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
				FROM [Catalog].[Question] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!AnswerType]			,NULL AS [ValueList!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!AnswerType]			,NULL AS [ValueList!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Value AS [Row!12!Value]							FROM @Ids Ids
	JOIN [Catalog].[Question_ValueList] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[SKUGroup_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[SKUGroup] E
	JOIN [Catalog].[SKUGroup_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.SKUGroup' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Parent] AS [Row!2!Parent]							FROM [Catalog].[SKUGroup] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[Brands_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[Brands] E
	JOIN [Catalog].[Brands_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.Brands' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description]							FROM [Catalog].[Brands] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[UnitsOfMeasure_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[UnitsOfMeasure] E
	JOIN [Catalog].[UnitsOfMeasure_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.UnitsOfMeasure' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!FullDescription]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[FullDescription] AS [Row!2!FullDescription]							FROM [Catalog].[UnitsOfMeasure] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[SKU_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[SKU] E
	JOIN [Catalog].[SKU_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Catalog].[SKU_Packing] E
	JOIN [Catalog].[SKU_Packing_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.SKU' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!Price],NULL AS [Row!2!Brand],NULL AS [Row!2!Stock],NULL AS [Row!2!BaseUnit]						,NULL AS [Packing!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Pack]
					,NULL AS [Row!12!Multiplier]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[Owner] AS [Row!2!Owner],H.[Price] AS [Row!2!Price],H.[Brand] AS [Row!2!Brand],H.[Stock] AS [Row!2!Stock],H.[BaseUnit] AS [Row!2!BaseUnit]						,NULL AS [Packing!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Pack]
					,NULL AS [Row!12!Multiplier]
				FROM [Catalog].[SKU] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!Price],NULL AS [Row!2!Brand],NULL AS [Row!2!Stock],NULL AS [Row!2!BaseUnit]			,NULL AS [Packing!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Pack]
					,NULL AS [Row!12!Multiplier]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!Owner],NULL AS [Row!2!Price],NULL AS [Row!2!Brand],NULL AS [Row!2!Stock],NULL AS [Row!2!BaseUnit]			,NULL AS [Packing!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Pack AS [Row!12!Pack]								 ,T.Multiplier AS [Row!12!Multiplier]							FROM @Ids Ids
	JOIN [Catalog].[SKU_Packing] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Catalog].[SKUQuestions_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Catalog].[SKUQuestions] E
	JOIN [Catalog].[SKUQuestions_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Catalog].[SKUQuestions_ValueList] E
	JOIN [Catalog].[SKUQuestions_ValueList_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Catalog.SKUQuestions' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!AnswerType]						,NULL AS [ValueList!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Code] AS [Row!2!Code],H.[Description] AS [Row!2!Description],H.[AnswerType] AS [Row!2!AnswerType]						,NULL AS [ValueList!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
				FROM [Catalog].[SKUQuestions] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!AnswerType]			,NULL AS [ValueList!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Value]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Code],NULL AS [Row!2!Description],NULL AS [Row!2!AnswerType]			,NULL AS [ValueList!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Value AS [Row!12!Value]							FROM @Ids Ids
	JOIN [Catalog].[SKUQuestions_ValueList] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[PriceList_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[PriceList] E
	JOIN [Document].[PriceList_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[PriceList_Prices] E
	JOIN [Document].[PriceList_Prices_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.PriceList' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted]						,NULL AS [Prices!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Stock]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted]						,NULL AS [Prices!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Stock]
				FROM [Document].[PriceList] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted]			,NULL AS [Prices!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Stock]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted]			,NULL AS [Prices!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.SKU AS [Row!12!SKU]								 ,T.Price AS [Row!12!Price]								 ,T.Stock AS [Row!12!Stock]							FROM @Ids Ids
	JOIN [Document].[PriceList_Prices] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[Questionnaire_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[Questionnaire] E
	JOIN [Document].[Questionnaire_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[Questionnaire_Questions] E
	JOIN [Document].[Questionnaire_Questions_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Questionnaire_SKUs] E
	JOIN [Document].[Questionnaire_SKUs_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Questionnaire_SKUGroups] E
	JOIN [Document].[Questionnaire_SKUGroups_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Questionnaire_SKUQuestions] E
	JOIN [Document].[Questionnaire_SKUQuestions_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Questionnaire_Territories] E
	JOIN [Document].[Questionnaire_Territories_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.Questionnaire' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]						,NULL AS [Questions!11]
						,NULL AS [SKUs!21]
						,NULL AS [SKUGroups!31]
						,NULL AS [SKUQuestions!41]
						,NULL AS [Territories!51]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
												,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
												,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKUQuestion]
					,NULL AS [Row!42!UseInQuestionaire]
												,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!Territory]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[OutletType] AS [Row!2!OutletType],H.[OutletClass] AS [Row!2!OutletClass]						,NULL AS [Questions!11]
						,NULL AS [SKUs!21]
						,NULL AS [SKUGroups!31]
						,NULL AS [SKUQuestions!41]
						,NULL AS [Territories!51]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
												,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
												,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKUQuestion]
					,NULL AS [Row!42!UseInQuestionaire]
												,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!Territory]
				FROM [Document].[Questionnaire] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!11]
				,NULL AS [SKUs!11]
				,NULL AS [SKUGroups!11]
				,NULL AS [SKUQuestions!11]
				,NULL AS [Territories!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKUGroup]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKUQuestion]
					,NULL AS [Row!12!UseInQuestionaire]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Territory]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!11]
				,NULL AS [SKUs!11]
				,NULL AS [SKUGroups!11]
				,NULL AS [SKUQuestions!11]
				,NULL AS [Territories!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Question AS [Row!12!Question]															 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKU]												 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKUGroup]												 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKUQuestion]								 ,NULL AS [Row!12!UseInQuestionaire]												 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!Territory]				FROM @Ids Ids
	JOIN [Document].[Questionnaire_Questions] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	21 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!21]
				,NULL AS [SKUs!21]
				,NULL AS [SKUGroups!21]
				,NULL AS [SKUQuestions!21]
				,NULL AS [Territories!21]
										,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!Question]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUGroup]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUQuestion]
					,NULL AS [Row!22!UseInQuestionaire]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!Territory]
				FROM @Ids Ids

	UNION ALL

	SELECT
	22 AS Tag, 21 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!21]
				,NULL AS [SKUs!21]
				,NULL AS [SKUGroups!21]
				,NULL AS [SKUQuestions!21]
				,NULL AS [Territories!21]
													 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!Question]									 ,T.Id AS [Row!22!Id]								 ,T.Ref AS [Row!22!Ref]								 ,T.LineNumber AS [Row!22!LineNumber]								 ,T.SKU AS [Row!22!SKU]															 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!SKUGroup]												 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!SKUQuestion]								 ,NULL AS [Row!22!UseInQuestionaire]												 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!Territory]				FROM @Ids Ids
	JOIN [Document].[Questionnaire_SKUs] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	31 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!31]
				,NULL AS [SKUs!31]
				,NULL AS [SKUGroups!31]
				,NULL AS [SKUQuestions!31]
				,NULL AS [Territories!31]
										,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!Question]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKU]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUQuestion]
					,NULL AS [Row!32!UseInQuestionaire]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!Territory]
				FROM @Ids Ids

	UNION ALL

	SELECT
	32 AS Tag, 31 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!31]
				,NULL AS [SKUs!31]
				,NULL AS [SKUGroups!31]
				,NULL AS [SKUQuestions!31]
				,NULL AS [Territories!31]
													 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!Question]												 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!SKU]									 ,T.Id AS [Row!32!Id]								 ,T.Ref AS [Row!32!Ref]								 ,T.LineNumber AS [Row!32!LineNumber]								 ,T.SKUGroup AS [Row!32!SKUGroup]															 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!SKUQuestion]								 ,NULL AS [Row!32!UseInQuestionaire]												 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!Territory]				FROM @Ids Ids
	JOIN [Document].[Questionnaire_SKUGroups] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	41 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!41]
				,NULL AS [SKUs!41]
				,NULL AS [SKUGroups!41]
				,NULL AS [SKUQuestions!41]
				,NULL AS [Territories!41]
										,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!Question]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKU]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKUGroup]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKUQuestion]
					,NULL AS [Row!42!UseInQuestionaire]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!Territory]
				FROM @Ids Ids

	UNION ALL

	SELECT
	42 AS Tag, 41 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!41]
				,NULL AS [SKUs!41]
				,NULL AS [SKUGroups!41]
				,NULL AS [SKUQuestions!41]
				,NULL AS [Territories!41]
													 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!Question]												 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!SKU]												 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!SKUGroup]									 ,T.Id AS [Row!42!Id]								 ,T.Ref AS [Row!42!Ref]								 ,T.LineNumber AS [Row!42!LineNumber]								 ,T.SKUQuestion AS [Row!42!SKUQuestion]								 ,T.UseInQuestionaire AS [Row!42!UseInQuestionaire]															 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!Territory]				FROM @Ids Ids
	JOIN [Document].[Questionnaire_SKUQuestions] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	51 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!51]
				,NULL AS [SKUs!51]
				,NULL AS [SKUGroups!51]
				,NULL AS [SKUQuestions!51]
				,NULL AS [Territories!51]
										,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!Question]
									,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!SKU]
									,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!SKUGroup]
									,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!SKUQuestion]
					,NULL AS [Row!52!UseInQuestionaire]
									,NULL AS [Row!52!Id]
					,NULL AS [Row!52!Ref]
					,NULL AS [Row!52!LineNumber]
					,NULL AS [Row!52!Territory]
				FROM @Ids Ids

	UNION ALL

	SELECT
	52 AS Tag, 51 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Questions!51]
				,NULL AS [SKUs!51]
				,NULL AS [SKUGroups!51]
				,NULL AS [SKUQuestions!51]
				,NULL AS [Territories!51]
													 ,NULL AS [Row!52!Id]								 ,NULL AS [Row!52!Ref]								 ,NULL AS [Row!52!LineNumber]								 ,NULL AS [Row!52!Question]												 ,NULL AS [Row!52!Id]								 ,NULL AS [Row!52!Ref]								 ,NULL AS [Row!52!LineNumber]								 ,NULL AS [Row!52!SKU]												 ,NULL AS [Row!52!Id]								 ,NULL AS [Row!52!Ref]								 ,NULL AS [Row!52!LineNumber]								 ,NULL AS [Row!52!SKUGroup]												 ,NULL AS [Row!52!Id]								 ,NULL AS [Row!52!Ref]								 ,NULL AS [Row!52!LineNumber]								 ,NULL AS [Row!52!SKUQuestion]								 ,NULL AS [Row!52!UseInQuestionaire]									 ,T.Id AS [Row!52!Id]								 ,T.Ref AS [Row!52!Ref]								 ,T.LineNumber AS [Row!52!LineNumber]								 ,T.Territory AS [Row!52!Territory]							FROM @Ids Ids
	JOIN [Document].[Questionnaire_Territories] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[Target_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[Target] E
	JOIN [Document].[Target_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[Target_Targets] E
	JOIN [Document].[Target_Targets_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.Target' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Territory],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]						,NULL AS [Targets!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Value]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[Territory] AS [Row!2!Territory],H.[OutletType] AS [Row!2!OutletType],H.[OutletClass] AS [Row!2!OutletClass]						,NULL AS [Targets!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Value]
				FROM [Document].[Target] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Territory],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Targets!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Value]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Territory],NULL AS [Row!2!OutletType],NULL AS [Row!2!OutletClass]			,NULL AS [Targets!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Question AS [Row!12!Question]								 ,T.Value AS [Row!12!Value]							FROM @Ids Ids
	JOIN [Document].[Target_Targets] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[VisitPlan_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[VisitPlan] E
	JOIN [Document].[VisitPlan_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[VisitPlan_Outlets] E
	JOIN [Document].[VisitPlan_Outlets_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.VisitPlan' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Year],NULL AS [Row!2!WeekNumber],NULL AS [Row!2!SR],NULL AS [Row!2!Owner],NULL AS [Row!2!DateFrom],NULL AS [Row!2!DateTo]						,NULL AS [Outlets!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
					,NULL AS [Row!12!Date]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[Year] AS [Row!2!Year],H.[WeekNumber] AS [Row!2!WeekNumber],H.[SR] AS [Row!2!SR],H.[Owner] AS [Row!2!Owner],H.[DateFrom] AS [Row!2!DateFrom],H.[DateTo] AS [Row!2!DateTo]						,NULL AS [Outlets!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
					,NULL AS [Row!12!Date]
				FROM [Document].[VisitPlan] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Year],NULL AS [Row!2!WeekNumber],NULL AS [Row!2!SR],NULL AS [Row!2!Owner],NULL AS [Row!2!DateFrom],NULL AS [Row!2!DateTo]			,NULL AS [Outlets!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Outlet]
					,NULL AS [Row!12!Date]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Year],NULL AS [Row!2!WeekNumber],NULL AS [Row!2!SR],NULL AS [Row!2!Owner],NULL AS [Row!2!DateFrom],NULL AS [Row!2!DateTo]			,NULL AS [Outlets!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Outlet AS [Row!12!Outlet]								 ,T.Date AS [Row!12!Date]							FROM @Ids Ids
	JOIN [Document].[VisitPlan_Outlets] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[Visit_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[Visit] E
	JOIN [Document].[Visit_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[Visit_Questions] E
	JOIN [Document].[Visit_Questions_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Visit_SKUs] E
	JOIN [Document].[Visit_SKUs_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Visit_SKUGroups] E
	JOIN [Document].[Visit_SKUGroups_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
		UNION
	SELECT E.Ref 
	FROM [Document].[Visit_Task] E
	JOIN [Document].[Visit_Task_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.Visit' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]						,NULL AS [Questions!11]
						,NULL AS [SKUs!21]
						,NULL AS [SKUGroups!31]
						,NULL AS [Task!41]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Answer]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
					,NULL AS [Row!22!Available]
					,NULL AS [Row!22!Facing]
					,NULL AS [Row!22!Stock]
					,NULL AS [Row!22!Price]
					,NULL AS [Row!22!MarkUp]
					,NULL AS [Row!22!OutOfStock]
												,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
					,NULL AS [Row!32!Available]
												,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!TextTask]
					,NULL AS [Row!42!Result]
					,NULL AS [Row!42!TaskRef]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[Outlet] AS [Row!2!Outlet],H.[SR] AS [Row!2!SR],H.[Status] AS [Row!2!Status],H.[StartTime] AS [Row!2!StartTime],H.[EndTime] AS [Row!2!EndTime],H.[Encashment] AS [Row!2!Encashment],H.[Plan] AS [Row!2!Plan],H.[Lattitude] AS [Row!2!Lattitude],H.[Longitude] AS [Row!2!Longitude]						,NULL AS [Questions!11]
						,NULL AS [SKUs!21]
						,NULL AS [SKUGroups!31]
						,NULL AS [Task!41]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Answer]
												,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
					,NULL AS [Row!22!Available]
					,NULL AS [Row!22!Facing]
					,NULL AS [Row!22!Stock]
					,NULL AS [Row!22!Price]
					,NULL AS [Row!22!MarkUp]
					,NULL AS [Row!22!OutOfStock]
												,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
					,NULL AS [Row!32!Available]
												,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!TextTask]
					,NULL AS [Row!42!Result]
					,NULL AS [Row!42!TaskRef]
				FROM [Document].[Visit] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!11]
				,NULL AS [SKUs!11]
				,NULL AS [SKUGroups!11]
				,NULL AS [Task!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!Question]
					,NULL AS [Row!12!Answer]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Available]
					,NULL AS [Row!12!Facing]
					,NULL AS [Row!12!Stock]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!MarkUp]
					,NULL AS [Row!12!OutOfStock]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKUGroup]
					,NULL AS [Row!12!Available]
									,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!TextTask]
					,NULL AS [Row!12!Result]
					,NULL AS [Row!12!TaskRef]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!11]
				,NULL AS [SKUs!11]
				,NULL AS [SKUGroups!11]
				,NULL AS [Task!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.Question AS [Row!12!Question]								 ,T.Answer AS [Row!12!Answer]															 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKU]								 ,NULL AS [Row!12!Available]								 ,NULL AS [Row!12!Facing]								 ,NULL AS [Row!12!Stock]								 ,NULL AS [Row!12!Price]								 ,NULL AS [Row!12!MarkUp]								 ,NULL AS [Row!12!OutOfStock]												 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!SKUGroup]								 ,NULL AS [Row!12!Available]												 ,NULL AS [Row!12!Id]								 ,NULL AS [Row!12!Ref]								 ,NULL AS [Row!12!LineNumber]								 ,NULL AS [Row!12!TextTask]								 ,NULL AS [Row!12!Result]								 ,NULL AS [Row!12!TaskRef]				FROM @Ids Ids
	JOIN [Document].[Visit_Questions] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	21 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!21]
				,NULL AS [SKUs!21]
				,NULL AS [SKUGroups!21]
				,NULL AS [Task!21]
										,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!Question]
					,NULL AS [Row!22!Answer]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKU]
					,NULL AS [Row!22!Available]
					,NULL AS [Row!22!Facing]
					,NULL AS [Row!22!Stock]
					,NULL AS [Row!22!Price]
					,NULL AS [Row!22!MarkUp]
					,NULL AS [Row!22!OutOfStock]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!SKUGroup]
					,NULL AS [Row!22!Available]
									,NULL AS [Row!22!Id]
					,NULL AS [Row!22!Ref]
					,NULL AS [Row!22!LineNumber]
					,NULL AS [Row!22!TextTask]
					,NULL AS [Row!22!Result]
					,NULL AS [Row!22!TaskRef]
				FROM @Ids Ids

	UNION ALL

	SELECT
	22 AS Tag, 21 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!21]
				,NULL AS [SKUs!21]
				,NULL AS [SKUGroups!21]
				,NULL AS [Task!21]
													 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!Question]								 ,NULL AS [Row!22!Answer]									 ,T.Id AS [Row!22!Id]								 ,T.Ref AS [Row!22!Ref]								 ,T.LineNumber AS [Row!22!LineNumber]								 ,T.SKU AS [Row!22!SKU]								 ,T.Available AS [Row!22!Available]								 ,T.Facing AS [Row!22!Facing]								 ,T.Stock AS [Row!22!Stock]								 ,T.Price AS [Row!22!Price]								 ,T.MarkUp AS [Row!22!MarkUp]								 ,T.OutOfStock AS [Row!22!OutOfStock]															 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!SKUGroup]								 ,NULL AS [Row!22!Available]												 ,NULL AS [Row!22!Id]								 ,NULL AS [Row!22!Ref]								 ,NULL AS [Row!22!LineNumber]								 ,NULL AS [Row!22!TextTask]								 ,NULL AS [Row!22!Result]								 ,NULL AS [Row!22!TaskRef]				FROM @Ids Ids
	JOIN [Document].[Visit_SKUs] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	31 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!31]
				,NULL AS [SKUs!31]
				,NULL AS [SKUGroups!31]
				,NULL AS [Task!31]
										,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!Question]
					,NULL AS [Row!32!Answer]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKU]
					,NULL AS [Row!32!Available]
					,NULL AS [Row!32!Facing]
					,NULL AS [Row!32!Stock]
					,NULL AS [Row!32!Price]
					,NULL AS [Row!32!MarkUp]
					,NULL AS [Row!32!OutOfStock]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!SKUGroup]
					,NULL AS [Row!32!Available]
									,NULL AS [Row!32!Id]
					,NULL AS [Row!32!Ref]
					,NULL AS [Row!32!LineNumber]
					,NULL AS [Row!32!TextTask]
					,NULL AS [Row!32!Result]
					,NULL AS [Row!32!TaskRef]
				FROM @Ids Ids

	UNION ALL

	SELECT
	32 AS Tag, 31 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!31]
				,NULL AS [SKUs!31]
				,NULL AS [SKUGroups!31]
				,NULL AS [Task!31]
													 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!Question]								 ,NULL AS [Row!32!Answer]												 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!SKU]								 ,NULL AS [Row!32!Available]								 ,NULL AS [Row!32!Facing]								 ,NULL AS [Row!32!Stock]								 ,NULL AS [Row!32!Price]								 ,NULL AS [Row!32!MarkUp]								 ,NULL AS [Row!32!OutOfStock]									 ,T.Id AS [Row!32!Id]								 ,T.Ref AS [Row!32!Ref]								 ,T.LineNumber AS [Row!32!LineNumber]								 ,T.SKUGroup AS [Row!32!SKUGroup]								 ,T.Available AS [Row!32!Available]															 ,NULL AS [Row!32!Id]								 ,NULL AS [Row!32!Ref]								 ,NULL AS [Row!32!LineNumber]								 ,NULL AS [Row!32!TextTask]								 ,NULL AS [Row!32!Result]								 ,NULL AS [Row!32!TaskRef]				FROM @Ids Ids
	JOIN [Document].[Visit_SKUGroups] T ON T.Ref = Ids.Id

		
	UNION ALL

	SELECT
	41 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!41]
				,NULL AS [SKUs!41]
				,NULL AS [SKUGroups!41]
				,NULL AS [Task!41]
										,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!Question]
					,NULL AS [Row!42!Answer]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKU]
					,NULL AS [Row!42!Available]
					,NULL AS [Row!42!Facing]
					,NULL AS [Row!42!Stock]
					,NULL AS [Row!42!Price]
					,NULL AS [Row!42!MarkUp]
					,NULL AS [Row!42!OutOfStock]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!SKUGroup]
					,NULL AS [Row!42!Available]
									,NULL AS [Row!42!Id]
					,NULL AS [Row!42!Ref]
					,NULL AS [Row!42!LineNumber]
					,NULL AS [Row!42!TextTask]
					,NULL AS [Row!42!Result]
					,NULL AS [Row!42!TaskRef]
				FROM @Ids Ids

	UNION ALL

	SELECT
	42 AS Tag, 41 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!Status],NULL AS [Row!2!StartTime],NULL AS [Row!2!EndTime],NULL AS [Row!2!Encashment],NULL AS [Row!2!Plan],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude]			,NULL AS [Questions!41]
				,NULL AS [SKUs!41]
				,NULL AS [SKUGroups!41]
				,NULL AS [Task!41]
													 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!Question]								 ,NULL AS [Row!42!Answer]												 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!SKU]								 ,NULL AS [Row!42!Available]								 ,NULL AS [Row!42!Facing]								 ,NULL AS [Row!42!Stock]								 ,NULL AS [Row!42!Price]								 ,NULL AS [Row!42!MarkUp]								 ,NULL AS [Row!42!OutOfStock]												 ,NULL AS [Row!42!Id]								 ,NULL AS [Row!42!Ref]								 ,NULL AS [Row!42!LineNumber]								 ,NULL AS [Row!42!SKUGroup]								 ,NULL AS [Row!42!Available]									 ,T.Id AS [Row!42!Id]								 ,T.Ref AS [Row!42!Ref]								 ,T.LineNumber AS [Row!42!LineNumber]								 ,T.TextTask AS [Row!42!TextTask]								 ,T.Result AS [Row!42!Result]								 ,T.TaskRef AS [Row!42!TaskRef]							FROM @Ids Ids
	JOIN [Document].[Visit_Task] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[Order_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[Order] E
	JOIN [Document].[Order_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
		UNION
	SELECT E.Ref 
	FROM [Document].[Order_SKUs] E
	JOIN [Document].[Order_SKUs_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo	
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.Order' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!DeliveryDate],NULL AS [Row!2!Commentary],NULL AS [Row!2!Visit],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude],NULL AS [Row!2!Status]						,NULL AS [SKUs!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Qty]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Discount]
					,NULL AS [Row!12!Total]
					,NULL AS [Row!12!Amount]
					,NULL AS [Row!12!Units]
			
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[Outlet] AS [Row!2!Outlet],H.[SR] AS [Row!2!SR],H.[DeliveryDate] AS [Row!2!DeliveryDate],H.[Commentary] AS [Row!2!Commentary],H.[Visit] AS [Row!2!Visit],H.[Lattitude] AS [Row!2!Lattitude],H.[Longitude] AS [Row!2!Longitude],H.[Status] AS [Row!2!Status]						,NULL AS [SKUs!11]
															,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Qty]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Discount]
					,NULL AS [Row!12!Total]
					,NULL AS [Row!12!Amount]
					,NULL AS [Row!12!Units]
				FROM [Document].[Order] H
	JOIN @Ids Ids ON Ids.Id = H.Id

			
	UNION ALL

	SELECT
	11 AS Tag, 2 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!DeliveryDate],NULL AS [Row!2!Commentary],NULL AS [Row!2!Visit],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude],NULL AS [Row!2!Status]			,NULL AS [SKUs!11]
										,NULL AS [Row!12!Id]
					,NULL AS [Row!12!Ref]
					,NULL AS [Row!12!LineNumber]
					,NULL AS [Row!12!SKU]
					,NULL AS [Row!12!Qty]
					,NULL AS [Row!12!Price]
					,NULL AS [Row!12!Discount]
					,NULL AS [Row!12!Total]
					,NULL AS [Row!12!Amount]
					,NULL AS [Row!12!Units]
				FROM @Ids Ids

	UNION ALL

	SELECT
	12 AS Tag, 11 AS Parent,
	NULL AS [Entity!1!Name],
	Ids.Id AS [Row!2!Id],
	NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Outlet],NULL AS [Row!2!SR],NULL AS [Row!2!DeliveryDate],NULL AS [Row!2!Commentary],NULL AS [Row!2!Visit],NULL AS [Row!2!Lattitude],NULL AS [Row!2!Longitude],NULL AS [Row!2!Status]			,NULL AS [SKUs!11]
										 ,T.Id AS [Row!12!Id]								 ,T.Ref AS [Row!12!Ref]								 ,T.LineNumber AS [Row!12!LineNumber]								 ,T.SKU AS [Row!12!SKU]								 ,T.Qty AS [Row!12!Qty]								 ,T.Price AS [Row!12!Price]								 ,T.Discount AS [Row!12!Discount]								 ,T.Total AS [Row!12!Total]								 ,T.Amount AS [Row!12!Amount]								 ,T.Units AS [Row!12!Units]							FROM @Ids Ids
	JOIN [Document].[Order_SKUs] T ON T.Ref = Ids.Id

	
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [Document].[Task_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [Document].[Task] E
	JOIN [Document].[Task_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'Document.Task' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Number],NULL AS [Row!2!Date],NULL AS [Row!2!Posted],NULL AS [Row!2!Territory],NULL AS [Row!2!Outlet],NULL AS [Row!2!StatusTask],NULL AS [Row!2!TextTask],NULL AS [Row!2!VisitPlan],NULL AS [Row!2!PlanDate],NULL AS [Row!2!TypeOfResultAndGoals],NULL AS [Row!2!Result],NULL AS [Row!2!FactDate],NULL AS [Row!2!Target]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Number] AS [Row!2!Number],H.[Date] AS [Row!2!Date],H.[Posted] AS [Row!2!Posted],H.[Territory] AS [Row!2!Territory],H.[Outlet] AS [Row!2!Outlet],H.[StatusTask] AS [Row!2!StatusTask],H.[TextTask] AS [Row!2!TextTask],H.[VisitPlan] AS [Row!2!VisitPlan],H.[PlanDate] AS [Row!2!PlanDate],H.[TypeOfResultAndGoals] AS [Row!2!TypeOfResultAndGoals],H.[Result] AS [Row!2!Result],H.[FactDate] AS [Row!2!FactDate],H.[Target] AS [Row!2!Target]							FROM [Document].[Task] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[BusinessProcess_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[BusinessProcess] E
	JOIN [resource].[BusinessProcess_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.BusinessProcess' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[BusinessProcess] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[Image_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[Image] E
	JOIN [resource].[Image_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.Image' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[Image] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[Screen_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[Screen] E
	JOIN [resource].[Screen_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.Screen' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[Screen] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[Script_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[Script] E
	JOIN [resource].[Script_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.Script' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[Script] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[Style_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[Style] E
	JOIN [resource].[Style_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.Style' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[Style] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [resource].[Translation_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [resource].[Translation] E
	JOIN [resource].[Translation_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'resource.Translation' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Data],NULL AS [Row!2!Parent]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Data] AS [Row!2!Data],H.[Parent] AS [Row!2!Parent]							FROM [resource].[Translation] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO


CREATE PROCEDURE [admin].[Entity_adm_getchanges] @SessionId UNIQUEIDENTIFIER AS
	SET NOCOUNT ON
	DECLARE @DateFrom DATETIME, @DateTo DATETIME
	SELECT @DateFrom = LastTime FROM [admin].LastSyncTime
	SELECT @DateTo = StartTime FROM [admin].SyncSession WHERE [Id] = @SessionId
	IF @DateFrom IS NULL OR @DateTo IS NULL
	  RAISERROR('Invalid interval', 16, 1)

	DECLARE @Ids TABLE(Id UNIQUEIDENTIFIER)
	INSERT @Ids 
	SELECT E.[Id] 
	FROM [admin].[Entity] E
	JOIN [admin].[Entity_tracking] T ON T.[Id] = E.[Id]
	WHERE T.[last_change_datetime] BETWEEN @DateFrom AND @DateTo
	
	SELECT
	1 AS Tag, NULL AS Parent,
	'admin.Entity' AS [Entity!1!Name],
	NULL AS [Row!2!Id],NULL AS [Row!2!Name],NULL AS [Row!2!Schema],NULL AS [Row!2!ShortName]						
	UNION ALL

	SELECT
	2 AS Tag, 1 AS Parent,
	NULL AS [Entity!1!Name],
	H.[Id] AS [Row!2!Id],H.[Name] AS [Row!2!Name],H.[Schema] AS [Row!2!Schema],H.[ShortName] AS [Row!2!ShortName]							FROM [admin].[Entity] H
	JOIN @Ids Ids ON Ids.Id = H.Id

		
	ORDER BY [Row!2!Id], Tag

	FOR XML EXPLICIT
GO

