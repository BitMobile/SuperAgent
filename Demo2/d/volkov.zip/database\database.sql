

CREATE SCHEMA Enum
GO


CREATE SCHEMA Catalog
GO


CREATE SCHEMA Document
GO


CREATE SCHEMA resource
GO


CREATE SCHEMA admin
GO



CREATE TABLE [Enum].[DataStatus](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[DataStatus] ADD CONSTRAINT PK_Enum_DataStatus PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[DataType](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[DataType] ADD CONSTRAINT PK_Enum_DataType PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[OutletConfirmationStatus](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[OutletConfirmationStatus] ADD CONSTRAINT PK_Enum_OutletConfirmationStatus PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[TypesOfUsers](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[TypesOfUsers] ADD CONSTRAINT PK_Enum_TypesOfUsers PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[UploadType](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[UploadType] ADD CONSTRAINT PK_Enum_UploadType PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[VisitStatus](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[VisitStatus] ADD CONSTRAINT PK_Enum_VisitStatus PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[StatusTask](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[StatusTask] ADD CONSTRAINT PK_Enum_StatusTask PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Enum].[OrderSatus](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(100) NOT NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Enum].[OrderSatus] ADD CONSTRAINT PK_Enum_OrderSatus PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Positions](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Positions] ADD CONSTRAINT PK_Catalog_Positions PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[User](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Manager] UNIQUEIDENTIFIER NULL,
		[EMail] VARCHAR(50) NULL,
		[UserID] UNIQUEIDENTIFIER NULL,
		[UserName] VARCHAR(100) NOT NULL,
		[Role] VARCHAR(25) NOT NULL,
		[Password] VARCHAR(100) NOT NULL,
		[Position] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Catalog].[User] ADD CONSTRAINT PK_Catalog_User PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Region](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Parent] UNIQUEIDENTIFIER NULL,
		[Manager] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Region] ADD CONSTRAINT PK_Catalog_Region PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Distributor](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Distributor] ADD CONSTRAINT PK_Catalog_Distributor PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[OutletParameter](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[DataType] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[OutletParameter] ADD CONSTRAINT PK_Catalog_OutletParameter PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[OutletType](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[OutletType] ADD CONSTRAINT PK_Catalog_OutletType PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[OutletClass](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[OutletClass] ADD CONSTRAINT PK_Catalog_OutletClass PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Outlet](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Type] UNIQUEIDENTIFIER NOT NULL,
		[Class] UNIQUEIDENTIFIER NOT NULL,
		[Distributor] UNIQUEIDENTIFIER NOT NULL,
		[Address] VARCHAR(100) NOT NULL,
		[ConfirmationStatus] UNIQUEIDENTIFIER NOT NULL,
		[Lattitude] DECIMAL(10,8) NULL,
		[Longitude] DECIMAL(10,8) NULL,
	)
GO
ALTER TABLE [Catalog].[Outlet] ADD CONSTRAINT PK_Catalog_Outlet PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Catalog].[Outlet_Parameters](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Parameter] UNIQUEIDENTIFIER NOT NULL,
		[Value] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Outlet_Parameters] ADD CONSTRAINT PK_Catalog_Outlet_Parameters PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[Outlet_Parameters] ADD CONSTRAINT FK_Catalog_Outlet_Parameters_Catalog_Outlet_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[Outlet]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Catalog].[Territory](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Owner] UNIQUEIDENTIFIER NULL,
		[SR] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Territory] ADD CONSTRAINT PK_Catalog_Territory PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Catalog].[Territory_Outlets](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Outlet] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Catalog].[Territory_Outlets] ADD CONSTRAINT PK_Catalog_Territory_Outlets PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[Territory_Outlets] ADD CONSTRAINT FK_Catalog_Territory_Outlets_Catalog_Territory_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[Territory]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Catalog].[Territory_SKUGroups](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKUGroup] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Catalog].[Territory_SKUGroups] ADD CONSTRAINT PK_Catalog_Territory_SKUGroups PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[Territory_SKUGroups] ADD CONSTRAINT FK_Catalog_Territory_SKUGroups_Catalog_Territory_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[Territory]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Catalog].[QuestionGroup](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[QuestionGroup] ADD CONSTRAINT PK_Catalog_QuestionGroup PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Question](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Owner] UNIQUEIDENTIFIER NULL,
		[AnswerType] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Question] ADD CONSTRAINT PK_Catalog_Question PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Catalog].[Question_ValueList](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Value] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Question_ValueList] ADD CONSTRAINT PK_Catalog_Question_ValueList PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[Question_ValueList] ADD CONSTRAINT FK_Catalog_Question_ValueList_Catalog_Question_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[Question]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Catalog].[SKUGroup](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Parent] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Catalog].[SKUGroup] ADD CONSTRAINT PK_Catalog_SKUGroup PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[Brands](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[Brands] ADD CONSTRAINT PK_Catalog_Brands PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[UnitsOfMeasure](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(25) NOT NULL,
		[FullDescription] VARCHAR(50) NULL,
	)
GO
ALTER TABLE [Catalog].[UnitsOfMeasure] ADD CONSTRAINT PK_Catalog_UnitsOfMeasure PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [Catalog].[SKU](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[Owner] UNIQUEIDENTIFIER NULL,
		[Price] DECIMAL(15,2) NULL,
		[Brand] UNIQUEIDENTIFIER NOT NULL,
		[Stock] DECIMAL(10,2) NULL,
		[BaseUnit] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[SKU] ADD CONSTRAINT PK_Catalog_SKU PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Catalog].[SKU_Packing](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Pack] UNIQUEIDENTIFIER NULL,
		[Multiplier] DECIMAL(10,2) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[SKU_Packing] ADD CONSTRAINT PK_Catalog_SKU_Packing PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[SKU_Packing] ADD CONSTRAINT FK_Catalog_SKU_Packing_Catalog_SKU_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[SKU]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Catalog].[SKUQuestions](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Code] VARCHAR(9) NULL,
		[Description] VARCHAR(100) NOT NULL,
		[AnswerType] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Catalog].[SKUQuestions] ADD CONSTRAINT PK_Catalog_SKUQuestions PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Catalog].[SKUQuestions_ValueList](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Value] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Catalog].[SKUQuestions_ValueList] ADD CONSTRAINT PK_Catalog_SKUQuestions_ValueList PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Catalog].[SKUQuestions_ValueList] ADD CONSTRAINT FK_Catalog_SKUQuestions_ValueList_Catalog_SKUQuestions_EntityId FOREIGN KEY ([Ref]) REFERENCES [Catalog].[SKUQuestions]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[PriceList](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
	)
GO
ALTER TABLE [Document].[PriceList] ADD CONSTRAINT PK_Document_PriceList PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[PriceList_Prices](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKU] UNIQUEIDENTIFIER NOT NULL,
		[Price] DECIMAL(10,2) NOT NULL,
		[Stock] DECIMAL(10,2) NULL,
	)
GO
ALTER TABLE [Document].[PriceList_Prices] ADD CONSTRAINT PK_Document_PriceList_Prices PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[PriceList_Prices] ADD CONSTRAINT FK_Document_PriceList_Prices_Document_PriceList_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[PriceList]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[Questionnaire](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[OutletType] UNIQUEIDENTIFIER NOT NULL,
		[OutletClass] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire] ADD CONSTRAINT PK_Document_Questionnaire PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[Questionnaire_Questions](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Question] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire_Questions] ADD CONSTRAINT PK_Document_Questionnaire_Questions PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Questionnaire_Questions] ADD CONSTRAINT FK_Document_Questionnaire_Questions_Document_Questionnaire_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Questionnaire]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Questionnaire_SKUs](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKU] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire_SKUs] ADD CONSTRAINT PK_Document_Questionnaire_SKUs PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Questionnaire_SKUs] ADD CONSTRAINT FK_Document_Questionnaire_SKUs_Document_Questionnaire_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Questionnaire]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Questionnaire_SKUGroups](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKUGroup] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire_SKUGroups] ADD CONSTRAINT PK_Document_Questionnaire_SKUGroups PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Questionnaire_SKUGroups] ADD CONSTRAINT FK_Document_Questionnaire_SKUGroups_Document_Questionnaire_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Questionnaire]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Questionnaire_SKUQuestions](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKUQuestion] UNIQUEIDENTIFIER NULL,
		[UseInQuestionaire] BIT NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire_SKUQuestions] ADD CONSTRAINT PK_Document_Questionnaire_SKUQuestions PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Questionnaire_SKUQuestions] ADD CONSTRAINT FK_Document_Questionnaire_SKUQuestions_Document_Questionnaire_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Questionnaire]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Questionnaire_Territories](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Territory] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Document].[Questionnaire_Territories] ADD CONSTRAINT PK_Document_Questionnaire_Territories PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Questionnaire_Territories] ADD CONSTRAINT FK_Document_Questionnaire_Territories_Document_Questionnaire_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Questionnaire]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[Target](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[Territory] UNIQUEIDENTIFIER NOT NULL,
		[OutletType] UNIQUEIDENTIFIER NOT NULL,
		[OutletClass] UNIQUEIDENTIFIER NOT NULL,
	)
GO
ALTER TABLE [Document].[Target] ADD CONSTRAINT PK_Document_Target PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[Target_Targets](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Question] UNIQUEIDENTIFIER NOT NULL,
		[Value] DECIMAL(10,2) NOT NULL,
	)
GO
ALTER TABLE [Document].[Target_Targets] ADD CONSTRAINT PK_Document_Target_Targets PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Target_Targets] ADD CONSTRAINT FK_Document_Target_Targets_Document_Target_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Target]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[VisitPlan](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[Year] DATETIME NOT NULL,
		[WeekNumber] INT NOT NULL,
		[SR] UNIQUEIDENTIFIER NOT NULL,
		[Owner] UNIQUEIDENTIFIER NOT NULL,
		[DateFrom] DATETIME NOT NULL,
		[DateTo] DATETIME NOT NULL,
	)
GO
ALTER TABLE [Document].[VisitPlan] ADD CONSTRAINT PK_Document_VisitPlan PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[VisitPlan_Outlets](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Outlet] UNIQUEIDENTIFIER NOT NULL,
		[Date] DATETIME NOT NULL,
	)
GO
ALTER TABLE [Document].[VisitPlan_Outlets] ADD CONSTRAINT PK_Document_VisitPlan_Outlets PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[VisitPlan_Outlets] ADD CONSTRAINT FK_Document_VisitPlan_Outlets_Document_VisitPlan_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[VisitPlan]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[Visit](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[Outlet] UNIQUEIDENTIFIER NOT NULL,
		[SR] UNIQUEIDENTIFIER NOT NULL,
		[Status] UNIQUEIDENTIFIER NOT NULL,
		[StartTime] DATETIME NOT NULL,
		[EndTime] DATETIME NULL,
		[Encashment] DECIMAL(15,2) NOT NULL,
		[Plan] UNIQUEIDENTIFIER NULL,
		[Lattitude] DECIMAL(10,8) NULL,
		[Longitude] DECIMAL(10,8) NULL,
	)
GO
ALTER TABLE [Document].[Visit] ADD CONSTRAINT PK_Document_Visit PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[Visit_Questions](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[Question] UNIQUEIDENTIFIER NOT NULL,
		[Answer] VARCHAR(100) NOT NULL,
	)
GO
ALTER TABLE [Document].[Visit_Questions] ADD CONSTRAINT PK_Document_Visit_Questions PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Visit_Questions] ADD CONSTRAINT FK_Document_Visit_Questions_Document_Visit_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Visit]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Visit_SKUs](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKU] UNIQUEIDENTIFIER NOT NULL,
		[Available] BIT NOT NULL,
		[Facing] INT NULL,
		[Stock] INT NULL,
		[Price] INT NULL,
		[MarkUp] INT NULL,
		[OutOfStock] BIT NOT NULL,
	)
GO
ALTER TABLE [Document].[Visit_SKUs] ADD CONSTRAINT PK_Document_Visit_SKUs PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Visit_SKUs] ADD CONSTRAINT FK_Document_Visit_SKUs_Document_Visit_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Visit]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Visit_SKUGroups](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKUGroup] UNIQUEIDENTIFIER NOT NULL,
		[Available] BIT NOT NULL,
	)
GO
ALTER TABLE [Document].[Visit_SKUGroups] ADD CONSTRAINT PK_Document_Visit_SKUGroups PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Visit_SKUGroups] ADD CONSTRAINT FK_Document_Visit_SKUGroups_Document_Visit_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Visit]([Id]) ON DELETE CASCADE
GO


CREATE TABLE [Document].[Visit_Task](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[TextTask] VARCHAR(100) NULL,
		[Result] VARCHAR(100) NULL,
		[TaskRef] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Document].[Visit_Task] ADD CONSTRAINT PK_Document_Visit_Task PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Visit_Task] ADD CONSTRAINT FK_Document_Visit_Task_Document_Visit_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Visit]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[Order](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[Outlet] UNIQUEIDENTIFIER NOT NULL,
		[SR] UNIQUEIDENTIFIER NOT NULL,
		[DeliveryDate] DATETIME NOT NULL,
		[Commentary] VARCHAR(100) NULL,
		[Visit] UNIQUEIDENTIFIER NULL,
		[Lattitude] DECIMAL(10,8) NULL,
		[Longitude] DECIMAL(10,8) NULL,
		[Status] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Document].[Order] ADD CONSTRAINT PK_Document_Order PRIMARY KEY CLUSTERED([Id]) 
GO


CREATE TABLE [Document].[Order_SKUs](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Ref] UNIQUEIDENTIFIER NOT NULL,
		[LineNumber] INT NOT NULL,
		[SKU] UNIQUEIDENTIFIER NOT NULL,
		[Qty] DECIMAL(15,1) NOT NULL,
		[Price] DECIMAL(15,2) NOT NULL,
		[Discount] INT NOT NULL,
		[Total] DECIMAL(10,2) NOT NULL,
		[Amount] DECIMAL(15,2) NOT NULL,
		[Units] UNIQUEIDENTIFIER NULL,
	)
GO
ALTER TABLE [Document].[Order_SKUs] ADD CONSTRAINT PK_Document_Order_SKUs PRIMARY KEY CLUSTERED([Id]) 
ALTER TABLE [Document].[Order_SKUs] ADD CONSTRAINT FK_Document_Order_SKUs_Document_Order_EntityId FOREIGN KEY ([Ref]) REFERENCES [Document].[Order]([Id]) ON DELETE CASCADE
GO



CREATE TABLE [Document].[Task](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Number] VARCHAR(9) NULL,
		[Date] DATETIME NOT NULL,
		[Posted] BIT NULL,
		[Territory] UNIQUEIDENTIFIER NOT NULL,
		[Outlet] UNIQUEIDENTIFIER NULL,
		[StatusTask] UNIQUEIDENTIFIER NULL,
		[TextTask] VARCHAR(100) NULL,
		[VisitPlan] UNIQUEIDENTIFIER NULL,
		[PlanDate] DATETIME NOT NULL,
		[TypeOfResultAndGoals] UNIQUEIDENTIFIER NULL,
		[Result] VARCHAR(100) NULL,
		[FactDate] DATETIME NULL,
		[Target] VARCHAR(100) NULL,
	)
GO
ALTER TABLE [Document].[Task] ADD CONSTRAINT PK_Document_Task PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[BusinessProcess](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[BusinessProcess] ADD CONSTRAINT PK_resource_BusinessProcess PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[Image](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[Image] ADD CONSTRAINT PK_resource_Image PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[Screen](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[Screen] ADD CONSTRAINT PK_resource_Screen PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[Script](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[Script] ADD CONSTRAINT PK_resource_Script PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[Style](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[Style] ADD CONSTRAINT PK_resource_Style PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [resource].[Translation](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Data] NTEXT NOT NULL,
		[Parent] VARCHAR(250) NOT NULL,
	)
GO
ALTER TABLE [resource].[Translation] ADD CONSTRAINT PK_resource_Translation PRIMARY KEY CLUSTERED([Id]) 
GO



CREATE TABLE [admin].[Entity](
		[Id] UNIQUEIDENTIFIER NOT NULL,
		[Name] VARCHAR(250) NOT NULL,
		[Schema] VARCHAR(50) NOT NULL,
		[ShortName] VARCHAR(50) NOT NULL,
	)
GO
ALTER TABLE [admin].[Entity] ADD CONSTRAINT PK_admin_Entity PRIMARY KEY CLUSTERED([Id]) 
GO



GO

GO

GO

GO

GO

GO

GO

GO

GO

ALTER TABLE [Catalog].[User] ADD CONSTRAINT FK_Catalog_User_Catalog_User_Manager FOREIGN KEY ([Manager]) REFERENCES [Catalog].[User]([Id])
ALTER TABLE [Catalog].[User] ADD CONSTRAINT FK_Catalog_User_Catalog_Positions_Position FOREIGN KEY ([Position]) REFERENCES [Catalog].[Positions]([Id])
GO

ALTER TABLE [Catalog].[Region] ADD CONSTRAINT FK_Catalog_Region_Catalog_Region_Parent FOREIGN KEY ([Parent]) REFERENCES [Catalog].[Region]([Id])
ALTER TABLE [Catalog].[Region] ADD CONSTRAINT FK_Catalog_Region_Catalog_User_Manager FOREIGN KEY ([Manager]) REFERENCES [Catalog].[User]([Id])
GO

GO

ALTER TABLE [Catalog].[OutletParameter] ADD CONSTRAINT FK_Catalog_OutletParameter_Enum_DataType_DataType FOREIGN KEY ([DataType]) REFERENCES [Enum].[DataType]([Id])
GO

GO

GO

ALTER TABLE [Catalog].[Outlet] ADD CONSTRAINT FK_Catalog_Outlet_Catalog_OutletType_Type FOREIGN KEY ([Type]) REFERENCES [Catalog].[OutletType]([Id])
ALTER TABLE [Catalog].[Outlet] ADD CONSTRAINT FK_Catalog_Outlet_Catalog_OutletClass_Class FOREIGN KEY ([Class]) REFERENCES [Catalog].[OutletClass]([Id])
ALTER TABLE [Catalog].[Outlet] ADD CONSTRAINT FK_Catalog_Outlet_Catalog_Distributor_Distributor FOREIGN KEY ([Distributor]) REFERENCES [Catalog].[Distributor]([Id])
ALTER TABLE [Catalog].[Outlet] ADD CONSTRAINT FK_Catalog_Outlet_Enum_OutletConfirmationStatus_ConfirmationStatus FOREIGN KEY ([ConfirmationStatus]) REFERENCES [Enum].[OutletConfirmationStatus]([Id])
GO

ALTER TABLE [Catalog].[Territory] ADD CONSTRAINT FK_Catalog_Territory_Catalog_Region_Owner FOREIGN KEY ([Owner]) REFERENCES [Catalog].[Region]([Id])
ALTER TABLE [Catalog].[Territory] ADD CONSTRAINT FK_Catalog_Territory_Catalog_User_SR FOREIGN KEY ([SR]) REFERENCES [Catalog].[User]([Id])
GO

GO

ALTER TABLE [Catalog].[Question] ADD CONSTRAINT FK_Catalog_Question_Catalog_QuestionGroup_Owner FOREIGN KEY ([Owner]) REFERENCES [Catalog].[QuestionGroup]([Id])
ALTER TABLE [Catalog].[Question] ADD CONSTRAINT FK_Catalog_Question_Enum_DataType_AnswerType FOREIGN KEY ([AnswerType]) REFERENCES [Enum].[DataType]([Id])
GO

ALTER TABLE [Catalog].[SKUGroup] ADD CONSTRAINT FK_Catalog_SKUGroup_Catalog_SKUGroup_Parent FOREIGN KEY ([Parent]) REFERENCES [Catalog].[SKUGroup]([Id])
GO

GO

GO

ALTER TABLE [Catalog].[SKU] ADD CONSTRAINT FK_Catalog_SKU_Catalog_SKUGroup_Owner FOREIGN KEY ([Owner]) REFERENCES [Catalog].[SKUGroup]([Id])
ALTER TABLE [Catalog].[SKU] ADD CONSTRAINT FK_Catalog_SKU_Catalog_Brands_Brand FOREIGN KEY ([Brand]) REFERENCES [Catalog].[Brands]([Id])
ALTER TABLE [Catalog].[SKU] ADD CONSTRAINT FK_Catalog_SKU_Catalog_UnitsOfMeasure_BaseUnit FOREIGN KEY ([BaseUnit]) REFERENCES [Catalog].[UnitsOfMeasure]([Id])
GO

ALTER TABLE [Catalog].[SKUQuestions] ADD CONSTRAINT FK_Catalog_SKUQuestions_Enum_DataType_AnswerType FOREIGN KEY ([AnswerType]) REFERENCES [Enum].[DataType]([Id])
GO

GO

ALTER TABLE [Document].[Questionnaire] ADD CONSTRAINT FK_Document_Questionnaire_Catalog_OutletType_OutletType FOREIGN KEY ([OutletType]) REFERENCES [Catalog].[OutletType]([Id])
ALTER TABLE [Document].[Questionnaire] ADD CONSTRAINT FK_Document_Questionnaire_Catalog_OutletClass_OutletClass FOREIGN KEY ([OutletClass]) REFERENCES [Catalog].[OutletClass]([Id])
GO

ALTER TABLE [Document].[Target] ADD CONSTRAINT FK_Document_Target_Catalog_Territory_Territory FOREIGN KEY ([Territory]) REFERENCES [Catalog].[Territory]([Id])
ALTER TABLE [Document].[Target] ADD CONSTRAINT FK_Document_Target_Catalog_OutletType_OutletType FOREIGN KEY ([OutletType]) REFERENCES [Catalog].[OutletType]([Id])
ALTER TABLE [Document].[Target] ADD CONSTRAINT FK_Document_Target_Catalog_OutletClass_OutletClass FOREIGN KEY ([OutletClass]) REFERENCES [Catalog].[OutletClass]([Id])
GO

ALTER TABLE [Document].[VisitPlan] ADD CONSTRAINT FK_Document_VisitPlan_Catalog_User_SR FOREIGN KEY ([SR]) REFERENCES [Catalog].[User]([Id])
ALTER TABLE [Document].[VisitPlan] ADD CONSTRAINT FK_Document_VisitPlan_Catalog_User_Owner FOREIGN KEY ([Owner]) REFERENCES [Catalog].[User]([Id])
GO

ALTER TABLE [Document].[Visit] ADD CONSTRAINT FK_Document_Visit_Catalog_Outlet_Outlet FOREIGN KEY ([Outlet]) REFERENCES [Catalog].[Outlet]([Id])
ALTER TABLE [Document].[Visit] ADD CONSTRAINT FK_Document_Visit_Catalog_User_SR FOREIGN KEY ([SR]) REFERENCES [Catalog].[User]([Id])
ALTER TABLE [Document].[Visit] ADD CONSTRAINT FK_Document_Visit_Enum_VisitStatus_Status FOREIGN KEY ([Status]) REFERENCES [Enum].[VisitStatus]([Id])
ALTER TABLE [Document].[Visit] ADD CONSTRAINT FK_Document_Visit_Document_VisitPlan_Plan FOREIGN KEY ([Plan]) REFERENCES [Document].[VisitPlan]([Id])
GO

ALTER TABLE [Document].[Order] ADD CONSTRAINT FK_Document_Order_Catalog_Outlet_Outlet FOREIGN KEY ([Outlet]) REFERENCES [Catalog].[Outlet]([Id])
ALTER TABLE [Document].[Order] ADD CONSTRAINT FK_Document_Order_Catalog_User_SR FOREIGN KEY ([SR]) REFERENCES [Catalog].[User]([Id])
ALTER TABLE [Document].[Order] ADD CONSTRAINT FK_Document_Order_Document_Visit_Visit FOREIGN KEY ([Visit]) REFERENCES [Document].[Visit]([Id])
ALTER TABLE [Document].[Order] ADD CONSTRAINT FK_Document_Order_Enum_OrderSatus_Status FOREIGN KEY ([Status]) REFERENCES [Enum].[OrderSatus]([Id])
GO

ALTER TABLE [Document].[Task] ADD CONSTRAINT FK_Document_Task_Catalog_Territory_Territory FOREIGN KEY ([Territory]) REFERENCES [Catalog].[Territory]([Id])
ALTER TABLE [Document].[Task] ADD CONSTRAINT FK_Document_Task_Catalog_Outlet_Outlet FOREIGN KEY ([Outlet]) REFERENCES [Catalog].[Outlet]([Id])
ALTER TABLE [Document].[Task] ADD CONSTRAINT FK_Document_Task_Enum_StatusTask_StatusTask FOREIGN KEY ([StatusTask]) REFERENCES [Enum].[StatusTask]([Id])
ALTER TABLE [Document].[Task] ADD CONSTRAINT FK_Document_Task_Document_VisitPlan_VisitPlan FOREIGN KEY ([VisitPlan]) REFERENCES [Document].[VisitPlan]([Id])
ALTER TABLE [Document].[Task] ADD CONSTRAINT FK_Document_Task_Enum_DataType_TypeOfResultAndGoals FOREIGN KEY ([TypeOfResultAndGoals]) REFERENCES [Enum].[DataType]([Id])
GO

GO

GO

GO

GO

GO

GO

ALTER TABLE [admin].[Entity] ADD CONSTRAINT UQ_admin_Entity_Name UNIQUE ([Name])
GO



