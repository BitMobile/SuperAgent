

ALTER PROCEDURE [Enum].[DataStatus_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[DataStatus] [base]
RIGHT JOIN [Enum].[DataStatus_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[DataType_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[DataType] [base]
RIGHT JOIN [Enum].[DataType_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[OutletConfirmationStatus_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[OutletConfirmationStatus] [base]
RIGHT JOIN [Enum].[OutletConfirmationStatus_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[TypesOfUsers_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[TypesOfUsers] [base]
RIGHT JOIN [Enum].[TypesOfUsers_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[UploadType_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[UploadType] [base]
RIGHT JOIN [Enum].[UploadType_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[VisitStatus_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[VisitStatus] [base]
RIGHT JOIN [Enum].[VisitStatus_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[StatusTask_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[StatusTask] [base]
RIGHT JOIN [Enum].[StatusTask_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Enum].[OrderSatus_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Enum].[OrderSatus] [base]
RIGHT JOIN [Enum].[OrderSatus_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Positions_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Positions] [base]
RIGHT JOIN [Catalog].[Positions_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[User_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Manager],[base].[EMail],[base].[UserID],[base].[UserName],[base].[Role],[base].[Password],[base].[Position],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[User] [base]
RIGHT JOIN [Catalog].[User_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Region_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Parent],[base].[Manager],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Region] [base]
RIGHT JOIN [Catalog].[Region_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Distributor_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Distributor] [base]
RIGHT JOIN [Catalog].[Distributor_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[OutletParameter_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[DataType],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[OutletParameter] [base]
RIGHT JOIN [Catalog].[OutletParameter_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[OutletType_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[OutletType] [base]
RIGHT JOIN [Catalog].[OutletType_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[OutletClass_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[OutletClass] [base]
RIGHT JOIN [Catalog].[OutletClass_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Outlet_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Type],[base].[Class],[base].[Distributor],[base].[Address],[base].[ConfirmationStatus],[base].[Lattitude],[base].[Longitude],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Outlet] [base]
RIGHT JOIN [Catalog].[Outlet_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Catalog].[Outlet_Parameters_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Parameter],[base].[Value],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Outlet_Parameters] [base]
INNER JOIN [Catalog].[Outlet] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[Outlet_Parameters_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Territory_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER  
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Owner],[base].[SR],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Territory] [base]
RIGHT JOIN [Catalog].[Territory_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Catalog].[Territory_Outlets_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Outlet],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Territory_Outlets] [base]
INNER JOIN [Catalog].[Territory] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[Territory_Outlets_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Catalog].[Territory_SKUGroups_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKUGroup],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Territory_SKUGroups] [base]
INNER JOIN [Catalog].[Territory] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[Territory_SKUGroups_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [Catalog].[QuestionGroup_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[QuestionGroup] [base]
RIGHT JOIN [Catalog].[QuestionGroup_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Question_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Owner],[base].[AnswerType],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Question] [base]
RIGHT JOIN [Catalog].[Question_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Catalog].[Question_ValueList_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Value],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Question_ValueList] [base]
INNER JOIN [Catalog].[Question] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[Question_ValueList_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[SKUGroup_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[SKUGroup] [base]
RIGHT JOIN [Catalog].[SKUGroup_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[Brands_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[Brands] [base]
RIGHT JOIN [Catalog].[Brands_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[UnitsOfMeasure_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[FullDescription],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[UnitsOfMeasure] [base]
RIGHT JOIN [Catalog].[UnitsOfMeasure_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[SKU_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[Owner],[base].[Price],[base].[Brand],[base].[Stock],[base].[BaseUnit],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[SKU] [base]
RIGHT JOIN [Catalog].[SKU_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Catalog].[SKU_Packing_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Pack],[base].[Multiplier],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[SKU_Packing] [base]
INNER JOIN [Catalog].[SKU] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[SKU_Packing_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Catalog].[SKUQuestions_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Code],[base].[Description],[base].[AnswerType],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[SKUQuestions] [base]
RIGHT JOIN [Catalog].[SKUQuestions_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Catalog].[SKUQuestions_ValueList_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Value],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Catalog].[SKUQuestions_ValueList] [base]
INNER JOIN [Catalog].[SKUQuestions] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Catalog].[SKUQuestions_ValueList_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Document].[PriceList_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[PriceList] [base]
RIGHT JOIN [Document].[PriceList_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[PriceList_Prices_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKU],[base].[Price],[base].[Stock],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[PriceList_Prices] [base]
INNER JOIN [Document].[PriceList] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[PriceList_Prices_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Document].[Questionnaire_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[OutletType],[base].[OutletClass],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire] [base]
RIGHT JOIN [Document].[Questionnaire_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Questionnaire_Questions_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Question],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire_Questions] [base]
INNER JOIN [Document].[Questionnaire] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Questionnaire_Questions_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Questionnaire_SKUs_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKU],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire_SKUs] [base]
INNER JOIN [Document].[Questionnaire] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Questionnaire_SKUs_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Questionnaire_SKUGroups_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKUGroup],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire_SKUGroups] [base]
INNER JOIN [Document].[Questionnaire] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Questionnaire_SKUGroups_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Questionnaire_SKUQuestions_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKUQuestion],[base].[UseInQuestionaire],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire_SKUQuestions] [base]
INNER JOIN [Document].[Questionnaire] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Questionnaire_SKUQuestions_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Questionnaire_Territories_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Territory],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Questionnaire_Territories] [base]
INNER JOIN [Document].[Questionnaire] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Questionnaire_Territories_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Document].[Target_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[Territory],[base].[OutletType],[base].[OutletClass],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Target] [base]
RIGHT JOIN [Document].[Target_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


ALTER PROCEDURE [Document].[Target_Targets_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Question],[base].[Value],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Target_Targets] [base]
INNER JOIN [Document].[Target] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Target_Targets_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [Document].[VisitPlan_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER  
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[Year],[base].[WeekNumber],[base].[SR],[base].[Owner],[base].[DateFrom],[base].[DateTo],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[VisitPlan] [base]
RIGHT JOIN [Document].[VisitPlan_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[VisitPlan_Outlets_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Outlet],[base].[Date],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[VisitPlan_Outlets] [base]
INNER JOIN [Document].[VisitPlan] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[VisitPlan_Outlets_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [Document].[Visit_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER  
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[Outlet],[base].[SR],[base].[Status],[base].[StartTime],[base].[EndTime],[base].[Encashment],[base].[Plan],[base].[Lattitude],[base].[Longitude],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Visit] [base]
RIGHT JOIN [Document].[Visit_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[Visit_Questions_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[Question],[base].[Answer],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Visit_Questions] [base]
INNER JOIN [Document].[Visit] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Visit_Questions_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[Visit_SKUs_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKU],[base].[Available],[base].[Facing],[base].[Stock],[base].[Price],[base].[MarkUp],[base].[OutOfStock],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Visit_SKUs] [base]
INNER JOIN [Document].[Visit] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Visit_SKUs_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[Visit_SKUGroups_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKUGroup],[base].[Available],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Visit_SKUGroups] [base]
INNER JOIN [Document].[Visit] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Visit_SKUGroups_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[Visit_Task_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[TextTask],[base].[Result],[base].[TaskRef],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Visit_Task] [base]
INNER JOIN [Document].[Visit] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Visit_Task_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [Document].[Order_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER  
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[Outlet],[base].[SR],[base].[DeliveryDate],[base].[Commentary],[base].[Visit],[base].[Lattitude],[base].[Longitude],[base].[Status],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Order] [base]
RIGHT JOIN [Document].[Order_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO


ALTER PROCEDURE [Document].[Order_SKUs_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@UserId UNIQUEIDENTIFIER AS
SELECT
[side].[Id],[base].[Ref],[base].[LineNumber],[base].[SKU],[base].[Qty],[base].[Price],[base].[Discount],[base].[Total],[base].[Amount],[base].[Units],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Order_SKUs] [base]
INNER JOIN [Document].[Order] [parent] ON [base].[Ref] = [parent].[Id]
RIGHT JOIN [Document].[Order_SKUs_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([parent].SR = @UserId) OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [Document].[Task_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Number],[base].[Date],[base].[Posted],[base].[Territory],[base].[Outlet],[base].[StatusTask],[base].[TextTask],[base].[VisitPlan],[base].[PlanDate],[base].[TypeOfResultAndGoals],[base].[Result],[base].[FactDate],[base].[Target],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [Document].[Task] [base]
RIGHT JOIN [Document].[Task_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [resource].[BusinessProcess_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[BusinessProcess] [base]
RIGHT JOIN [resource].[BusinessProcess_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [resource].[Image_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@Resolution VARCHAR(100)  
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[Image] [base]
RIGHT JOIN [resource].[Image_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].Parent LIKE '%' + @Resolution + '%') OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [resource].[Screen_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[Screen] [base]
RIGHT JOIN [resource].[Screen_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [resource].[Script_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[Script] [base]
RIGHT JOIN [resource].[Script_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [resource].[Style_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
,@Resolution VARCHAR(100)  
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[Style] [base]
RIGHT JOIN [resource].[Style_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
AND (([side].Parent LIKE '%' + @Resolution + '%') OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL)))

GO



ALTER PROCEDURE [resource].[Translation_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Data],[base].[Parent],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [resource].[Translation] [base]
RIGHT JOIN [resource].[Translation_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO



ALTER PROCEDURE [admin].[Entity_selectchanges]
@sync_min_timestamp BigInt,
@sync_scope_local_id Int,
@sync_scope_restore_count Int,
@sync_update_peer_key Int
 
AS
SELECT
[side].[Id],[base].[Name],[base].[Schema],[base].[ShortName],[side].[sync_row_is_tombstone],
[side].[local_update_peer_timestamp] as sync_row_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then [side].[local_update_peer_timestamp] else [side].[scope_update_peer_timestamp] end as sync_update_peer_timestamp,
case when ([side].[update_scope_local_id] is null or [side].[update_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_update_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_update_peer_key] end else [side].[scope_update_peer_key] end as sync_update_peer_key,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then [side].[local_create_peer_timestamp] else [side].[scope_create_peer_timestamp] end as sync_create_peer_timestamp,
case when ([side].[create_scope_local_id] is null or [side].[create_scope_local_id] <> @sync_scope_local_id) then case when ([side].[local_create_peer_key] > @sync_scope_restore_count) then @sync_scope_restore_count else [side].[local_create_peer_key] end else [side].[scope_create_peer_key] end as sync_create_peer_key
FROM [admin].[Entity] [base]
RIGHT JOIN [admin].[Entity_tracking] [side] ON [base].[Id] = [side].[Id]
WHERE ([side].[update_scope_local_id] IS NULL OR [side].[update_scope_local_id] <> @sync_scope_local_id OR ([side].[update_scope_local_id] = @sync_scope_local_id AND [side].[scope_update_peer_key] <> @sync_update_peer_key)) AND [side].[local_update_peer_timestamp] > @sync_min_timestamp
OR ([side].[sync_row_is_tombstone] = 1 AND ([side].[update_scope_local_id] = @sync_scope_local_id OR [side].[update_scope_local_id] IS NULL))

GO


