use 
http://bitmobile server address/solution name/script/js file name/function name
to run

for guestbook example 
http://bitmobile server address/sulution name/script/guestbook/entries
