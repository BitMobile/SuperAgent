function DoSave()
{
    DB.Save();
}

function DoSync()
{
    DB.Sync();
}
